# SICREP - Sistema Integral de Certificación REP

## Overview

SICREP is a comprehensive SaaS platform for REP (Extended Producer Responsibility) compliance certification in Chile, designed specifically for the mining industry and their suppliers. The system provides end-to-end certification workflow management, CPS (Código Producto SICREP) packaging certification, NFC-based traceability, ESG analytics, and regulatory compliance according to Chilean Law 20.920.

The platform serves two primary user segments:
- **Providers (<300kg)**: Companies that introduce less than 300kg of packaging annually who need RETC reporting, CPS certification, and dispatch tracking
- **Mining Companies**: Large enterprises requiring centralized ESG dashboards, supplier management, and compliance tracking

## Recent Changes (November 2024)

### Technical Documentation Analysis - COMPLETED (8 Nov 2025)
- **5 Official Documents Received**: Manual Técnico v1.1, Modelo de Negocio (1630 lines), Benchmark Report, HTML Certificador, Certificado PDF
- **Gap Analysis Documented**: `ANALISIS_TECNICO_SICREP.md` with complete comparison spec vs implementation
- **Key Findings**:
  - **CPS Assignment CLARIFIED**: Provider creates CPS during onboarding (auto-generated as `CPS-[RUT]-001`), NOT assigned by evaluator
  - **Evaluator Role**: Phases 4-6 (Technical Evaluation, Preliminary Report, Corrections), reviews existing CPS from providers
  - **Manager/CPS Role**: Internal SICREP coordinator, orchestrates projects, approves labels, manages SLA (not CPS creator)
  - **Official Workflow**: `Solicitud → Evaluación documental → Auditoría → Comité → Dictamen` (Apto/En Proceso/No apto)
  - **Blockchain Required**: Polygon Mumbai hash for immutable traceability (Copper Mark + Ley REP compliance)
  - **Public QR Validation**: Endpoint `/api/validar/{hash}` without authentication for industrial consumers
  - **Auto-derivation >300kg**: Alert at 80%, block modules, export XML RETC format for Sistema de Gestión handoff
  - **Pricing Model**: 4 tiers (MICRO Express 280k, MICRO Plus 450k, PYME 680k, COMERCIALIZADORA 1.2M CLP/year)
  - **ROI**: 531% return for 150kg/year provider (saves 1.97M CLP vs manual process)
- **Critical Gaps Identified**:
  1. ❌ Backend security completely absent (BLOCKER for production)
  2. ❌ Certification workflow only UI mockup, no backend logic
  3. ❌ Blockchain traceability not implemented
  4. ❌ Auto-derivation >300kg missing
  5. ❌ RETC XML export not implemented
  6. ❌ Public QR validation API missing
- **Next Priority**: See `ANALISIS_TECNICO_SICREP.md` for full 5-phase implementation plan

### Module PDF Reports - COMPLETED (November 2024)
- **PDF Generation System**: Puppeteer-based system generating 3 professional branded reports
  - `Certificado REP Oficial`: Official certification document with SICREP branding, QR code, signatures
  - `Reporte de Auditoría`: Comprehensive audit report with findings, recommendations, compliance metrics
  - `Reporte ESG`: Environmental, Social, Governance analytics with Copper Mark status, CO2 footprint
- **API Routes**: `/api/reports/certificado/:id`, `/api/reports/auditoria/:id`, `/api/reports/esg/:id`
- **UI Integration**: Download buttons in CertificadorDashboard, AuditorDashboard, AnalistaESGDashboard
- **Technical Implementation**:
  - Shared browser instance with promise lock to prevent race conditions
  - Process signal handlers (SIGINT/SIGTERM) for graceful Puppeteer cleanup
  - Professional HTML/CSS templates with consistent SICREP branding
- **⚠️ CRITICAL SECURITY GAP**: PDF endpoints (and all API routes) lack backend authorization
  - Frontend RoleGuard exists but can be bypassed with direct API calls
  - System uses stateless auth (login returns JSON without session/token)
  - **NEXT PRIORITY**: Implement express-session based RBAC middleware for backend authorization

### Module CPS (Código Producto SICREP) - COMPLETED
- **New Tables**: 
  - `cps` for product codes with level and averageWeight
  - `cps_materials` for material composition per CPS (percentage breakdown)
  - `dispatch_materials` for actual material breakdown per dispatch
- **Material Types**: papel_carton, plasticos, vidrio, metales, madera, compuestos, otros
- **Package Levels**: primario, secundario, terciario
- **Weight Management**: 
  - totalWeight and yearlyUsage stored in grams (INTEGER) for precision
  - annualLimit in kg, conversions done at display/validation layer
- **API Routes**: Complete CRUD for CPS, dispatch_materials, cps_materials
- **UI**: 
  - CPSManagement page at /cps with CRUD dialogs
  - DispatchManagement page at /despachos with automatic material breakdown generation

### Module Despachos (Dispatches) - COMPLETED
- **Automatic Material Breakdown**: When creating dispatch, system auto-generates dispatch_materials based on cps_materials composition
- **Yearly Usage Tracking**: company.yearlyUsage updated transactionally on dispatch creation (stored in grams)
- **Annual Limit Validation**: Frontend and backend validate 300kg limit before allowing dispatch
- **Real-time Dashboard**: Metrics update immediately via React Query cache invalidation
- **Critical Bugs Fixed**:
  - Unit consistency: yearlyUsage in grams, annualLimit in kg with proper conversions
  - React Query cache key alignment for automatic UI refresh
  - INTEGER type safety for yearlyUsage column
  - Transactional yearlyUsage update on dispatch creation

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18+ with TypeScript
- Vite as build tool and development server
- Wouter for client-side routing
- TanStack Query (React Query) for server state management
- Shadcn/ui component library with Radix UI primitives
- Tailwind CSS for styling with custom design system

**Design System:**
- Hybrid approach: Material Design 3-inspired for dashboards, SaaS marketing style for landing pages
- Custom typography using Inter (primary) and JetBrains Mono (technical codes)
- Comprehensive spacing system based on Tailwind units
- Responsive breakpoints: mobile (<640px), tablet (640-1024px), desktop (>1024px)
- Dark mode support with theme toggle

**Key Frontend Patterns:**
- Component-driven architecture with reusable UI primitives
- Context-based authentication state management
- Custom hooks for mobile detection and toast notifications
- Offline-first PWA capabilities for NFC module

### Backend Architecture

**Technology Stack:**
- Node.js with Express.js
- TypeScript for type safety
- Drizzle ORM for database interactions
- PostgreSQL via Neon serverless
- bcrypt.js for password hashing
- Session-based authentication

**API Design:**
- RESTful API structure
- Centralized route registration in `server/routes.ts`
- Storage layer abstraction via `server/storage.ts` interface
- Request/response logging middleware
- JSON-based communication

**Key Backend Patterns:**
- Repository pattern through storage interface
- Separation of concerns: routes → storage → database
- Type-safe schema definitions shared between client and server
- Error handling with appropriate HTTP status codes

### Data Storage

**Database: PostgreSQL (Neon Serverless)**

**Schema Design:**
- Role-based access control with 15 distinct roles (from proveedor to consultor_externo)
- Multi-tenant architecture with company isolation
- Comprehensive certification workflow tracking (10 phases: solicitud_inicial → publicación)
- Three-tier evaluation system: documentales, operativos, valor_agregado

**Core Entities:**
- `users`: Authentication and role management
- `companies`: Providers and mining companies with ESG metrics
- `cps`: Product codes with packaging details (level, weight, material composition)
- `dispatches`: Packaging dispatch records with NFC integration and total weight tracking
- `dispatch_materials`: Material breakdown per dispatch (papel_carton, plasticos, vidrio, metales, etc.)
- `certifications`: 10-phase workflow with SLA tracking
- `certificationPhases`: Timeline and completion tracking per phase
- `dispatches`: Packaging dispatch records with NFC integration
- `evaluationCriteria`: 100-point evaluation matrix
- `evaluationResults`: Certification scoring per criterion
- `providerMetrics`: Historical ESG performance data

**Key Design Decisions:**
- Enum-based type safety for roles, statuses, and categories
- Decimal precision for ESG scores and CO2 footprint
- JSONB for flexible metadata storage
- Timestamps for audit trails

### Authentication & Authorization

**Authentication:**
- Username/password with bcrypt hashing
- Session-based approach with localStorage persistence
- Company-scoped user context

**Authorization:**
- 15 granular roles from basic provider to external consultant
- Role-based feature access (e.g., NFC module only for certified providers)
- CPS (Coordinador de Procesos y Servicios) for initial evaluation workflow
- Hierarchical permissions for certification advancement

### Key Architectural Decisions

**1. Monorepo Structure**
- **Decision**: Shared schema between client and server via `@shared` alias
- **Rationale**: Type safety across full stack, single source of truth for data models
- **Trade-off**: Tighter coupling, but worth it for small team velocity

**2. Drizzle ORM over Prisma**
- **Decision**: Use Drizzle with PostgreSQL dialect
- **Rationale**: Lightweight, SQL-like syntax, better TypeScript inference
- **Alternative**: Prisma was considered but Drizzle provides more control

**3. Vite for Build Tooling**
- **Decision**: Vite instead of Create React App or Next.js
- **Rationale**: Fast HMR, simple SSR setup for production, modern ES modules
- **Trade-off**: Custom server setup required but provides flexibility

**4. Component Library Approach**
- **Decision**: Shadcn/ui (copy-paste components) over full UI framework
- **Rationale**: Full customization control, no runtime dependency, aligns with design system
- **Alternative**: Material-UI or Ant Design were considered but too opinionated

**5. 10-Phase Certification Workflow**
- **Decision**: Rigid sequential workflow with SLA tracking per phase
- **Rationale**: Regulatory compliance requires audit trail and standardization
- **Implementation**: Phase advancement requires explicit approval, delayed phases flagged

**6. Offline-First NFC Module**
- **Decision**: IndexedDB cache with sync queue for NFC operations
- **Rationale**: Factory floors often have poor connectivity; can't lose packaging data
- **Trade-off**: Complexity in conflict resolution, but critical for reliability

**7. Three-Tier Evaluation System**
- **Decision**: Split 100-point evaluation into documentales/operativos/valor_agregado
- **Rationale**: Regulatory requirements (60 pts base) + competitive differentiation (40 pts value-add)
- **Implementation**: Each tier has weighted criteria, total must reach threshold for approval

## External Dependencies

### Third-Party Services

**Database:**
- Neon Serverless PostgreSQL - Managed PostgreSQL with WebSocket support for serverless environments

**Authentication:**
- bcrypt.js - Password hashing (no external auth service currently)

**Development Tools:**
- Replit specific: vite-plugin-runtime-error-modal, vite-plugin-cartographer, vite-plugin-dev-banner

### Key NPM Packages

**UI & Styling:**
- @radix-ui/* - Headless accessible UI primitives (20+ components)
- tailwindcss - Utility-first CSS framework
- class-variance-authority - Type-safe component variants
- lucide-react - Icon library

**Data & State:**
- @tanstack/react-query - Server state management
- drizzle-orm - TypeScript ORM
- @neondatabase/serverless - Neon database driver
- zod - Schema validation (via drizzle-zod)

**Forms & Validation:**
- react-hook-form - Form state management
- @hookform/resolvers - Validation resolver integration

**Charts & Visualization:**
- recharts - Composable charting library for ESG dashboards

**Build & Dev:**
- vite - Build tool and dev server
- tsx - TypeScript execution for development
- esbuild - Production bundler

**Routing:**
- wouter - Lightweight client-side router (alternative to React Router)

### Planned Integrations

**Document Management:**
- OpenKM - DMS for certification PDFs and evidence storage (webhooks for indexing)

**Digital Signatures:**
- FEA SDK - Chilean electronic signature for legal documents (optional blockchain anchoring)

**Cloud Storage:**
- S3/MinIO - Photo and balanza ticket storage for dispatch verification

**NFC Technology:**
- Web NFC API - Browser-based NFC tag reading/writing for packaging traceability

**Blockchain:**
- Polygon testnet - Optional hash anchoring for immutable audit trail