import { db } from "./db";
import { users, companies } from "@shared/schema";
import bcrypt from "bcryptjs";

/**
 * Script para crear cuentas demo de todos los roles
 * Ejecutar con: npx tsx server/seed-demo.ts
 */

async function seedDemoAccounts() {
  console.log("🌱 Creando cuentas demo...\n");

  // Crear empresas demo
  const [proveedorCompany] = await db.insert(companies).values({
    name: "Proveedor Demo S.A.",
    rut: "76.123.456-7",
    type: "proveedor",
    contactEmail: "proveedor@demo.cl",
    contactPhone: "+56912345678",
    annualLimit: 300,
    yearlyUsage: 150000, // 150kg usados de 300kg
  }).returning().onConflictDoNothing();

  const [mineraCompany] = await db.insert(companies).values({
    name: "Minera Demo Corp",
    rut: "96.987.654-3",
    type: "minera",
    contactEmail: "minera@demo.cl",
    contactPhone: "+56987654321",
    esgScore: 75,
    co2Footprint: "12500.50",
    copperMarkCertified: true,
  }).returning().onConflictDoNothing();

  // Hash de contraseña demo (todas usan "demo123")
  const hashedPassword = await bcrypt.hash("demo123", 10);

  // Crear usuarios demo para cada rol
  const demoUsers = [
    {
      username: "admin",
      password: hashedPassword,
      email: "admin@sicrep.cl",
      role: "admin" as const,
      companyId: null,
    },
    {
      username: "proveedor",
      password: hashedPassword,
      email: "proveedor@demo.cl",
      role: "proveedor" as const,
      companyId: proveedorCompany?.id,
    },
    {
      username: "minera",
      password: hashedPassword,
      email: "minera@demo.cl",
      role: "empresa_minera" as const,
      companyId: mineraCompany?.id,
    },
    {
      username: "cps",
      password: hashedPassword,
      email: "cps@sicrep.cl",
      role: "cps" as const,
      companyId: null,
    },
    {
      username: "evaluador",
      password: hashedPassword,
      email: "evaluador@sicrep.cl",
      role: "evaluador" as const,
      companyId: null,
    },
    {
      username: "auditor",
      password: hashedPassword,
      email: "auditor@sicrep.cl",
      role: "auditor" as const,
      companyId: null,
    },
    {
      username: "certificador",
      password: hashedPassword,
      email: "certificador@sicrep.cl",
      role: "certificador" as const,
      companyId: null,
    },
    {
      username: "inspector",
      password: hashedPassword,
      email: "inspector@sicrep.cl",
      role: "inspector" as const,
      companyId: null,
    },
    {
      username: "analista_esg",
      password: hashedPassword,
      email: "esg@sicrep.cl",
      role: "analista_esg" as const,
      companyId: null,
    },
    {
      username: "especialista_nfc",
      password: hashedPassword,
      email: "nfc@sicrep.cl",
      role: "especialista_nfc" as const,
      companyId: null,
    },
    {
      username: "vendedor",
      password: hashedPassword,
      email: "ventas@sicrep.cl",
      role: "vendedor" as const,
      companyId: null,
    },
    {
      username: "comite",
      password: hashedPassword,
      email: "comite@sicrep.cl",
      role: "miembro_comite" as const,
      companyId: null,
    },
  ];

  for (const user of demoUsers) {
    await db.insert(users).values(user).onConflictDoNothing();
  }

  console.log("✅ Cuentas demo creadas exitosamente!\n");
  console.log("═".repeat(60));
  console.log("📋 CREDENCIALES DEMO - SICREP");
  console.log("═".repeat(60));
  console.log("\n🔐 Contraseña para todas: demo123\n");
  
  console.log("👥 ROLES ADMINISTRATIVOS:");
  console.log("  • admin@sicrep.cl          → Admin (gestión total)");
  console.log("  • cps@sicrep.cl            → CPS (evaluación inicial)");
  console.log("  • certificador@sicrep.cl   → Certificador (emisión)");
  console.log("  • auditor@sicrep.cl        → Auditor (compliance)");
  
  console.log("\n🏭 ROLES EVALUACIÓN:");
  console.log("  • evaluador@sicrep.cl      → Evaluador (terreno)");
  console.log("  • inspector@sicrep.cl      → Inspector (verificación)");
  console.log("  • comite@sicrep.cl         → Comité (votaciones)");
  
  console.log("\n🏢 ROLES EMPRESARIALES:");
  console.log("  • proveedor@demo.cl        → Proveedor (despachos/NFC)");
  console.log("  • minera@demo.cl           → Minera (ESG/proveedores)");
  console.log("  • ventas@sicrep.cl         → Vendedor (comercial)");
  
  console.log("\n🔬 ROLES ESPECIALIZADOS:");
  console.log("  • esg@sicrep.cl            → Analista ESG");
  console.log("  • nfc@sicrep.cl            → Especialista NFC");
  
  console.log("\n" + "═".repeat(60));
  console.log(`✨ Total: ${demoUsers.length} cuentas demo`);
  console.log("═".repeat(60) + "\n");
}

seedDemoAccounts()
  .then(() => {
    console.log("🎉 Seed completado");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Error:", error);
    process.exit(1);
  });
