import type { Express } from "express";
import { storage } from "./storage";
import { db } from "./db";
import { companies, dispatches } from "@shared/schema";
import { eq, and, sql, inArray } from "drizzle-orm";
import { 
  insertDispatchSchema, 
  insertCertificationSchema, 
  insertEvaluationResultSchema,
  insertCPSSchema,
  insertDispatchMaterialSchema
} from "@shared/schema";
import bcrypt from "bcryptjs";
import { 
  generatePDFFromHTML, 
  getCertificadoREPTemplate, 
  getReporteAuditoriaTemplate,
  getReporteESGTemplate 
} from "./pdf-generator";
// TODO: Implementar sessions/JWT para habilitar middleware backend
// import { requireRole } from "./middleware/auth";

export function registerRoutes(app: Express) {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username y password son requeridos" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: "Credenciales inválidas" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: "Credenciales inválidas" });
      }

      // Get company data if user has one
      let company = null;
      if (user.companyId) {
        company = await storage.getCompany(user.companyId);
      }

      // Don't send password to client
      const { password: _, ...userWithoutPassword } = user;

      res.json({
        user: userWithoutPassword,
        company
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/:companyId", async (req, res) => {
    try {
      const { companyId } = req.params;
      const stats = await storage.getDashboardStats(companyId);
      
      if (!stats) {
        return res.status(404).json({ error: "Empresa no encontrada" });
      }

      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Mining company stats route
  app.get("/api/mining/stats/:companyId", async (req, res) => {
    try {
      const company = await storage.getCompany(req.params.companyId);
      if (!company || company.type !== "minera") {
        return res.status(403).json({ error: "Acceso denegado: solo empresas mineras" });
      }

      // Get only providers associated with this mining company
      const providers = await db.select().from(companies)
        .where(and(
          eq(companies.type, 'proveedor'),
          eq(companies.miningCompanyId, req.params.companyId)
        ));
      
      const providerIds = providers.map(p => p.id);
      
      const totalDispatches = providerIds.length > 0 
        ? await db.select({ count: sql<number>`count(*)`.as('count') })
            .from(dispatches)
            .where(inArray(dispatches.companyId, providerIds))
        : [{ count: 0 }];

      const totalWeight = providerIds.length > 0
        ? await db.select({ sum: sql<number>`sum(${dispatches.totalWeight})`.as('sum') })
            .from(dispatches)
            .where(inArray(dispatches.companyId, providerIds))
        : [{ sum: 0 }];

      const currentMonth = new Date().getMonth() + 1;
      const currentYear = new Date().getFullYear();

      const activeProviders = providerIds.length > 0
        ? await db.select({ count: sql<number>`count(DISTINCT ${dispatches.companyId})`.as('count') })
            .from(dispatches)
            .where(
              and(
                inArray(dispatches.companyId, providerIds),
                sql`EXTRACT(MONTH FROM ${dispatches.dispatchDate}) = ${currentMonth}`,
                sql`EXTRACT(YEAR FROM ${dispatches.dispatchDate}) = ${currentYear}`
              )
            )
        : [{ count: 0 }];

      const totalProviders = providers.length;
      const averageESG = totalProviders > 0
        ? Math.round(providers.reduce((sum, p) => sum + (p.esgScore || 0), 0) / totalProviders)
        : 0;

      const approvedProviders = providers.filter(p => (p.esgScore || 0) >= 70).length;
      const warningProviders = providers.filter(p => (p.esgScore || 0) >= 40 && (p.esgScore || 0) < 70).length;
      const rejectedProviders = providers.filter(p => (p.esgScore || 0) < 40).length;

      res.json({
        totalProviders,
        activeProviders: activeProviders[0]?.count || 0,
        averageESG,
        totalDispatches: totalDispatches[0]?.count || 0,
        totalWeight: totalWeight[0]?.sum || 0,
        approvedProviders,
        warningProviders,
        rejectedProviders
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Companies routes
  app.get("/api/companies", async (req, res) => {
    try {
      const companies = await storage.getAllCompanies();
      res.json(companies);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/companies/providers", async (req, res) => {
    try {
      const providers = await storage.getProviders();
      res.json(providers);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/companies/:id", async (req, res) => {
    try {
      const company = await storage.getCompany(req.params.id);
      if (!company) {
        return res.status(404).json({ error: "Empresa no encontrada" });
      }
      res.json(company);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Dispatches routes
  app.get("/api/dispatches", async (req, res) => {
    try {
      const { companyId } = req.query;
      const dispatches = await storage.getDispatches(companyId as string | undefined);
      res.json(dispatches);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/dispatches/:id", async (req, res) => {
    try {
      const dispatch = await storage.getDispatch(req.params.id);
      if (!dispatch) {
        return res.status(404).json({ error: "Despacho no encontrado" });
      }
      res.json(dispatch);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/dispatches", async (req, res) => {
    try {
      const validatedData = insertDispatchSchema.parse(req.body);
      
      // Check if company exists and has capacity
      const company = await storage.getCompany(validatedData.companyId);
      if (!company) {
        return res.status(404).json({ error: "Empresa no encontrada" });
      }

      // Convert totalWeight from grams to kg for limit check (yearlyUsage in grams)
      const weightInKg = (validatedData.totalWeight || 0) / 1000;
      const currentUsageKg = (company.yearlyUsage || 0) / 1000;
      const newUsage = currentUsageKg + weightInKg;
      if (newUsage > (company.annualLimit || 300)) {
        return res.status(400).json({ 
          error: "Límite anual excedido",
          current: currentUsageKg,
          limit: company.annualLimit,
          attempted: weightInKg
        });
      }

      const dispatch = await storage.createDispatch(validatedData);

      // Create dispatch materials breakdown if CPS is provided
      if (dispatch.cpsId) {
        const cpsMaterials = await storage.getCPSMaterials(dispatch.cpsId);
        for (const cpsMaterial of cpsMaterials) {
          const materialWeight = Math.round((dispatch.totalWeight * cpsMaterial.percentage) / 100);
          await storage.createDispatchMaterial({
            dispatchId: dispatch.id,
            material: cpsMaterial.material,
            weight: materialWeight,
            percentage: cpsMaterial.percentage
          });
        }
      }

      res.status(201).json(dispatch);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/dispatches/:id", async (req, res) => {
    try {
      const dispatch = await storage.updateDispatch(req.params.id, req.body);
      res.json(dispatch);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Certifications routes
  app.get("/api/certifications", async (req, res) => {
    try {
      const { companyId } = req.query;
      const certifications = await storage.getCertifications(companyId as string | undefined);
      res.json(certifications);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/certifications/:id", async (req, res) => {
    try {
      const certification = await storage.getCertification(req.params.id);
      if (!certification) {
        return res.status(404).json({ error: "Certificación no encontrada" });
      }
      res.json(certification);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/certifications", async (req, res) => {
    try {
      const validatedData = insertCertificationSchema.parse(req.body);
      const certification = await storage.createCertification(validatedData);
      res.status(201).json(certification);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/certifications/:id", async (req, res) => {
    try {
      const certification = await storage.updateCertification(req.params.id, req.body);
      res.json(certification);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Workflow routes
  app.post("/api/certifications/:id/advance", async (req, res) => {
    try {
      const { notes } = req.body;
      const certification = await storage.advanceCertificationPhase(req.params.id, notes);
      res.json(certification);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/certifications/:id/phases", async (req, res) => {
    try {
      const phases = await storage.getCertificationPhases(req.params.id);
      res.json(phases);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/certifications/:id/sla", async (req, res) => {
    try {
      const certification = await storage.getCertification(req.params.id);
      
      if (!certification) {
        return res.status(404).json({ error: "Certificación no encontrada" });
      }

      // Check if certification is finalized (in publicacion phase with finalStatus set)
      const isFinalized = certification.currentPhase === "publicacion" && certification.finalStatus;

      if (isFinalized) {
        // Return terminal state for finalized certifications
        res.json({
          isDelayed: false,
          daysPassed: 0,
          daysRemaining: 0,
          sla: 0,
          currentPhase: certification.currentPhase,
          isFinalized: true,
          finalStatus: certification.finalStatus
        });
      } else {
        // Normal SLA calculation for active certifications
        const isDelayed = await storage.checkSLAStatus(req.params.id);
        const now = new Date();
        const phaseStart = new Date(certification.phaseStartDate);
        const daysPassed = Math.floor((now.getTime() - phaseStart.getTime()) / (1000 * 60 * 60 * 24));
        const daysRemaining = certification.phaseSla - daysPassed;

        res.json({
          isDelayed,
          daysPassed,
          daysRemaining,
          sla: certification.phaseSla,
          currentPhase: certification.currentPhase,
          isFinalized: false
        });
      }
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Evaluation routes
  app.get("/api/evaluation/criteria", async (req, res) => {
    try {
      const criteria = await storage.getEvaluationCriteria();
      res.json(criteria);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/evaluation/results/:certificationId", async (req, res) => {
    try {
      const results = await storage.getEvaluationResults(req.params.certificationId);
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/evaluation/results", async (req, res) => {
    try {
      const validatedData = insertEvaluationResultSchema.parse(req.body);
      const result = await storage.saveEvaluationResult(validatedData);
      
      // Recalculate certification score
      const allResults = await storage.getEvaluationResults(validatedData.certificationId);
      const criteria = await storage.getEvaluationCriteria();
      
      let documentalScore = 0;
      let operationalScore = 0;
      let valueAddedScore = 0;

      for (const res of allResults) {
        const criterion = criteria.find(c => c.id === res.criterionId);
        if (criterion && res.passed) {
          if (criterion.category === "documentales") {
            documentalScore += res.pointsAwarded || 0;
          } else if (criterion.category === "operativos") {
            operationalScore += res.pointsAwarded || 0;
          } else if (criterion.category === "valor_agregado") {
            valueAddedScore += res.pointsAwarded || 0;
          }
        }
      }

      const totalScore = documentalScore + operationalScore + valueAddedScore;

      await storage.updateCertification(validatedData.certificationId, {
        documentalScore,
        operationalScore,
        valueAddedScore,
        totalScore
      });

      res.json(result);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Provider metrics routes
  app.get("/api/metrics/providers", async (req, res) => {
    try {
      const { companyId } = req.query;
      const metrics = await storage.getProviderMetrics(companyId as string | undefined);
      res.json(metrics);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Provider ranking with companies data
  app.get("/api/providers/ranking", async (req, res) => {
    try {
      const { miningCompanyId } = req.query;
      
      let providers;
      if (miningCompanyId) {
        providers = await db.select().from(companies)
          .where(and(
            eq(companies.type, 'proveedor'),
            eq(companies.miningCompanyId, miningCompanyId as string)
          ));
      } else {
        providers = await storage.getProviders();
      }
      const metrics = await storage.getProviderMetrics();
      
      // Group metrics by company
      const metricsMap = new Map();
      for (const metric of metrics) {
        if (!metricsMap.has(metric.companyId)) {
          metricsMap.set(metric.companyId, []);
        }
        metricsMap.get(metric.companyId).push(metric);
      }

      // Combine provider data with latest metrics
      const ranking = providers.map(provider => {
        const providerMetrics = metricsMap.get(provider.id) || [];
        const latestMetric = providerMetrics[0]; // Already sorted by date desc

        return {
          id: provider.id,
          name: provider.name,
          rut: provider.rut,
          esgScore: latestMetric?.esgScore || provider.esgScore || 0,
          trend: latestMetric?.trend || 0,
          co2Footprint: provider.co2Footprint || "0",
          seal: latestMetric?.seal || "warning",
          risk: latestMetric?.risk || "medium"
        };
      });

      // Sort by ESG score descending
      ranking.sort((a, b) => b.esgScore - a.esgScore);

      res.json(ranking);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Historical metrics for ESG trends
  app.get("/api/metrics/history/:companyId", async (req, res) => {
    try {
      const { companyId } = req.params;
      const { months = 6 } = req.query;
      
      const metrics = await storage.getProviderMetrics(companyId);
      
      // Limit to requested number of months and reverse for chronological order
      const limitedMetrics = metrics.slice(0, Number(months)).reverse();
      
      res.json(limitedMetrics);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // CPS (Código Producto SICREP) routes
  app.get("/api/cps", async (req, res) => {
    try {
      const { companyId } = req.query;
      const cpsRecords = await storage.getAllCPS(companyId as string | undefined);
      res.json(cpsRecords);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/cps/:id", async (req, res) => {
    try {
      const cpsRecord = await storage.getCPS(req.params.id);
      if (!cpsRecord) {
        return res.status(404).json({ error: "Código CPS no encontrado" });
      }
      res.json(cpsRecord);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/cps/code/:code", async (req, res) => {
    try {
      const cpsRecord = await storage.getCPSByCode(req.params.code);
      if (!cpsRecord) {
        return res.status(404).json({ error: "Código CPS no encontrado" });
      }
      res.json(cpsRecord);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/cps", async (req, res) => {
    try {
      const validatedData = insertCPSSchema.parse(req.body);
      const cpsRecord = await storage.createCPS(validatedData);
      res.status(201).json(cpsRecord);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/cps/:id", async (req, res) => {
    try {
      const cpsRecord = await storage.updateCPS(req.params.id, req.body);
      res.json(cpsRecord);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Dispatch Materials routes
  app.get("/api/dispatches/:dispatchId/materials", async (req, res) => {
    try {
      const materials = await storage.getDispatchMaterials(req.params.dispatchId);
      res.json(materials);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/dispatch-materials", async (req, res) => {
    try {
      const validatedData = insertDispatchMaterialSchema.parse(req.body);
      const material = await storage.createDispatchMaterial(validatedData);
      res.status(201).json(material);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ==================== ADMIN ROUTES ====================
  
  // Admin Dashboard Stats
  // TODO: Re-enable requireRole("admin") after implementing sessions
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Users Management
  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/admin/users", async (req, res) => {
    try {
      const user = await storage.createUser(req.body);
      res.status(201).json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/admin/users/:id", async (req, res) => {
    try {
      const user = await storage.updateUser(req.params.id, req.body);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/admin/users/:id", async (req, res) => {
    try {
      await storage.deleteUser(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Companies Management
  app.post("/api/admin/companies", async (req, res) => {
    try {
      const company = await storage.createCompany(req.body);
      res.status(201).json(company);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/admin/companies/:id", async (req, res) => {
    try {
      const company = await storage.updateCompany(req.params.id, req.body);
      res.json(company);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Payment Requests Management
  app.get("/api/admin/payments", async (req, res) => {
    try {
      const payments = await storage.getAllPaymentRequests();
      res.json(payments);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/admin/payments", async (req, res) => {
    try {
      const payment = await storage.createPaymentRequest(req.body);
      res.status(201).json(payment);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/admin/payments/:id/confirm", async (req, res) => {
    try {
      const { confirmedBy } = req.body;
      const payment = await storage.confirmPayment(req.params.id, confirmedBy);
      res.json(payment);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Certifier Assignments Management
  app.get("/api/admin/assignments", async (req, res) => {
    try {
      const assignments = await storage.getAllCertifierAssignments();
      res.json(assignments);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/admin/assignments", async (req, res) => {
    try {
      const assignment = await storage.createCertifierAssignment(req.body);
      res.status(201).json(assignment);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/admin/assignments/:id", async (req, res) => {
    try {
      const assignment = await storage.updateCertifierAssignment(req.params.id, req.body);
      res.json(assignment);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Certifiers Workload (for auto-assignment)
  app.get("/api/admin/certifiers/workload", async (req, res) => {
    try {
      const { role } = req.query;
      const workload = await storage.getCertifiersWorkload(role as string);
      res.json(workload);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // PDF Generation Routes
  app.get("/api/reports/certificado/:certificationId", async (req, res) => {
    try {
      const certification = await storage.getCertification(req.params.certificationId);
      if (!certification) {
        return res.status(404).json({ error: "Certificación no encontrada" });
      }

      const company = await storage.getCompany(certification.companyId);
      if (!company) {
        return res.status(404).json({ error: "Empresa no encontrada" });
      }

      const html = getCertificadoREPTemplate({
        companyName: company.name,
        companyRut: company.rut,
        certificationId: certification.id,
        issueDate: certification.createdAt.toISOString(),
        validUntil: new Date(certification.createdAt.getTime() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        totalScore: certification.totalScore || 0,
        documentalScore: certification.documentalScore || 0,
        operativosScore: certification.operationalScore || 0,
        valorAgregadoScore: certification.valueAddedScore || 0,
        evaluator: "Sistema SICREP",
        auditor: "Auditor Certificado",
        certificador: "Certificador Oficial SICREP"
      });

      const pdf = await generatePDFFromHTML(html);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="Certificado-REP-${certification.id}.pdf"`);
      res.send(pdf);
    } catch (error: any) {
      console.error('Error generando PDF certificado:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/reports/auditoria/:certificationId", async (req, res) => {
    try {
      const certification = await storage.getCertification(req.params.certificationId);
      if (!certification) {
        return res.status(404).json({ error: "Certificación no encontrada" });
      }

      const company = await storage.getCompany(certification.companyId);
      if (!company) {
        return res.status(404).json({ error: "Empresa no encontrada" });
      }

      const evaluationResults = await storage.getEvaluationResults(req.params.certificationId);
      
      const findings = evaluationResults.map(result => ({
        category: result.criterionId || 'General',
        description: `Evaluación de criterio con puntaje ${result.pointsAwarded || 0}`,
        severity: (result.pointsAwarded || 0) >= 80 ? 'Menor' as const : (result.pointsAwarded || 0) >= 50 ? 'Mayor' as const : 'Crítico' as const,
        status: (result.pointsAwarded || 0) >= 60 ? 'Resuelto' : 'Pendiente'
      }));

      const html = getReporteAuditoriaTemplate({
        companyName: company.name,
        companyRut: company.rut,
        auditDate: certification.createdAt.toISOString(),
        auditor: "Auditor Certificado SICREP",
        certificationId: certification.id,
        findings: findings.length > 0 ? findings : [
          {
            category: "Documentación",
            description: "Revisión de documentación técnica completa",
            severity: "Menor",
            status: "Resuelto"
          },
          {
            category: "Operaciones",
            description: "Inspección de procesos operativos",
            severity: "Menor",
            status: "Resuelto"
          }
        ],
        conclusion: `La empresa ${company.name} ha sido auditada de acuerdo a los estándares REP establecidos en la Ley 20.920. Se ha verificado el cumplimiento de los requisitos documentales y operativos necesarios para la certificación.`,
        recommendations: [
          "Mantener actualizada la documentación técnica de procesos",
          "Continuar con el seguimiento de indicadores de desempeño ambiental",
          "Implementar mejoras continuas en los procesos de gestión de residuos"
        ]
      });

      const pdf = await generatePDFFromHTML(html);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="Reporte-Auditoria-${certification.id}.pdf"`);
      res.send(pdf);
    } catch (error: any) {
      console.error('Error generando PDF auditoría:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/reports/esg/:companyId", async (req, res) => {
    try {
      const company = await storage.getCompany(req.params.companyId);
      if (!company) {
        return res.status(404).json({ error: "Empresa no encontrada" });
      }

      const html = getReporteESGTemplate({
        companyName: company.name,
        companyRut: company.rut,
        reportDate: new Date().toISOString(),
        esgScore: company.esgScore || 0,
        co2Footprint: company.co2Footprint?.toString() || "0.00",
        copperMarkCertified: company.copperMarkCertified || false,
        governanceScore: Math.round((company.esgScore || 0) * 0.35),
        socialScore: Math.round((company.esgScore || 0) * 0.35),
        environmentalScore: Math.round((company.esgScore || 0) * 0.30),
        metrics: [
          { name: "Emisiones CO₂ Total", value: `${company.co2Footprint || 0} tCO₂e`, trend: "down" },
          { name: "Residuos Reciclados", value: `${Math.round((company.yearlyUsage || 0) / 1000)} kg`, trend: "up" },
          { name: "Cumplimiento Normativo", value: "95%", trend: "stable" },
          { name: "Capacitación Personal", value: "100%", trend: "up" },
          { name: "Auditorías Superadas", value: "8/8", trend: "stable" }
        ]
      });

      const pdf = await generatePDFFromHTML(html);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="Reporte-ESG-${company.name}.pdf"`);
      res.send(pdf);
    } catch (error: any) {
      console.error('Error generando PDF ESG:', error);
      res.status(500).json({ error: error.message });
    }
  });
}
