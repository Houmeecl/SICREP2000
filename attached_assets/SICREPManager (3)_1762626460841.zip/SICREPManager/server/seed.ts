import { db } from "./db";
import { 
  users, 
  companies, 
  dispatches, 
  certifications,
  certificationPhases,
  evaluationCriteria,
  evaluationResults,
  providerMetrics
} from "@shared/schema";
import bcrypt from "bcryptjs";

async function seed() {
  console.log("🌱 Seeding database...");

  // Clear existing data
  await db.delete(evaluationResults);
  await db.delete(certificationPhases);
  await db.delete(certifications);
  await db.delete(dispatches);
  await db.delete(providerMetrics);
  await db.delete(evaluationCriteria);
  await db.delete(users);
  await db.delete(companies);

  // Create companies
  const [mineraCodelco] = await db.insert(companies).values({
    name: "Minera Codelco",
    rut: "76.123.456-7",
    type: "minera",
    address: "Av. Libertador Bernardo O'Higgins 1234, Santiago",
    contactEmail: "contacto@codelco.cl",
    contactPhone: "+56 2 2690 3000",
    esgScore: 85,
    co2Footprint: "125000.50",
    annualLimit: 50000,
    currentYear: 2024,
    yearlyUsage: 12500
  }).returning();

  const [ecoRecicla] = await db.insert(companies).values({
    name: "EcoRecicla SpA",
    rut: "76.543.210-K",
    type: "proveedor",
    address: "Calle Principal 789, Antofagasta",
    contactEmail: "info@ecorecicla.cl",
    contactPhone: "+56 55 2345 678",
    esgScore: 92,
    co2Footprint: "12.5",
    annualLimit: 300,
    currentYear: 2024,
    yearlyUsage: 247
  }).returning();

  const [recuperaChile] = await db.insert(companies).values({
    name: "RecuperaChile Ltda",
    rut: "77.234.567-8",
    type: "proveedor",
    address: "Pasaje Comercio 456, Valparaíso",
    contactEmail: "contacto@recuperachile.cl",
    contactPhone: "+56 32 2876 543",
    esgScore: 78,
    co2Footprint: "18.3",
    annualLimit: 300,
    currentYear: 2024,
    yearlyUsage: 215
  }).returning();

  const [verdeSur] = await db.insert(companies).values({
    name: "VerdeSur SA",
    rut: "78.901.234-5",
    type: "proveedor",
    address: "Av. Sustentable 321, Concepción",
    contactEmail: "admin@verdesur.cl",
    contactPhone: "+56 41 2234 567",
    esgScore: 65,
    co2Footprint: "24.1",
    annualLimit: 300,
    currentYear: 2024,
    yearlyUsage: 255
  }).returning();

  // Create users
  const hashedPassword = await bcrypt.hash("password123", 10);

  const [adminUser] = await db.insert(users).values({
    username: "admin",
    email: "admin@sicrep.cl",
    password: hashedPassword,
    role: "admin_sicrep"
  }).returning();

  const [proveedorUser] = await db.insert(users).values({
    username: "ecorecicla",
    email: "usuario@ecorecicla.cl",
    password: hashedPassword,
    role: "proveedor",
    companyId: ecoRecicla.id
  }).returning();

  const [mineraUser] = await db.insert(users).values({
    username: "codelco",
    email: "usuario@codelco.cl",
    password: hashedPassword,
    role: "empresa_minera",
    companyId: mineraCodelco.id
  }).returning();

  const [auditorUser] = await db.insert(users).values({
    username: "auditor1",
    email: "auditor@sicrep.cl",
    password: hashedPassword,
    role: "auditor"
  }).returning();

  // Create evaluation criteria
  const criteriaDocumentales = await db.insert(evaluationCriteria).values([
    {
      category: "documentales",
      name: "Certificado de inscripción REP vigente",
      description: "Documento oficial de registro en el sistema REP",
      maxPoints: 10
    },
    {
      category: "documentales",
      name: "Plan de gestión de residuos aprobado",
      description: "Plan detallado de manejo de residuos certificado",
      maxPoints: 10
    },
    {
      category: "documentales",
      name: "Informe de cumplimiento anual",
      description: "Reporte anual de cumplimiento normativo",
      maxPoints: 10
    },
    {
      category: "documentales",
      name: "Registro de trazabilidad completo",
      description: "Sistema de trazabilidad con registros históricos",
      maxPoints: 10
    }
  ]).returning();

  const criteriaOperativos = await db.insert(evaluationCriteria).values([
    {
      category: "operativos",
      name: "Instalaciones de almacenamiento adecuadas",
      description: "Infraestructura apropiada para almacenamiento de residuos",
      maxPoints: 15
    },
    {
      category: "operativos",
      name: "Procesos de segregación implementados",
      description: "Sistemas operativos de separación de materiales",
      maxPoints: 15
    },
    {
      category: "operativos",
      name: "Personal capacitado certificado",
      description: "Equipo de trabajo con certificaciones vigentes",
      maxPoints: 10
    }
  ]).returning();

  const criteriaValor = await db.insert(evaluationCriteria).values([
    {
      category: "valor_agregado",
      name: "Innovación en reciclaje",
      description: "Implementación de tecnologías innovadoras",
      maxPoints: 10
    },
    {
      category: "valor_agregado",
      name: "Certificaciones ambientales adicionales",
      description: "Certificaciones ISO u otras normativas ambientales",
      maxPoints: 10
    }
  ]).returning();

  // Create certifications
  const [cert1] = await db.insert(certifications).values({
    code: "CPS-C-001",
    companyId: ecoRecicla.id,
    currentPhase: "inspeccion_terreno",
    phaseStartDate: new Date("2024-01-15"),
    phaseSla: 10,
    isDelayed: false,
    totalScore: 30,
    documentalScore: 20,
    operationalScore: 10,
    valueAddedScore: 0
  }).returning();

  // Create certification phases for cert1
  await db.insert(certificationPhases).values([
    {
      certificationId: cert1.id,
      phase: "solicitud_inicial",
      startDate: new Date("2024-01-01"),
      endDate: new Date("2024-01-02"),
      sla: 2,
      completed: true,
      delayed: false,
      notes: "Solicitud recibida y validada"
    },
    {
      certificationId: cert1.id,
      phase: "revision_documentacion",
      startDate: new Date("2024-01-03"),
      endDate: new Date("2024-01-10"),
      sla: 5,
      completed: true,
      delayed: false,
      notes: "Documentación completa y aprobada"
    },
    {
      certificationId: cert1.id,
      phase: "inspeccion_terreno",
      startDate: new Date("2024-01-15"),
      endDate: null,
      sla: 10,
      completed: false,
      delayed: false,
      notes: "Inspección programada para el 2024-01-22"
    }
  ]);

  // Create evaluation results for cert1
  await db.insert(evaluationResults).values([
    {
      certificationId: cert1.id,
      criterionId: criteriaDocumentales[0].id,
      passed: true,
      pointsAwarded: 10,
      evaluatorId: auditorUser.id,
      notes: "Certificado vigente hasta 2025"
    },
    {
      certificationId: cert1.id,
      criterionId: criteriaDocumentales[1].id,
      passed: true,
      pointsAwarded: 10,
      evaluatorId: auditorUser.id,
      notes: "Plan aprobado por autoridad competente"
    },
    {
      certificationId: cert1.id,
      criterionId: criteriaDocumentales[2].id,
      passed: false,
      pointsAwarded: 0,
      evaluatorId: auditorUser.id,
      notes: "Pendiente de presentación"
    },
    {
      certificationId: cert1.id,
      criterionId: criteriaDocumentales[3].id,
      passed: true,
      pointsAwarded: 10,
      evaluatorId: auditorUser.id,
      notes: "Sistema de trazabilidad implementado"
    }
  ]);

  // Create dispatches
  const dispatchesData = [
    {
      companyId: ecoRecicla.id,
      nfcTag: "NFC-2024-ECO-001",
      weight: 85,
      material: "plastico",
      status: "certificado" as const,
      origin: "Planta EcoRecicla Antofagasta",
      destination: "Centro de Procesamiento Santiago",
      dispatchDate: new Date("2024-01-05"),
      receptionDate: new Date("2024-01-06"),
      certificationId: cert1.id
    },
    {
      companyId: ecoRecicla.id,
      nfcTag: "NFC-2024-ECO-002",
      weight: 62,
      material: "metal",
      status: "verificado" as const,
      origin: "Planta EcoRecicla Antofagasta",
      destination: "Fundición Valparaíso",
      dispatchDate: new Date("2024-01-10"),
      receptionDate: new Date("2024-01-11")
    },
    {
      companyId: ecoRecicla.id,
      nfcTag: "NFC-2024-ECO-003",
      weight: 45,
      material: "papel",
      status: "en_transito" as const,
      origin: "Planta EcoRecicla Antofagasta",
      destination: "Papelera Concepción",
      dispatchDate: new Date("2024-01-15")
    },
    {
      companyId: ecoRecicla.id,
      nfcTag: "NFC-2024-ECO-004",
      weight: 28,
      material: "vidrio",
      status: "registrado" as const,
      origin: "Planta EcoRecicla Antofagasta",
      destination: "Vidriera La Granja",
      dispatchDate: new Date("2024-01-18")
    }
  ];

  await db.insert(dispatches).values(dispatchesData);

  // Create provider metrics
  await db.insert(providerMetrics).values([
    {
      companyId: ecoRecicla.id,
      month: 1,
      year: 2024,
      totalDispatches: 15,
      totalWeight: 247,
      esgScore: 92,
      trend: 5,
      seal: "approved",
      risk: "low"
    },
    {
      companyId: recuperaChile.id,
      month: 1,
      year: 2024,
      totalDispatches: 12,
      totalWeight: 215,
      esgScore: 78,
      trend: -2,
      seal: "approved",
      risk: "medium"
    },
    {
      companyId: verdeSur.id,
      month: 1,
      year: 2024,
      totalDispatches: 18,
      totalWeight: 255,
      esgScore: 65,
      trend: 3,
      seal: "warning",
      risk: "medium"
    }
  ]);

  console.log("✅ Database seeded successfully!");
  console.log("\n📊 Credentials:");
  console.log("Admin: admin / password123");
  console.log("Proveedor: ecorecicla / password123");
  console.log("Minera: codelco / password123");
  console.log("Auditor: auditor1 / password123");
}

seed()
  .catch((error) => {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  })
  .finally(() => {
    process.exit(0);
  });
