import { db } from "./db";
import { 
  users, 
  companies,
  cps,
  cpsMaterials,
  dispatches,
  dispatchMaterials,
  certifications,
  certificationPhases,
  evaluationCriteria,
  evaluationResults,
  providerMetrics,
  paymentRequests,
  certifierAssignments,
  nfcTags,
  pesoMediciones,
  medicionMaterials,
  traceEvents,
  type User, 
  type InsertUser,
  type Company,
  type InsertCompany,
  type CPS,
  type InsertCPS,
  type CPSMaterial,
  type InsertCPSMaterial,
  type Dispatch,
  type InsertDispatch,
  type DispatchMaterial,
  type InsertDispatchMaterial,
  type Certification,
  type InsertCertification,
  type CertificationPhase,
  type InsertCertificationPhase,
  type EvaluationCriterion,
  type EvaluationResult,
  type InsertEvaluationResult,
  type ProviderMetric,
  type PaymentRequest,
  type InsertPaymentRequest,
  type CertifierAssignment,
  type InsertCertifierAssignment,
  type NfcTag,
  type InsertNfcTag,
  type PesoMedicion,
  type InsertPesoMedicion,
  type MedicionMaterial,
  type InsertMedicionMaterial,
  type TraceEvent,
  type InsertTraceEvent
} from "@shared/schema";
import { eq, and, desc, sql, gt, inArray, count } from "drizzle-orm";
import bcrypt from "bcryptjs";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Companies
  getCompany(id: string): Promise<Company | undefined>;
  getCompanyByRut(rut: string): Promise<Company | undefined>;
  getAllCompanies(): Promise<Company[]>;
  getProviders(): Promise<Company[]>;
  updateCompany(id: string, data: Partial<Company>): Promise<Company>;
  
  // CPS (Código Producto SICREP)
  getCPS(id: string): Promise<CPS | undefined>;
  getCPSByCode(code: string): Promise<CPS | undefined>;
  getAllCPS(companyId?: string): Promise<CPS[]>;
  createCPS(cpsData: InsertCPS): Promise<CPS>;
  updateCPS(id: string, data: Partial<CPS>): Promise<CPS>;
  
  // Dispatches
  getDispatch(id: string): Promise<Dispatch | undefined>;
  getDispatches(companyId?: string): Promise<Dispatch[]>;
  createDispatch(dispatch: InsertDispatch): Promise<Dispatch>;
  updateDispatch(id: string, data: Partial<Dispatch>): Promise<Dispatch>;
  
  // CPS Materials
  getCPSMaterials(cpsId: string): Promise<CPSMaterial[]>;
  createCPSMaterial(material: InsertCPSMaterial): Promise<CPSMaterial>;
  deleteCPSMaterials(cpsId: string): Promise<void>;
  
  // Dispatch Materials
  getDispatchMaterials(dispatchId: string): Promise<DispatchMaterial[]>;
  createDispatchMaterial(material: InsertDispatchMaterial): Promise<DispatchMaterial>;
  
  // Certifications
  getCertification(id: string): Promise<Certification | undefined>;
  getCertifications(companyId?: string): Promise<Certification[]>;
  createCertification(certification: InsertCertification): Promise<Certification>;
  updateCertification(id: string, data: Partial<Certification>): Promise<Certification>;
  advanceCertificationPhase(certificationId: string, notes?: string): Promise<Certification>;
  getCertificationPhases(certificationId: string): Promise<any[]>;
  checkSLAStatus(certificationId: string): Promise<boolean>;
  
  // Evaluation
  getEvaluationCriteria(): Promise<EvaluationCriterion[]>;
  getEvaluationResults(certificationId: string): Promise<EvaluationResult[]>;
  saveEvaluationResult(result: InsertEvaluationResult): Promise<EvaluationResult>;
  
  // Provider Metrics
  getProviderMetrics(companyId?: string): Promise<ProviderMetric[]>;
  
  // Dashboard stats
  getDashboardStats(companyId: string): Promise<any>;
  
  // Admin methods
  getAllUsers(): Promise<User[]>;
  updateUser(id: string, data: Partial<User>): Promise<User>;
  deleteUser(id: string): Promise<void>;
  createCompany(company: InsertCompany): Promise<Company>;
  getAllPaymentRequests(): Promise<any[]>;
  createPaymentRequest(payment: any): Promise<any>;
  confirmPayment(id: string, confirmedBy: string): Promise<any>;
  getAllCertifierAssignments(): Promise<any[]>;
  createCertifierAssignment(assignment: any): Promise<any>;
  updateCertifierAssignment(id: string, data: any): Promise<any>;
  getCertifiersWorkload(role?: string): Promise<any[]>;
  getAdminStats(): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Companies
  async getCompany(id: string): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company;
  }

  async getCompanyByRut(rut: string): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.rut, rut));
    return company;
  }

  async getAllCompanies(): Promise<Company[]> {
    return await db.select().from(companies);
  }

  async getProviders(): Promise<Company[]> {
    return await db.select().from(companies).where(eq(companies.type, "proveedor"));
  }

  async updateCompany(id: string, data: Partial<Company>): Promise<Company> {
    const [updated] = await db.update(companies)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(companies.id, id))
      .returning();
    return updated;
  }

  // CPS (Código Producto SICREP)
  async getCPS(id: string): Promise<CPS | undefined> {
    const [cpsRecord] = await db.select().from(cps).where(eq(cps.id, id));
    return cpsRecord;
  }

  async getCPSByCode(code: string): Promise<CPS | undefined> {
    const [cpsRecord] = await db.select().from(cps).where(eq(cps.code, code));
    return cpsRecord;
  }

  async getAllCPS(companyId?: string): Promise<CPS[]> {
    if (companyId) {
      return await db.select().from(cps)
        .where(and(eq(cps.companyId, companyId), eq(cps.isActive, true)))
        .orderBy(desc(cps.createdAt));
    }
    return await db.select().from(cps)
      .where(eq(cps.isActive, true))
      .orderBy(desc(cps.createdAt));
  }

  async createCPS(insertCPS: InsertCPS): Promise<CPS> {
    const [cpsRecord] = await db.insert(cps).values(insertCPS).returning();
    return cpsRecord;
  }

  async updateCPS(id: string, data: Partial<CPS>): Promise<CPS> {
    const [updated] = await db.update(cps)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(cps.id, id))
      .returning();
    return updated;
  }

  // Dispatches
  async getDispatch(id: string): Promise<Dispatch | undefined> {
    const [dispatch] = await db.select().from(dispatches).where(eq(dispatches.id, id));
    return dispatch;
  }

  async getDispatches(companyId?: string): Promise<Dispatch[]> {
    if (companyId) {
      return await db.select().from(dispatches)
        .where(eq(dispatches.companyId, companyId))
        .orderBy(desc(dispatches.dispatchDate));
    }
    return await db.select().from(dispatches).orderBy(desc(dispatches.dispatchDate));
  }

  async createDispatch(insertDispatch: InsertDispatch): Promise<Dispatch> {
    const [dispatch] = await db.insert(dispatches).values(insertDispatch).returning();
    
    // Update company yearly usage (both totalWeight and yearlyUsage in grams)
    if (dispatch.companyId && dispatch.totalWeight) {
      const company = await this.getCompany(dispatch.companyId);
      if (company) {
        await this.updateCompany(dispatch.companyId, {
          yearlyUsage: (company.yearlyUsage || 0) + dispatch.totalWeight
        });
      }
    }
    
    return dispatch;
  }

  async updateDispatch(id: string, data: Partial<Dispatch>): Promise<Dispatch> {
    const [updated] = await db.update(dispatches)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(dispatches.id, id))
      .returning();
    return updated;
  }

  // CPS Materials
  async getCPSMaterials(cpsId: string): Promise<CPSMaterial[]> {
    return await db.select().from(cpsMaterials).where(eq(cpsMaterials.cpsId, cpsId));
  }

  async createCPSMaterial(insertMaterial: InsertCPSMaterial): Promise<CPSMaterial> {
    const [material] = await db.insert(cpsMaterials).values(insertMaterial).returning();
    return material;
  }

  async deleteCPSMaterials(cpsId: string): Promise<void> {
    await db.delete(cpsMaterials).where(eq(cpsMaterials.cpsId, cpsId));
  }

  // Dispatch Materials
  async getDispatchMaterials(dispatchId: string): Promise<DispatchMaterial[]> {
    return await db.select().from(dispatchMaterials)
      .where(eq(dispatchMaterials.dispatchId, dispatchId));
  }

  async createDispatchMaterial(insertMaterial: InsertDispatchMaterial): Promise<DispatchMaterial> {
    const [material] = await db.insert(dispatchMaterials).values(insertMaterial).returning();
    return material;
  }

  // Certifications
  async getCertification(id: string): Promise<Certification | undefined> {
    const [certification] = await db.select().from(certifications).where(eq(certifications.id, id));
    return certification;
  }

  async getCertifications(companyId?: string): Promise<Certification[]> {
    if (companyId) {
      return await db.select().from(certifications)
        .where(eq(certifications.companyId, companyId))
        .orderBy(desc(certifications.createdAt));
    }
    return await db.select().from(certifications).orderBy(desc(certifications.createdAt));
  }

  async createCertification(insertCertification: InsertCertification): Promise<Certification> {
    const [certification] = await db.insert(certifications).values(insertCertification).returning();
    return certification;
  }

  async updateCertification(id: string, data: Partial<Certification>): Promise<Certification> {
    const [updated] = await db.update(certifications)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(certifications.id, id))
      .returning();
    return updated;
  }

  async advanceCertificationPhase(certificationId: string, notes?: string): Promise<Certification> {
    const certification = await this.getCertification(certificationId);
    if (!certification) {
      throw new Error("Certificación no encontrada");
    }

    // Phase progression map
    const phaseMap: Record<string, { next: string | null; sla: number }> = {
      "solicitud_inicial": { next: "revision_documentacion", sla: 3 },
      "revision_documentacion": { next: "inspeccion_terreno", sla: 5 },
      "inspeccion_terreno": { next: "evaluacion_tecnica", sla: 7 },
      "evaluacion_tecnica": { next: "informe_preliminar", sla: 5 },
      "informe_preliminar": { next: "correcciones", sla: 10 },
      "correcciones": { next: "revision_final", sla: 5 },
      "revision_final": { next: "aprobacion", sla: 3 },
      "aprobacion": { next: "emision_certificado", sla: 2 },
      "emision_certificado": { next: "publicacion", sla: 1 },
      "publicacion": { next: null, sla: 0 }
    };

    const currentPhase = certification.currentPhase;
    const phaseInfo = phaseMap[currentPhase];
    
    if (!phaseInfo) {
      throw new Error("Fase actual no válida");
    }

    // If already in final phase, cannot advance further
    if (phaseInfo.next === null) {
      throw new Error("La certificación ya está en la fase final y completada");
    }

    // Close current phase in history
    await db.update(certificationPhases)
      .set({ 
        endDate: new Date(),
        completed: true,
        notes
      })
      .where(and(
        eq(certificationPhases.certificationId, certificationId),
        eq(certificationPhases.phase, currentPhase),
        eq(certificationPhases.completed, false)
      ));

    // Get next phase info
    const nextPhaseSla = phaseMap[phaseInfo.next]?.sla || 0;
    const isNextPhaseFinal = phaseMap[phaseInfo.next]?.next === null;

    // Create new phase record
    const nowDate = new Date();
    const newPhaseData: InsertCertificationPhase = {
      certificationId,
      phase: phaseInfo.next as any,
      startDate: nowDate,
      sla: nextPhaseSla,
      completed: isNextPhaseFinal, // Auto-complete if final phase
      delayed: false,
      endDate: isNextPhaseFinal ? nowDate : null // Set endDate if final phase
    };
    
    await db.insert(certificationPhases).values(newPhaseData);

    // Update certification
    const updated = await this.updateCertification(certificationId, {
      currentPhase: phaseInfo.next as any,
      phaseStartDate: nowDate,
      phaseSla: nextPhaseSla,
      isDelayed: false,
      finalStatus: isNextPhaseFinal ? "aprobado" : certification.finalStatus
    });

    return updated;
  }

  async getCertificationPhases(certificationId: string): Promise<CertificationPhase[]> {
    return await db.select()
      .from(certificationPhases)
      .where(eq(certificationPhases.certificationId, certificationId))
      .orderBy(certificationPhases.startDate);
  }

  async checkSLAStatus(certificationId: string): Promise<boolean> {
    const certification = await this.getCertification(certificationId);
    if (!certification) return false;

    const now = new Date();
    const phaseStart = new Date(certification.phaseStartDate);
    const daysPassed = Math.floor((now.getTime() - phaseStart.getTime()) / (1000 * 60 * 60 * 24));
    
    const isDelayed = daysPassed > certification.phaseSla;

    // Update isDelayed flag if changed
    if (isDelayed !== certification.isDelayed) {
      await this.updateCertification(certificationId, { isDelayed });
      
      // Update phase record
      await db.update(certificationPhases)
        .set({ delayed: true })
        .where(and(
          eq(certificationPhases.certificationId, certificationId),
          eq(certificationPhases.phase, certification.currentPhase),
          eq(certificationPhases.completed, false)
        ));
    }

    return isDelayed;
  }

  // Evaluation
  async getEvaluationCriteria(): Promise<EvaluationCriterion[]> {
    return await db.select().from(evaluationCriteria).where(eq(evaluationCriteria.isActive, true));
  }

  async getEvaluationResults(certificationId: string): Promise<EvaluationResult[]> {
    return await db.select().from(evaluationResults)
      .where(eq(evaluationResults.certificationId, certificationId));
  }

  async saveEvaluationResult(result: InsertEvaluationResult): Promise<EvaluationResult> {
    // Check if result already exists
    const existing = await db.select().from(evaluationResults)
      .where(and(
        eq(evaluationResults.certificationId, result.certificationId),
        eq(evaluationResults.criterionId, result.criterionId)
      ));

    if (existing.length > 0) {
      // Update existing
      const [updated] = await db.update(evaluationResults)
        .set({ ...result, updatedAt: new Date() })
        .where(eq(evaluationResults.id, existing[0].id))
        .returning();
      return updated;
    } else {
      // Insert new
      const [inserted] = await db.insert(evaluationResults).values(result).returning();
      return inserted;
    }
  }

  // Provider Metrics
  async getProviderMetrics(companyId?: string): Promise<ProviderMetric[]> {
    if (companyId) {
      return await db.select().from(providerMetrics)
        .where(eq(providerMetrics.companyId, companyId))
        .orderBy(desc(providerMetrics.year), desc(providerMetrics.month));
    }
    return await db.select().from(providerMetrics)
      .orderBy(desc(providerMetrics.year), desc(providerMetrics.month));
  }

  // Dashboard stats
  async getDashboardStats(companyId: string) {
    const company = await this.getCompany(companyId);
    if (!company) return null;

    // Get current month dispatches
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();

    const monthlyDispatches = await db.select()
      .from(dispatches)
      .where(and(
        eq(dispatches.companyId, companyId),
        sql`EXTRACT(MONTH FROM ${dispatches.dispatchDate}) = ${currentMonth}`,
        sql`EXTRACT(YEAR FROM ${dispatches.dispatchDate}) = ${currentYear}`
      ));

    const totalDispatches = monthlyDispatches.length;
    const monthlyWeight = monthlyDispatches.reduce((sum, d) => sum + (d.totalWeight || 0), 0);

    // Get active certifications
    const activeCertifications = await db.select()
      .from(certifications)
      .where(and(
        eq(certifications.companyId, companyId),
        sql`${certifications.currentPhase} != 'publicacion'`
      ));

    // Material distribution from dispatch_materials
    const materialDistribution = await db.select({
      material: dispatchMaterials.material,
      cantidad: sql<number>`SUM(${dispatchMaterials.weight})`.as('cantidad')
    })
    .from(dispatchMaterials)
    .innerJoin(dispatches, eq(dispatches.id, dispatchMaterials.dispatchId))
    .where(eq(dispatches.companyId, companyId))
    .groupBy(dispatchMaterials.material);

    return {
      company,
      monthlyDispatches: totalDispatches,
      monthlyWeight,
      yearlyUsage: company.yearlyUsage || 0,
      annualLimit: company.annualLimit || 300,
      activeCertifications: activeCertifications.length,
      esgScore: company.esgScore || 0,
      materialDistribution
    };
  }

  // ==================== ADMIN METHODS ====================
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUser(id: string, data: Partial<User>): Promise<User> {
    if (data.password) {
      data.password = await bcrypt.hash(data.password, 10);
    }
    const [updated] = await db.update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return updated;
  }

  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id)).execute();
  }

  async createCompany(insertCompany: InsertCompany): Promise<Company> {
    const [company] = await db.insert(companies).values(insertCompany).returning();
    return company;
  }

  async getAllPaymentRequests(): Promise<PaymentRequest[]> {
    return await db.select()
      .from(paymentRequests)
      .orderBy(desc(paymentRequests.createdAt));
  }

  async createPaymentRequest(payment: InsertPaymentRequest): Promise<PaymentRequest> {
    const [created] = await db.insert(paymentRequests).values(payment).returning();
    return created;
  }

  async confirmPayment(id: string, confirmedBy: string): Promise<PaymentRequest> {
    const [updated] = await db.update(paymentRequests)
      .set({ 
        status: 'confirmed',
        confirmedBy,
        confirmedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(paymentRequests.id, id))
      .returning();
    return updated;
  }

  async getAllCertifierAssignments(): Promise<CertifierAssignment[]> {
    return await db.select()
      .from(certifierAssignments)
      .orderBy(desc(certifierAssignments.createdAt));
  }

  async createCertifierAssignment(assignment: InsertCertifierAssignment): Promise<CertifierAssignment> {
    const [created] = await db.insert(certifierAssignments).values(assignment).returning();
    return created;
  }

  async updateCertifierAssignment(id: string, data: Partial<CertifierAssignment>): Promise<CertifierAssignment> {
    const [updated] = await db.update(certifierAssignments)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(certifierAssignments.id, id))
      .returning();
    return updated;
  }

  async getCertifiersWorkload(role?: string): Promise<any[]> {
    let certifiers;
    if (role) {
      certifiers = await db.select().from(users).where(eq(users.role, role as any));
    } else {
      certifiers = await db.select().from(users)
        .where(inArray(users.role, ['cps', 'evaluador', 'auditor'] as any[]));
    }

    const workloadData = await Promise.all(
      certifiers.map(async (certifier) => {
        const activeAssignments = await db.select({ count: count() })
          .from(certifierAssignments)
          .where(and(
            eq(certifierAssignments.assignedTo, certifier.id),
            eq(certifierAssignments.status, 'in_progress' as any)
          ));

        return {
          userId: certifier.id,
          username: certifier.username,
          email: certifier.email,
          role: certifier.role,
          workload: activeAssignments[0]?.count || 0
        };
      })
    );

    return workloadData.sort((a, b) => a.workload - b.workload);
  }

  async getAdminStats(): Promise<any> {
    const totalUsers = await db.select({ count: count() }).from(users);
    const totalCompanies = await db.select({ count: count() }).from(companies);
    const totalProviders = await db.select({ count: count() })
      .from(companies)
      .where(eq(companies.type, 'proveedor'));
    const totalMiningCompanies = await db.select({ count: count() })
      .from(companies)
      .where(eq(companies.type, 'minera'));
    
    const pendingPayments = await db.select({ count: count() })
      .from(paymentRequests)
      .where(eq(paymentRequests.status, 'pending' as any));
    
    const activeCertifications = await db.select({ count: count() })
      .from(certifications)
      .where(sql`${certifications.currentPhase} != 'publicacion'`);
    
    const completedCertifications = await db.select({ count: count() })
      .from(certifications)
      .where(and(
        eq(certifications.currentPhase, 'publicacion' as any),
        sql`${certifications.finalStatus} = 'aprobado'`
      ));
    
    const totalDispatches = await db.select({ count: count() }).from(dispatches);
    
    const totalWeight = await db.select({
      sum: sql<number>`SUM(${dispatches.totalWeight})`.as('sum')
    }).from(dispatches);

    return {
      totalUsers: totalUsers[0]?.count || 0,
      totalCompanies: totalCompanies[0]?.count || 0,
      totalProviders: totalProviders[0]?.count || 0,
      totalMiningCompanies: totalMiningCompanies[0]?.count || 0,
      pendingPayments: pendingPayments[0]?.count || 0,
      activeCertifications: activeCertifications[0]?.count || 0,
      completedCertifications: completedCertifications[0]?.count || 0,
      totalDispatches: totalDispatches[0]?.count || 0,
      totalWeight: totalWeight[0]?.sum || 0
    };
  }
}

export const storage = new DatabaseStorage();
