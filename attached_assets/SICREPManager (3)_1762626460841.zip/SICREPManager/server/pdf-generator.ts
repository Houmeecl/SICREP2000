import puppeteer, { Browser } from 'puppeteer';

let browser: Browser | null = null;
let browserPromise: Promise<Browser> | null = null;

async function getBrowser(): Promise<Browser> {
  if (browser) {
    return browser;
  }
  
  if (browserPromise) {
    return browserPromise;
  }

  browserPromise = puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
  }).then((b) => {
    browser = b;
    browserPromise = null;
    return b;
  });

  return browserPromise;
}

export async function generatePDFFromHTML(html: string, options: {
  format?: 'A4' | 'Letter';
  landscape?: boolean;
  margin?: { top?: string; right?: string; bottom?: string; left?: string };
} = {}): Promise<Buffer> {
  const browserInstance = await getBrowser();
  const page = await browserInstance.newPage();
  
  try {
    await page.setContent(html, { waitUntil: 'networkidle0' });
    
    const pdf = await page.pdf({
      format: options.format || 'A4',
      landscape: options.landscape || false,
      margin: options.margin || { top: '20mm', right: '15mm', bottom: '20mm', left: '15mm' },
      printBackground: true,
      preferCSSPageSize: false,
    });
    
    return Buffer.from(pdf);
  } finally {
    await page.close();
  }
}

export async function closeBrowser() {
  if (browser) {
    await browser.close();
    browser = null;
    browserPromise = null;
  }
}

process.on('SIGINT', async () => {
  await closeBrowser();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await closeBrowser();
  process.exit(0);
});

const commonStyles = `
  <style>
    @page {
      margin: 0;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      color: #1a1a1a;
      line-height: 1.6;
    }
    
    .page-container {
      padding: 40px 30px;
      max-width: 210mm;
      margin: 0 auto;
    }
    
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 3px solid #10b981;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    
    .logo-section h1 {
      color: #10b981;
      font-size: 32px;
      font-weight: 800;
      letter-spacing: -0.5px;
      margin-bottom: 4px;
    }
    
    .logo-section p {
      color: #6b7280;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    
    .report-meta {
      text-align: right;
      font-size: 12px;
      color: #6b7280;
    }
    
    .report-meta strong {
      color: #1a1a1a;
      font-weight: 600;
    }
    
    .report-title {
      font-size: 24px;
      font-weight: 700;
      color: #1a1a1a;
      margin-bottom: 10px;
    }
    
    .report-subtitle {
      font-size: 14px;
      color: #6b7280;
      margin-bottom: 30px;
    }
    
    .section {
      margin-bottom: 30px;
    }
    
    .section-title {
      font-size: 18px;
      font-weight: 700;
      color: #1a1a1a;
      margin-bottom: 15px;
      padding-bottom: 8px;
      border-bottom: 2px solid #e5e7eb;
    }
    
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 20px;
    }
    
    .info-item {
      padding: 12px;
      background: #f9fafb;
      border-radius: 6px;
      border-left: 3px solid #10b981;
    }
    
    .info-label {
      font-size: 11px;
      color: #6b7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 4px;
      font-weight: 600;
    }
    
    .info-value {
      font-size: 14px;
      color: #1a1a1a;
      font-weight: 600;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 13px;
    }
    
    thead {
      background: #10b981;
      color: white;
    }
    
    thead th {
      padding: 12px;
      text-align: left;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 11px;
      letter-spacing: 0.5px;
    }
    
    tbody tr {
      border-bottom: 1px solid #e5e7eb;
    }
    
    tbody tr:hover {
      background: #f9fafb;
    }
    
    tbody td {
      padding: 12px;
      color: #1a1a1a;
    }
    
    .badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    
    .badge-success {
      background: #d1fae5;
      color: #065f46;
    }
    
    .badge-warning {
      background: #fef3c7;
      color: #92400e;
    }
    
    .badge-danger {
      background: #fee2e2;
      color: #991b1b;
    }
    
    .badge-info {
      background: #dbeafe;
      color: #1e40af;
    }
    
    .metric-card {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 15px;
    }
    
    .metric-label {
      font-size: 12px;
      opacity: 0.9;
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .metric-value {
      font-size: 36px;
      font-weight: 800;
      line-height: 1;
    }
    
    .footer {
      margin-top: 50px;
      padding-top: 20px;
      border-top: 2px solid #e5e7eb;
      font-size: 11px;
      color: #6b7280;
      text-align: center;
    }
    
    .signature-section {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 40px;
      margin-top: 60px;
    }
    
    .signature-box {
      text-align: center;
      padding: 20px;
      border: 2px dashed #d1d5db;
      border-radius: 8px;
    }
    
    .signature-line {
      border-top: 2px solid #1a1a1a;
      margin: 40px 20px 10px;
    }
    
    .signature-label {
      font-size: 12px;
      color: #6b7280;
      font-weight: 600;
    }
    
    .qr-placeholder {
      width: 120px;
      height: 120px;
      background: #f3f4f6;
      border: 2px solid #d1d5db;
      border-radius: 8px;
      margin: 0 auto 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      color: #9ca3af;
    }
  </style>
`;

export function getCertificadoREPTemplate(data: {
  companyName: string;
  companyRut: string;
  certificationId: string;
  issueDate: string;
  validUntil: string;
  totalScore: number;
  documentalScore: number;
  operativosScore: number;
  valorAgregadoScore: number;
  evaluator: string;
  auditor: string;
  certificador: string;
}): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      ${commonStyles}
    </head>
    <body>
      <div class="page-container">
        <div class="header">
          <div class="logo-section">
            <h1>SICREP</h1>
            <p>Sistema Integral de Certificación REP</p>
          </div>
          <div class="report-meta">
            <div><strong>Certificado N°:</strong> ${data.certificationId}</div>
            <div><strong>Fecha Emisión:</strong> ${new Date(data.issueDate).toLocaleDateString('es-CL')}</div>
          </div>
        </div>
        
        <div style="text-align: center; margin: 40px 0;">
          <h1 class="report-title">CERTIFICADO DE CUMPLIMIENTO REP</h1>
          <p class="report-subtitle">Ley 20.920 - Responsabilidad Extendida del Productor</p>
        </div>
        
        <div class="section">
          <h2 class="section-title">Datos de la Empresa</h2>
          <div class="info-grid">
            <div class="info-item">
              <div class="info-label">Razón Social</div>
              <div class="info-value">${data.companyName}</div>
            </div>
            <div class="info-item">
              <div class="info-label">RUT</div>
              <div class="info-value">${data.companyRut}</div>
            </div>
            <div class="info-item">
              <div class="info-label">Certificado N°</div>
              <div class="info-value">${data.certificationId}</div>
            </div>
            <div class="info-item">
              <div class="info-label">Vigencia</div>
              <div class="info-value">Hasta ${new Date(data.validUntil).toLocaleDateString('es-CL')}</div>
            </div>
          </div>
        </div>
        
        <div class="section">
          <h2 class="section-title">Resultados de Evaluación</h2>
          
          <div class="metric-card">
            <div class="metric-label">Puntaje Total Obtenido</div>
            <div class="metric-value">${data.totalScore} / 100</div>
          </div>
          
          <table>
            <thead>
              <tr>
                <th>Categoría</th>
                <th style="text-align: center;">Puntaje</th>
                <th style="text-align: center;">Estado</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Evaluación Documental</td>
                <td style="text-align: center;"><strong>${data.documentalScore} pts</strong></td>
                <td style="text-align: center;">
                  <span class="badge ${data.documentalScore >= 20 ? 'badge-success' : 'badge-warning'}">
                    ${data.documentalScore >= 20 ? 'APROBADO' : 'OBSERVADO'}
                  </span>
                </td>
              </tr>
              <tr>
                <td>Evaluación Operativa</td>
                <td style="text-align: center;"><strong>${data.operativosScore} pts</strong></td>
                <td style="text-align: center;">
                  <span class="badge ${data.operativosScore >= 30 ? 'badge-success' : 'badge-warning'}">
                    ${data.operativosScore >= 30 ? 'APROBADO' : 'OBSERVADO'}
                  </span>
                </td>
              </tr>
              <tr>
                <td>Valor Agregado</td>
                <td style="text-align: center;"><strong>${data.valorAgregadoScore} pts</strong></td>
                <td style="text-align: center;">
                  <span class="badge ${data.valorAgregadoScore >= 10 ? 'badge-success' : 'badge-info'}">
                    ${data.valorAgregadoScore >= 10 ? 'DESTACADO' : 'ESTÁNDAR'}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div class="section">
          <h2 class="section-title">Declaración Oficial</h2>
          <p style="text-align: justify; line-height: 1.8; color: #374151;">
            Se certifica que <strong>${data.companyName}</strong>, RUT <strong>${data.companyRut}</strong>, 
            ha cumplido satisfactoriamente con todos los requisitos establecidos en la Ley 20.920 
            sobre Responsabilidad Extendida del Productor (REP) para gestión de residuos de envases 
            y embalajes, alcanzando un puntaje total de <strong>${data.totalScore} puntos</strong> 
            en el proceso de evaluación integral realizado por SICREP.
          </p>
          <p style="text-align: justify; line-height: 1.8; color: #374151; margin-top: 15px;">
            El presente certificado tiene validez hasta el <strong>${new Date(data.validUntil).toLocaleDateString('es-CL')}</strong> 
            y puede ser verificado mediante el código QR adjunto o en el sitio web oficial de SICREP.
          </p>
        </div>
        
        <div class="signature-section">
          <div class="signature-box">
            <div class="signature-line"></div>
            <div class="signature-label">Evaluador Técnico</div>
            <div style="margin-top: 8px; font-size: 13px; font-weight: 600;">${data.evaluator}</div>
          </div>
          <div class="signature-box">
            <div class="signature-line"></div>
            <div class="signature-label">Certificador Oficial</div>
            <div style="margin-top: 8px; font-size: 13px; font-weight: 600;">${data.certificador}</div>
          </div>
        </div>
        
        <div style="text-align: center; margin-top: 40px;">
          <div class="qr-placeholder">
            QR CODE
          </div>
          <p style="font-size: 11px; color: #6b7280;">Verificación Digital: ${data.certificationId}</p>
        </div>
        
        <div class="footer">
          <p>
            Este documento es un certificado oficial emitido por SICREP - Sistema Integral de Certificación REP<br>
            Conforme a la Ley 20.920 de Responsabilidad Extendida del Productor - Chile
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
}

export function getReporteAuditoriaTemplate(data: {
  companyName: string;
  companyRut: string;
  auditDate: string;
  auditor: string;
  certificationId: string;
  findings: Array<{ category: string; description: string; severity: 'Crítico' | 'Mayor' | 'Menor'; status: string }>;
  conclusion: string;
  recommendations: string[];
}): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      ${commonStyles}
    </head>
    <body>
      <div class="page-container">
        <div class="header">
          <div class="logo-section">
            <h1>SICREP</h1>
            <p>Sistema Integral de Certificación REP</p>
          </div>
          <div class="report-meta">
            <div><strong>Auditoría N°:</strong> ${data.certificationId}</div>
            <div><strong>Fecha:</strong> ${new Date(data.auditDate).toLocaleDateString('es-CL')}</div>
          </div>
        </div>
        
        <div style="margin: 30px 0;">
          <h1 class="report-title">REPORTE DE AUDITORÍA REP</h1>
          <p class="report-subtitle">Evaluación de Cumplimiento Normativo</p>
        </div>
        
        <div class="section">
          <h2 class="section-title">Información General</h2>
          <div class="info-grid">
            <div class="info-item">
              <div class="info-label">Empresa Auditada</div>
              <div class="info-value">${data.companyName}</div>
            </div>
            <div class="info-item">
              <div class="info-label">RUT</div>
              <div class="info-value">${data.companyRut}</div>
            </div>
            <div class="info-item">
              <div class="info-label">Auditor Responsable</div>
              <div class="info-value">${data.auditor}</div>
            </div>
            <div class="info-item">
              <div class="info-label">Fecha Auditoría</div>
              <div class="info-value">${new Date(data.auditDate).toLocaleDateString('es-CL')}</div>
            </div>
          </div>
        </div>
        
        <div class="section">
          <h2 class="section-title">Hallazgos de Auditoría</h2>
          <table>
            <thead>
              <tr>
                <th>Categoría</th>
                <th>Descripción</th>
                <th style="text-align: center;">Severidad</th>
                <th style="text-align: center;">Estado</th>
              </tr>
            </thead>
            <tbody>
              ${data.findings.map(finding => `
                <tr>
                  <td><strong>${finding.category}</strong></td>
                  <td>${finding.description}</td>
                  <td style="text-align: center;">
                    <span class="badge ${
                      finding.severity === 'Crítico' ? 'badge-danger' : 
                      finding.severity === 'Mayor' ? 'badge-warning' : 'badge-info'
                    }">
                      ${finding.severity}
                    </span>
                  </td>
                  <td style="text-align: center;">
                    <span class="badge ${finding.status === 'Resuelto' ? 'badge-success' : 'badge-warning'}">
                      ${finding.status}
                    </span>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        
        <div class="section">
          <h2 class="section-title">Conclusión</h2>
          <p style="text-align: justify; line-height: 1.8; color: #374151;">
            ${data.conclusion}
          </p>
        </div>
        
        <div class="section">
          <h2 class="section-title">Recomendaciones</h2>
          <ul style="list-style: none; padding: 0;">
            ${data.recommendations.map(rec => `
              <li style="padding: 12px; margin-bottom: 8px; background: #f9fafb; border-left: 3px solid #10b981; border-radius: 4px;">
                ${rec}
              </li>
            `).join('')}
          </ul>
        </div>
        
        <div class="signature-section">
          <div class="signature-box">
            <div class="signature-line"></div>
            <div class="signature-label">Auditor Responsable</div>
            <div style="margin-top: 8px; font-size: 13px; font-weight: 600;">${data.auditor}</div>
          </div>
        </div>
        
        <div class="footer">
          <p>
            Este reporte de auditoría es un documento oficial emitido por SICREP<br>
            Generado el ${new Date().toLocaleDateString('es-CL')} a las ${new Date().toLocaleTimeString('es-CL')}
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
}

export function getReporteESGTemplate(data: {
  companyName: string;
  companyRut: string;
  reportDate: string;
  esgScore: number;
  co2Footprint: string;
  copperMarkCertified: boolean;
  governanceScore: number;
  socialScore: number;
  environmentalScore: number;
  metrics: Array<{ name: string; value: string; trend: 'up' | 'down' | 'stable' }>;
}): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      ${commonStyles}
    </head>
    <body>
      <div class="page-container">
        <div class="header">
          <div class="logo-section">
            <h1>SICREP</h1>
            <p>Sistema Integral de Certificación REP</p>
          </div>
          <div class="report-meta">
            <div><strong>Reporte ESG</strong></div>
            <div><strong>Fecha:</strong> ${new Date(data.reportDate).toLocaleDateString('es-CL')}</div>
          </div>
        </div>
        
        <div style="margin: 30px 0;">
          <h1 class="report-title">DASHBOARD ESG EJECUTIVO</h1>
          <p class="report-subtitle">Indicadores de Sostenibilidad y Gobernanza</p>
        </div>
        
        <div class="section">
          <h2 class="section-title">Información de la Empresa</h2>
          <div class="info-grid">
            <div class="info-item">
              <div class="info-label">Empresa</div>
              <div class="info-value">${data.companyName}</div>
            </div>
            <div class="info-item">
              <div class="info-label">RUT</div>
              <div class="info-value">${data.companyRut}</div>
            </div>
            <div class="info-item">
              <div class="info-label">Copper Mark</div>
              <div class="info-value">
                <span class="badge ${data.copperMarkCertified ? 'badge-success' : 'badge-warning'}">
                  ${data.copperMarkCertified ? 'CERTIFICADO' : 'NO CERTIFICADO'}
                </span>
              </div>
            </div>
            <div class="info-item">
              <div class="info-label">Huella de Carbono</div>
              <div class="info-value">${data.co2Footprint} tCO₂e</div>
            </div>
          </div>
        </div>
        
        <div class="section">
          <h2 class="section-title">Puntajes ESG</h2>
          
          <div class="metric-card" style="background: linear-gradient(135deg, #059669 0%, #047857 100%);">
            <div class="metric-label">Puntaje ESG Total</div>
            <div class="metric-value">${data.esgScore} / 100</div>
          </div>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-top: 20px;">
            <div style="background: #ecfdf5; border: 2px solid #10b981; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="font-size: 12px; color: #065f46; font-weight: 600; margin-bottom: 8px;">Ambiental</div>
              <div style="font-size: 32px; font-weight: 800; color: #047857;">${data.environmentalScore}</div>
            </div>
            <div style="background: #dbeafe; border: 2px solid #3b82f6; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="font-size: 12px; color: #1e3a8a; font-weight: 600; margin-bottom: 8px;">Social</div>
              <div style="font-size: 32px; font-weight: 800; color: #1e40af;">${data.socialScore}</div>
            </div>
            <div style="background: #fef3c7; border: 2px solid #f59e0b; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="font-size: 12px; color: #92400e; font-weight: 600; margin-bottom: 8px;">Gobernanza</div>
              <div style="font-size: 32px; font-weight: 800; color: #b45309;">${data.governanceScore}</div>
            </div>
          </div>
        </div>
        
        <div class="section">
          <h2 class="section-title">Indicadores Clave de Desempeño</h2>
          <table>
            <thead>
              <tr>
                <th>Métrica</th>
                <th style="text-align: right;">Valor</th>
                <th style="text-align: center;">Tendencia</th>
              </tr>
            </thead>
            <tbody>
              ${data.metrics.map(metric => `
                <tr>
                  <td><strong>${metric.name}</strong></td>
                  <td style="text-align: right;">${metric.value}</td>
                  <td style="text-align: center;">
                    <span class="badge ${
                      metric.trend === 'up' ? 'badge-success' : 
                      metric.trend === 'down' ? 'badge-danger' : 'badge-info'
                    }">
                      ${metric.trend === 'up' ? '↑ MEJORA' : metric.trend === 'down' ? '↓ BAJA' : '→ ESTABLE'}
                    </span>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        
        <div class="section">
          <h2 class="section-title">Certificación Copper Mark</h2>
          <p style="text-align: justify; line-height: 1.8; color: #374151;">
            ${data.copperMarkCertified 
              ? `La empresa <strong>${data.companyName}</strong> cuenta con certificación Copper Mark vigente, 
                 demostrando su compromiso con prácticas responsables de producción de cobre y cumplimiento 
                 de estándares internacionales de sostenibilidad.`
              : `La empresa <strong>${data.companyName}</strong> actualmente no cuenta con certificación Copper Mark. 
                 Se recomienda iniciar el proceso de certificación para alinearse con estándares internacionales 
                 de producción responsable de cobre.`
            }
          </p>
        </div>
        
        <div class="footer">
          <p>
            Reporte ESG Ejecutivo generado por SICREP - Sistema Integral de Certificación REP<br>
            Generado el ${new Date().toLocaleDateString('es-CL')} a las ${new Date().toLocaleTimeString('es-CL')}
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
}
