import { Request, Response, NextFunction } from "express";

// Middleware para verificar que el usuario está autenticado
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const isAuth = (req as any).isAuthenticated && (req as any).isAuthenticated();
  if (!isAuth) {
    return res.status(401).json({ error: "No autenticado" });
  }
  next();
}

// Middleware para verificar rol específico
export function requireRole(...allowedRoles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const isAuth = (req as any).isAuthenticated && (req as any).isAuthenticated();
    if (!isAuth) {
      return res.status(401).json({ error: "No autenticado" });
    }

    const user = (req as any).user;
    if (!user || !user.role) {
      return res.status(403).json({ error: "No autorizado - rol no definido" });
    }

    if (!allowedRoles.includes(user.role)) {
      return res.status(403).json({ 
        error: "No autorizado - rol insuficiente",
        requiredRoles: allowedRoles,
        userRole: user.role
      });
    }

    next();
  };
}
