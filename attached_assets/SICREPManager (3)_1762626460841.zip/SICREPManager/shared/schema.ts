import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, decimal, jsonb, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const roleEnum = pgEnum("role", [
  "admin",
  "cps",
  "evaluador",
  "auditor",
  "certificador",
  "proveedor",
  "empresa_minera",
  "inspector",
  "coordinador_regional",
  "analista_esg",
  "especialista_nfc",
  "responsable_legal",
  "supervisor_calidad",
  "gestor_documentos",
  "analista_datos",
  "soporte_tecnico",
  "consultor_externo",
  "manager_comercial",
  "manager_operaciones",
  "jefe_tecnico",
  "vendedor",
  "miembro_comite",
  "viewer"
]);

export const paymentStatusEnum = pgEnum("payment_status", [
  "pending",
  "confirmed",
  "rejected",
  "refunded"
]);

export const paymentTypeEnum = pgEnum("payment_type", [
  "certificacion_inicial", // 15 UF
  "mensual_plataforma",     // 5 UF/mes
  "certificados_nfc_extra"  // Adicionales
]);

export const assignmentStatusEnum = pgEnum("assignment_status", [
  "assigned",
  "in_progress",
  "completed",
  "reassigned"
]);

export const certificationStatusEnum = pgEnum("certification_status", [
  "solicitud_inicial",
  "revision_documentacion",
  "inspeccion_terreno",
  "evaluacion_tecnica",
  "informe_preliminar",
  "correcciones",
  "revision_final",
  "aprobacion",
  "emision_certificado",
  "publicacion"
]);

export const dispatchStatusEnum = pgEnum("dispatch_status", [
  "registrado",
  "en_transito",
  "recibido",
  "verificado",
  "certificado"
]);

export const evaluationCategoryEnum = pgEnum("evaluation_category", [
  "documentales",
  "operativos",
  "valor_agregado"
]);

export const providerSealEnum = pgEnum("provider_seal", [
  "approved",
  "warning",
  "rejected"
]);

export const riskLevelEnum = pgEnum("risk_level", [
  "low",
  "medium",
  "high"
]);

export const materialTypeEnum = pgEnum("material_type", [
  "papel_carton",
  "plasticos",
  "vidrio",
  "metales",
  "madera",
  "compuestos",
  "otros"
]);

export const packageLevelEnum = pgEnum("package_level", [
  "primario",
  "secundario",
  "terciario"
]);

export const nfcStatusEnum = pgEnum("nfc_status", [
  "activo",
  "en_transito",
  "entregado",
  "cerrado"
]);

export const traceEventTypeEnum = pgEnum("trace_event_type", [
  "alta",
  "despacho",
  "en_transito",
  "recepcion",
  "certificado",
  "cierre"
]);

export const metodoMedicionEnum = pgEnum("metodo_medicion", [
  "balanza",
  "declarado",
  "estimado"
]);

// Companies table (debe estar antes de users para las referencias)
export const companies = pgTable("companies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  rut: text("rut").notNull().unique(),
  type: text("type").notNull(), // "proveedor" | "minera"
  miningCompanyId: varchar("mining_company_id").references(() => companies.id), // For providers: which mining company they belong to
  address: text("address"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  esgScore: integer("esg_score").default(0),
  co2Footprint: decimal("co2_footprint", { precision: 10, scale: 2 }),
  copperMarkCertified: boolean("copper_mark_certified").default(false),
  annualLimit: integer("annual_limit").default(300), // kg
  currentYear: integer("current_year").default(2024),
  yearlyUsage: integer("yearly_usage").default(0), // gramos
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  role: roleEnum("role").notNull().default("proveedor"),
  companyId: varchar("company_id").references(() => companies.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// CPS table (Código Producto SICREP)
export const cps = pgTable("cps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: text("code").notNull().unique(), // CPS-ABC-001
  companyId: varchar("company_id").references(() => companies.id).notNull(),
  productName: text("product_name").notNull(),
  productDescription: text("product_description"),
  level: packageLevelEnum("level").notNull(),
  averageWeight: integer("average_weight"), // gramos
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Dispatches table
export const dispatches = pgTable("dispatches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id).notNull(),
  cpsId: varchar("cps_id").references(() => cps.id),
  nfcTag: text("nfc_tag").notNull().unique(),
  totalWeight: integer("total_weight").notNull(), // gramos
  status: dispatchStatusEnum("status").notNull().default("registrado"),
  origin: text("origin").notNull(),
  destination: text("destination"),
  dispatchDate: timestamp("dispatch_date").notNull(),
  receptionDate: timestamp("reception_date"),
  certificationId: varchar("certification_id").references(() => certifications.id),
  metadata: jsonb("metadata"), // Additional tracking data
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// CPS materials composition
export const cpsMaterials = pgTable("cps_materials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cpsId: varchar("cps_id").references(() => cps.id).notNull(),
  material: materialTypeEnum("material").notNull(),
  percentage: integer("percentage").notNull(), // % del total (0-100)
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Dispatch materials breakdown
export const dispatchMaterials = pgTable("dispatch_materials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dispatchId: varchar("dispatch_id").references(() => dispatches.id).notNull(),
  material: materialTypeEnum("material").notNull(),
  weight: integer("weight").notNull(), // gramos
  percentage: integer("percentage"), // % del total
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// NFC Tags for package traceability
export const nfcTags = pgTable("nfc_tags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  uidTag: text("uid_tag").notNull().unique(), // UID from NFC chip
  cpsId: varchar("cps_id").references(() => cps.id).notNull(),
  companyId: varchar("company_id").references(() => companies.id).notNull(),
  nivel: packageLevelEnum("nivel").notNull(),
  taraGr: integer("tara_gr"), // Tara weight in grams
  status: nfcStatusEnum("status").notNull().default("activo"),
  qrCode: text("qr_code"), // QR code URL
  locked: boolean("locked").default(false), // Write-lock status
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Peso Mediciones (weight measurements)
export const pesoMediciones = pgTable("peso_mediciones", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nfcTagId: varchar("nfc_tag_id").references(() => nfcTags.id).notNull(),
  totalGr: integer("total_gr").notNull(), // Total weight in grams
  metodo: metodoMedicionEnum("metodo").notNull(),
  balanzaId: text("balanza_id"), // Scale/balance ID
  ubicacion: text("ubicacion"), // Location name
  lat: decimal("lat", { precision: 10, scale: 7 }), // GPS latitude
  lng: decimal("lng", { precision: 10, scale: 7 }), // GPS longitude
  evidenciaUrl: text("evidencia_url"), // Photo/ticket URL
  actorRut: text("actor_rut").notNull(),
  actorNombre: text("actor_nombre").notNull(),
  hashIntegridad: text("hash_integridad").notNull(), // SHA-256 hash
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Medicion Materials breakdown
export const medicionMaterials = pgTable("medicion_materials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  medicionId: varchar("medicion_id").references(() => pesoMediciones.id).notNull(),
  material: materialTypeEnum("material").notNull(),
  pesoGr: integer("peso_gr").notNull(), // Weight in grams
  percentage: integer("percentage"), // % of total
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Trace Events (trazabilidad)
export const traceEvents = pgTable("trace_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nfcTagId: varchar("nfc_tag_id").references(() => nfcTags.id).notNull(),
  tipo: traceEventTypeEnum("tipo").notNull(),
  detalle: jsonb("detalle"), // JSON with event details
  actorRut: text("actor_rut").notNull(),
  actorNombre: text("actor_nombre").notNull(),
  firmaOk: boolean("firma_ok").default(false),
  hash: text("hash").notNull(), // SHA-256 hash
  ubicacion: text("ubicacion"),
  lat: decimal("lat", { precision: 10, scale: 7 }),
  lng: decimal("lng", { precision: 10, scale: 7 }),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Certifications table
export const certifications = pgTable("certifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: text("code").notNull().unique(), // CPS-C-001
  companyId: varchar("company_id").references(() => companies.id).notNull(),
  currentPhase: certificationStatusEnum("current_phase").notNull().default("solicitud_inicial"),
  phaseStartDate: timestamp("phase_start_date").defaultNow().notNull(),
  phaseSla: integer("phase_sla").notNull(), // days
  isDelayed: boolean("is_delayed").default(false),
  totalScore: integer("total_score").default(0),
  documentalScore: integer("documental_score").default(0),
  operationalScore: integer("operational_score").default(0),
  valueAddedScore: integer("value_added_score").default(0),
  finalStatus: text("final_status"), // "aprobado" | "observaciones" | "rechazado"
  certificateUrl: text("certificate_url"),
  publicHash: text("public_hash"), // Blockchain hash for public verification
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Certification phases history
export const certificationPhases = pgTable("certification_phases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  certificationId: varchar("certification_id").references(() => certifications.id).notNull(),
  phase: certificationStatusEnum("phase").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  sla: integer("sla").notNull(), // days
  completed: boolean("completed").default(false),
  delayed: boolean("delayed").default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Evaluation criteria table
export const evaluationCriteria = pgTable("evaluation_criteria", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  category: evaluationCategoryEnum("category").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  maxPoints: integer("max_points").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Evaluation results table
export const evaluationResults = pgTable("evaluation_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  certificationId: varchar("certification_id").references(() => certifications.id).notNull(),
  criterionId: varchar("criterion_id").references(() => evaluationCriteria.id).notNull(),
  passed: boolean("passed").default(false),
  pointsAwarded: integer("points_awarded").default(0),
  evaluatorId: varchar("evaluator_id").references(() => users.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Provider metrics table (for ESG dashboard)
export const providerMetrics = pgTable("provider_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id).notNull(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  totalDispatches: integer("total_dispatches").default(0),
  totalWeight: integer("total_weight").default(0), // kg
  esgScore: integer("esg_score").default(0),
  trend: integer("trend").default(0), // percentage
  seal: providerSealEnum("seal").default("warning"),
  risk: riskLevelEnum("risk").default("medium"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Payment Requests (gestión de pagos)
export const paymentRequests = pgTable("payment_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id).notNull(),
  type: paymentTypeEnum("type").notNull(),
  amountUF: decimal("amount_uf", { precision: 10, scale: 2 }).notNull(),
  amountCLP: integer("amount_clp"),
  status: paymentStatusEnum("status").notNull().default("pending"),
  paymentMethod: text("payment_method"),
  transactionId: text("transaction_id"),
  paymentProofUrl: text("payment_proof_url"),
  paidAt: timestamp("paid_at"),
  confirmedBy: varchar("confirmed_by").references(() => users.id),
  confirmedAt: timestamp("confirmed_at"),
  notes: text("notes"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Certifier Assignments (asignación de certificadores)
export const certifierAssignments = pgTable("certifier_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  certificationId: varchar("certification_id").references(() => certifications.id).notNull(),
  assignedTo: varchar("assigned_to").references(() => users.id).notNull(),
  assignedBy: varchar("assigned_by").references(() => users.id).notNull(),
  role: roleEnum("role").notNull(),
  status: assignmentStatusEnum("status").notNull().default("assigned"),
  phaseStart: certificationStatusEnum("phase_start"),
  phaseEnd: certificationStatusEnum("phase_end"),
  workload: integer("workload").default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertCompanySchema = createInsertSchema(companies).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertDispatchSchema = createInsertSchema(dispatches).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertCertificationSchema = createInsertSchema(certifications).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertEvaluationCriterionSchema = createInsertSchema(evaluationCriteria).omit({
  id: true,
  createdAt: true
});

export const insertEvaluationResultSchema = createInsertSchema(evaluationResults).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertProviderMetricSchema = createInsertSchema(providerMetrics).omit({
  id: true,
  createdAt: true
});

export const insertCertificationPhaseSchema = createInsertSchema(certificationPhases).omit({
  id: true,
  createdAt: true
});

export const insertCPSSchema = createInsertSchema(cps).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertDispatchMaterialSchema = createInsertSchema(dispatchMaterials).omit({
  id: true,
  createdAt: true
});

export const insertCPSMaterialSchema = createInsertSchema(cpsMaterials).omit({
  id: true,
  createdAt: true
});

export const insertPaymentRequestSchema = createInsertSchema(paymentRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertCertifierAssignmentSchema = createInsertSchema(certifierAssignments).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertNfcTagSchema = createInsertSchema(nfcTags).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertPesoMedicionSchema = createInsertSchema(pesoMediciones).omit({
  id: true,
  createdAt: true
});

export const insertMedicionMaterialSchema = createInsertSchema(medicionMaterials).omit({
  id: true,
  createdAt: true
});

export const insertTraceEventSchema = createInsertSchema(traceEvents).omit({
  id: true,
  createdAt: true
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

export type InsertCPS = z.infer<typeof insertCPSSchema>;
export type CPS = typeof cps.$inferSelect;

export type InsertDispatch = z.infer<typeof insertDispatchSchema>;
export type Dispatch = typeof dispatches.$inferSelect;

export type InsertDispatchMaterial = z.infer<typeof insertDispatchMaterialSchema>;
export type DispatchMaterial = typeof dispatchMaterials.$inferSelect;

export type InsertCPSMaterial = z.infer<typeof insertCPSMaterialSchema>;
export type CPSMaterial = typeof cpsMaterials.$inferSelect;

export type InsertCertification = z.infer<typeof insertCertificationSchema>;
export type Certification = typeof certifications.$inferSelect;

export type InsertEvaluationCriterion = z.infer<typeof insertEvaluationCriterionSchema>;
export type EvaluationCriterion = typeof evaluationCriteria.$inferSelect;

export type InsertEvaluationResult = z.infer<typeof insertEvaluationResultSchema>;
export type EvaluationResult = typeof evaluationResults.$inferSelect;

export type InsertProviderMetric = z.infer<typeof insertProviderMetricSchema>;
export type ProviderMetric = typeof providerMetrics.$inferSelect;

export type InsertCertificationPhase = z.infer<typeof insertCertificationPhaseSchema>;
export type CertificationPhase = typeof certificationPhases.$inferSelect;

export type InsertPaymentRequest = z.infer<typeof insertPaymentRequestSchema>;
export type PaymentRequest = typeof paymentRequests.$inferSelect;

export type InsertCertifierAssignment = z.infer<typeof insertCertifierAssignmentSchema>;
export type CertifierAssignment = typeof certifierAssignments.$inferSelect;

export type InsertNfcTag = z.infer<typeof insertNfcTagSchema>;
export type NfcTag = typeof nfcTags.$inferSelect;

export type InsertPesoMedicion = z.infer<typeof insertPesoMedicionSchema>;
export type PesoMedicion = typeof pesoMediciones.$inferSelect;

export type InsertMedicionMaterial = z.infer<typeof insertMedicionMaterialSchema>;
export type MedicionMaterial = typeof medicionMaterials.$inferSelect;

export type InsertTraceEvent = z.infer<typeof insertTraceEventSchema>;
export type TraceEvent = typeof traceEvents.$inferSelect;
