# SICREP - WORKFLOW Y PROCESOS
## Sistema de Gestión de Certificación REP

**Versión:** 2.0  
**Fecha:** Noviembre 2025

---

## TABLA DE CONTENIDOS

1. [Workflow de Certificación (10 Fases)](#workflow-certificacion)
2. [Workflow de Auditoría](#workflow-auditoria)
3. [Workflow de Documentos](#workflow-documentos)
4. [Workflow de Aprobaciones](#workflow-aprobaciones)
5. [Reglas de Negocio](#reglas-negocio)
6. [SLA y Tiempos](#sla-tiempos)
7. [Notificaciones Automáticas](#notificaciones)
8. [Estados y Transiciones](#estados-transiciones)

---

<a name="workflow-certificacion"></a>
## 1. WORKFLOW DE CERTIFICACIÓN (10 FASES)

### 1.1 Diagrama General

```
┌──────────────────────────────────────────────────────────────┐
│                    PROCESO DE CERTIFICACIÓN                   │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 1: SOLICITUD INICIAL                                     │
│ - Cliente envía solicitud                                     │
│ - Sistema crea proyecto                                       │
│ - Asignación automática de ID                                │
│ Duración: 1 día                                               │
│ Responsable: Sistema/Comercial                               │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 2: REVISIÓN DOCUMENTAL INICIAL                          │
│ - Verificación de documentos legales                         │
│ - Validación RUT, certificados                               │
│ - Checklist automático                                       │
│ Duración: 2-3 días                                           │
│ Responsable: Analista Documental                            │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 3: EVALUACIÓN PRELIMINAR                                │
│ - Análisis de cumplimiento inicial                           │
│ - Evaluación documental (40 pts)                             │
│ - Identificación de brechas                                  │
│ Duración: 3-4 días                                           │
│ Responsable: Evaluador                                       │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 4: VISITA EN TERRENO                                    │
│ - Coordinación de visita                                     │
│ - Evaluación operativa (40 pts)                              │
│ - Captura de evidencias                                      │
│ - Entrevistas con personal                                   │
│ Duración: 1-2 días + viaje                                   │
│ Responsable: Auditor de Campo                                │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 5: ANÁLISIS DE CUMPLIMIENTO                             │
│ - Consolidación de evaluaciones                              │
│ - Cálculo de puntaje total (100 pts)                         │
│ - Categorización (Verde/Amarillo/Rojo)                       │
│ - Identificación de no conformidades                         │
│ Duración: 2-3 días                                           │
│ Responsable: Analista Senior                                 │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 6: DICTAMEN TÉCNICO                                     │
│ - Elaboración de informe técnico                             │
│ - Recomendaciones de mejora                                  │
│ - Plan de acción (si aplica)                                 │
│ Duración: 2 días                                             │
│ Responsable: Jefe Técnico                                    │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 7: APROBACIÓN COMITÉ                                    │
│ - Revisión por Comité de Certificación                       │
│ - Votación (aprobación/rechazo/observaciones)               │
│ - Resolución de observaciones                                │
│ Duración: 3-5 días (reunión semanal)                         │
│ Responsable: Comité de Certificación                         │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 8: EMISIÓN DE CERTIFICADO                               │
│ - Generación de certificado PDF                              │
│ - Creación de QR code                                        │
│ - Registro en blockchain                                     │
│ - Firma digital                                              │
│ Duración: 1 día                                              │
│ Responsable: Sistema/Administrador                           │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 9: PUBLICACIÓN                                          │
│ - Publicación en portal público                              │
│ - Notificación al cliente                                    │
│ - Actualización de registros                                 │
│ Duración: 1 día                                              │
│ Responsable: Sistema                                         │
└──────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌──────────────────────────────────────────────────────────────┐
│ FASE 10: SEGUIMIENTO POST-CERTIFICACIÓN                      │
│ - Monitoreo de vigencia                                      │
│ - Recordatorios de renovación                                │
│ - Auditorías de seguimiento (aleatorias)                     │
│ Duración: Continuo (12 meses)                                │
│ Responsable: Sistema/Área de Calidad                         │
└──────────────────────────────────────────────────────────────┘
```

### 1.2 Matriz de Decisión por Fase

```javascript
const phaseDecisions = {
  FASE_1_SOLICITUD: {
    acciones: [
      "Crear proyecto en sistema",
      "Asignar ID único",
      "Notificar al cliente",
      "Asignar analista documental"
    ],
    siguienteFase: "FASE_2_REVISION",
    condiciones: "Solicitud completa"
  },
  
  FASE_2_REVISION: {
    acciones: [
      "Verificar documentos legales",
      "Validar RUT en SII",
      "Verificar certificado RETC",
      "Verificar certificado SMA"
    ],
    decision: {
      APROBADO: "FASE_3_EVALUACION",
      RECHAZADO: "SOLICITUD_RECHAZADA",
      CON_OBSERVACIONES: "FASE_2_REVISION" // Permanece hasta subsanar
    },
    criterios: [
      "Documentos completos: 100%",
      "Documentos vigentes: < 30 días",
      "Sin sanciones SMA"
    ]
  },
  
  FASE_3_EVALUACION: {
    acciones: [
      "Evaluar criterios documentales (40 pts)",
      "Verificar procedimientos operativos",
      "Revisar trazabilidad de información",
      "Analizar políticas de sostenibilidad"
    ],
    decision: {
      CUMPLE_MINIMO: "FASE_4_VISITA", // >= 28 pts (70% de 40)
      NO_CUMPLE: "EVALUACION_NEGATIVA",
      REQUIERE_MEJORAS: "FASE_3_EVALUACION" // Plan de mejora
    }
  },
  
  FASE_4_VISITA: {
    acciones: [
      "Coordinar visita con cliente",
      "Realizar inspección en terreno",
      "Evaluar criterios operativos (40 pts)",
      "Capturar evidencias fotográficas",
      "Entrevistar al personal",
      "Verificar infraestructura"
    ],
    decision: {
      CUMPLE: "FASE_5_ANALISIS",
      NO_CUMPLE: "PLAN_DE_ACCION",
      PARCIAL: "VISITA_ADICIONAL"
    }
  },
  
  FASE_5_ANALISIS: {
    acciones: [
      "Consolidar puntajes",
      "Calcular score total (100 pts)",
      "Categorizar (Verde/Amarillo/Rojo)",
      "Identificar no conformidades",
      "Generar reporte preliminar"
    ],
    categorizacion: {
      VERDE: ">= 85 pts → Certificación Aprobada",
      AMARILLO: "70-84 pts → Certificación Condicional",
      ROJO: "< 70 pts → No Certificable"
    },
    siguienteFase: "FASE_6_DICTAMEN"
  },
  
  FASE_6_DICTAMEN: {
    acciones: [
      "Elaborar informe técnico completo",
      "Redactar recomendaciones",
      "Definir plan de acción (si aplica)",
      "Preparar presentación para comité"
    ],
    siguienteFase: "FASE_7_COMITE"
  },
  
  FASE_7_COMITE: {
    acciones: [
      "Presentar caso al comité",
      "Deliberación y votación",
      "Resolver observaciones",
      "Emitir resolución"
    ],
    decision: {
      APROBADO: "FASE_8_EMISION",
      APROBADO_CON_CONDICIONES: "FASE_8_EMISION", // Con seguimiento
      RECHAZADO: "CERTIFICACION_RECHAZADA",
      DIFERIDO: "FASE_6_DICTAMEN" // Más información requerida
    },
    quorum: "3 de 5 miembros"
  },
  
  FASE_8_EMISION: {
    acciones: [
      "Generar certificado PDF con template",
      "Crear QR code único",
      "Registrar en blockchain",
      "Aplicar firma digital",
      "Almacenar en sistema"
    ],
    siguienteFase: "FASE_9_PUBLICACION",
    tiempoEmision: "< 24 horas"
  },
  
  FASE_9_PUBLICACION: {
    acciones: [
      "Publicar en portal público",
      "Habilitar validación por QR",
      "Notificar al cliente (email + SMS)",
      "Actualizar dashboard",
      "Generar comunicado de prensa (opcional)"
    ],
    siguienteFase: "FASE_10_SEGUIMIENTO"
  },
  
  FASE_10_SEGUIMIENTO: {
    acciones: [
      "Monitorear vigencia (12 meses)",
      "Enviar recordatorios de renovación (-90, -60, -30 días)",
      "Auditorías aleatorias de seguimiento",
      "Verificar mantenimiento de condiciones",
      "Actualizar estadísticas de compliance"
    ],
    duracion: "12 meses",
    alertas: [
      "90 días antes de vencimiento: Email recordatorio",
      "60 días antes: Email + SMS",
      "30 días antes: Email + SMS + Llamada",
      "Vencido: Suspensión automática del certificado"
    ]
  }
};
```

### 1.3 Flujo de Excepciones

```
EXCEPCIONES COMUNES:

1. Cliente No Responde
   ├─ Espera: 5 días hábiles
   ├─ Recordatorio automático (día 3)
   ├─ Escalamiento a manager (día 5)
   └─ Suspensión proyecto (día 7)

2. Documentación Incompleta
   ├─ Notificación inmediata al cliente
   ├─ Lista detallada de faltantes
   ├─ Plazo: 10 días hábiles
   └─ Bloqueo de avance hasta completar

3. Rechazo en Comité
   ├─ Notificación formal al cliente
   ├─ Explicación detallada de motivos
   ├─ Posibilidad de apelación (15 días)
   └─ Nueva evaluación (si procede)

4. Hallazgos Críticos en Terreno
   ├─ Notificación inmediata
   ├─ Suspensión temporal del proceso
   ├─ Plan de acción correctivo obligatorio
   └─ Nueva visita de verificación
```

---

<a name="workflow-auditoria"></a>
## 2. WORKFLOW DE AUDITORÍA

### 2.1 Proceso de Evaluación de Criterios

```yaml
EVALUACIÓN DOCUMENTAL (40 puntos):

1. Documentos Legales (10 pts):
   verificaciones:
     - e-RUT vigente (2 pts)
     - Certificado de vigencia sociedad < 30 días (2 pts)
     - Certificado RETC vigente (3 pts)
     - Certificado SMA sin sanciones (3 pts)
   método: Verificación automática + revisión manual
   
2. Certificaciones Ambientales (10 pts):
   verificaciones:
     - POE información a clientes (4 pts) ★ CRÍTICO
     - Plantilla de reporte de envases (2 pts)
     - Plan de manejo de residuos (2 pts)
     - Registros de capacitación (2 pts)
   método: Revisión documental + entrevistas
   
3. Procedimientos Operativos (10 pts):
   verificaciones:
     - Sistema de información documentado (3 pts)
     - Procedimientos de control de calidad (3 pts)
     - Protocolos de emergencia (2 pts)
     - Manual de operaciones (2 pts)
   método: Revisión de procedimientos escritos
   
4. Trazabilidad de Información (10 pts):
   verificaciones:
     - Sistema ERP/registro de productos (4 pts)
     - Fichas técnicas completas (3 pts)
     - Historial de entregas (2 pts)
     - Documentación de cambios (1 pt)
   método: Demostración en sistema + muestras

---

EVALUACIÓN OPERATIVA (40 puntos):

5. Gestión de Residuos (10 pts):
   verificaciones:
     - Puntos de reciclaje implementados (3 pts)
     - Señalética adecuada (2 pts)
     - Capacitación de personal (3 pts)
     - Registro de residuos (2 pts)
   método: Inspección visual + revisión de registros
   
6. Capacitación de Personal (10 pts):
   verificaciones:
     - Personal comercial capacitado (4 pts)
     - Personal logística capacitado (3 pts)
     - Plan de capacitación anual (2 pts)
     - Evaluaciones de conocimiento (1 pt)
   método: Entrevistas + revisión de certificados
   
7. Infraestructura (10 pts):
   verificaciones:
     - Instalaciones adecuadas (3 pts)
     - Equipamiento necesario (3 pts)
     - Condiciones de almacenamiento (2 pts)
     - Seguridad y accesos (2 pts)
   método: Inspección física + fotografías
   
8. Cumplimiento Normativo (10 pts):
   verificaciones:
     - Permisos operacionales vigentes (3 pts)
     - Cumplimiento Ley REP (4 pts)
     - Normativa laboral (2 pts)
     - Normativa ambiental (1 pt)
   método: Verificación de documentos oficiales

---

VALOR AGREGADO (20 puntos):

9. Ecodiseño y Material Reciclado (10 pts):
   verificaciones:
     - Uso de material reciclado (5 pts)
     - Diseño de embalajes sostenibles (3 pts)
     - Innovaciones ambientales (2 pts)
   método: Revisión de especificaciones + muestras
   
10. Certificaciones Adicionales (10 pts):
    verificaciones:
      - ISO 14001 (5 pts)
      - ISO 9001 (3 pts)
      - Otras certificaciones relevantes (2 pts)
    método: Verificación de certificados vigentes
```

### 2.2 Sistema de Puntuación

```javascript
const evaluationSystem = {
  totalPoints: 100,
  
  categories: {
    documental: {
      weight: 40,
      minimumToPass: 28 // 70% of 40
    },
    operational: {
      weight: 40,
      minimumToPass: 28 // 70% of 40
    },
    valueAdded: {
      weight: 20,
      minimumToPass: 0 // Optional
    }
  },
  
  classification: {
    GREEN: {
      range: [85, 100],
      label: "Proveedor Comprometido (Apto)",
      validityPeriod: 12, // months
      badge: "verde.png"
    },
    YELLOW: {
      range: [70, 84.9],
      label: "Certificado en Proceso (Con Observaciones)",
      validityPeriod: 12, // months
      conditions: "Debe subsanar observaciones en 60 días",
      badge: "amarillo.png"
    },
    RED: {
      range: [0, 69.9],
      label: "No Apto",
      validityPeriod: 0,
      action: "Requiere plan de mejora antes de nueva evaluación"
    }
  },
  
  calculateScore: function(scores) {
    const total = scores.documental + scores.operational + scores.valueAdded;
    
    if (total >= 85) return { category: "GREEN", total };
    if (total >= 70) return { category: "YELLOW", total };
    return { category: "RED", total };
  }
};
```

### 2.3 Proceso de Auditoría en Terreno

```
ANTES DE LA VISITA:
├─ Coordinación con cliente (48 hrs antes)
├─ Preparación de checklist personalizado
├─ Descarga de documentación previa
└─ Configuración de app móvil (modo offline)

DURANTE LA VISITA:
├─ Check-in con geolocalización
├─ Entrevista con responsable REP
├─ Inspección de instalaciones
│  ├─ Área de producción
│  ├─ Área de almacenamiento
│  ├─ Punto de reciclaje
│  └─ Oficinas administrativas
├─ Captura de evidencias
│  ├─ Fotografías geolocalizadas
│  ├─ Videos cortos (opcional)
│  └─ Firma digital del cliente
├─ Evaluación de criterios operativos
├─ Entrevistas con personal
└─ Reporte preliminar in-situ

DESPUÉS DE LA VISITA:
├─ Sincronización de datos
├─ Revisión de evidencias
├─ Completar evaluación
├─ Generar informe
└─ Notificar al cliente
```

---

<a name="workflow-documentos"></a>
## 3. WORKFLOW DE DOCUMENTOS

### 3.1 Ciclo de Vida del Documento

```
SUBIDA → VALIDACIÓN → CLASIFICACIÓN → OCR → APROBACIÓN → ARCHIVO
  │         │             │              │        │           │
  │         │             │              │        │           └─ Storage S3
  │         │             │              │        └─ Manager/Comité
  │         │             │              └─ Extracción de datos
  │         │             └─ IA categoriza tipo
  │         └─ Verificación formato/tamaño
  └─ Cliente/Evaluador
```

### 3.2 Reglas de Validación

```yaml
Documentos Aceptados:
  formatos:
    - PDF (preferido)
    - JPEG, PNG (fotos)
    - DOCX (documentos)
  
  tamaño_máximo: 25 MB por archivo
  
  requisitos_pdf:
    - No protegido con contraseña
    - Texto searchable (no escaneado)
    - Páginas completas
  
  requisitos_imagen:
    - Resolución mínima: 1024x768
    - Formato: JPEG, PNG
    - Orientación correcta

Validación Automática:
  - Verificación de formato
  - Escaneo antivirus
  - Detección de duplicados
  - Verificación de metadatos
  - OCR automático (PDF escaneados)
```

### 3.3 Clasificación Automática con IA

```python
document_types = {
    "RUT_EMPRESARIAL": {
        "keywords": ["rut", "rol único tributario", "servicio impuestos internos"],
        "confidence_threshold": 0.85,
        "required_fields": ["rut", "razon_social"]
    },
    "CERTIFICADO_VIGENCIA": {
        "keywords": ["certificado de vigencia", "conservador de bienes raíces"],
        "confidence_threshold": 0.85,
        "required_fields": ["fecha_emision", "vigente"]
    },
    "CERTIFICADO_RETC": {
        "keywords": ["retc", "registro emisiones", "ventanilla única"],
        "confidence_threshold": 0.90,
        "required_fields": ["codigo_retc", "fecha_inscripcion"]
    },
    "CERTIFICADO_SMA": {
        "keywords": ["superintendencia medio ambiente", "sma", "sanciones"],
        "confidence_threshold": 0.90,
        "required_fields": ["rut", "sin sanciones"]
    },
    "POLITICA_SOSTENIBILIDAD": {
        "keywords": ["política", "sostenibilidad", "compromiso ambiental"],
        "confidence_threshold": 0.80,
        "required_fields": ["firma_gerencia"]
    }
}
```

---

<a name="workflow-aprobaciones"></a>
## 4. WORKFLOW DE APROBACIONES

### 4.1 Niveles de Aprobación

```
NIVEL 1: Aprobación Automática del Sistema
├─ Validaciones técnicas
├─ Verificación de completitud
└─ Checks de integridad

NIVEL 2: Aprobación de Analista
├─ Revisión documental
├─ Verificación de criterios
└─ Recomendación inicial

NIVEL 3: Aprobación de Jefe Técnico
├─ Revisión de evaluación
├─ Validación de dictamen
└─ Preparación para comité

NIVEL 4: Aprobación de Comité
├─ Revisión colegiada
├─ Votación (quorum 3/5)
└─ Resolución final

NIVEL 5: Emisión por Administrador
├─ Generación de certificado
├─ Firma digital
└─ Publicación
```

### 4.2 Matriz de Autoridad

```javascript
const approvalMatrix = {
  DOCUMENT_APPROVAL: {
    roles: ["ANALISTA", "JEFE_TECNICO"],
    requiredApprovals: 1,
    timeout: 48 // hours
  },
  
  PRELIMINARY_EVALUATION: {
    roles: ["EVALUADOR", "AUDITOR"],
    requiredApprovals: 1,
    timeout: 72 // hours
  },
  
  TECHNICAL_OPINION: {
    roles: ["JEFE_TECNICO", "GERENTE_TECNICO"],
    requiredApprovals: 1,
    timeout: 48 // hours
  },
  
  COMMITTEE_APPROVAL: {
    roles: ["MIEMBRO_COMITE"],
    requiredApprovals: 3, // quorum
    totalMembers: 5,
    timeout: 168 // hours (1 week)
  },
  
  CERTIFICATE_ISSUANCE: {
    roles: ["ADMINISTRADOR", "GERENTE_GENERAL"],
    requiredApprovals: 1,
    timeout: 24 // hours
  }
};
```

---

<a name="reglas-negocio"></a>
## 5. REGLAS DE NEGOCIO

### 5.1 Reglas de Certificación

```yaml
Regla 1: Puntaje Mínimo
  - Puntaje total >= 70 puntos (de 100)
  - Puntaje documental >= 28 puntos (70% de 40)
  - Puntaje operativo >= 28 puntos (70% de 40)

Regla 2: Documentos Obligatorios
  - e-RUT vigente
  - Certificado vigencia < 30 días
  - Certificado RETC vigente
  - Certificado SMA sin sanciones
  - POE información a clientes (CRÍTICO)

Regla 3: Visita en Terreno
  - Obligatoria para todos los proyectos
  - Debe realizarse en instalaciones del cliente
  - Duración mínima: 2 horas
  - Evidencias fotográficas: mínimo 10 fotos

Regla 4: Aprobación Comité
  - Quorum: 3 de 5 miembros
  - Votación por mayoría simple
  - Acta de reunión obligatoria

Regla 5: Vigencia del Certificado
  - Duración: 12 meses desde emisión
  - Renovación: hasta 30 días después de vencimiento
  - Auditoría de renovación obligatoria

Regla 6: Suspensión Automática
  - Por sanciones SMA posteriores
  - Por cambio de razón social sin notificar
  - Por vencimiento sin renovación
  - Por hallazgos críticos en auditoría de seguimiento
```

### 5.2 Reglas de Pricing

```javascript
const pricingRules = {
  BASE_PRICES: {
    BASIC: 120000,      // $120,000 CLP
    EXPRESS: 180000,    // $180,000 CLP
    PREMIUM: 300000     // $300,000 CLP
  },
  
  DISCOUNTS: {
    VOLUME: {
      '2-5_projects': 0.05,    // 5% off
      '6-10_projects': 0.10,   // 10% off
      '11+_projects': 0.15     // 15% off
    },
    LOYALTY: {
      'first_renewal': 0.10,   // 10% off
      'second_renewal': 0.15,  // 15% off
      'third+_renewal': 0.20   // 20% off
    },
    SECTOR: {
      'PYME': 0.10,            // 10% off
      'NGO': 0.15              // 15% off
    }
  },
  
  SURCHARGES: {
    URGENCY: {
      'express_5days': 0.50,   // +50%
      'super_express_3days': 1.00  // +100%
    },
    COMPLEXITY: {
      'multiple_sites': 0.25,  // +25% per additional site
      'special_requirements': 0.15  // +15%
    }
  }
};
```

---

<a name="sla-tiempos"></a>
## 6. SLA Y TIEMPOS

### 6.1 Tiempos Estándar por Servicio

```yaml
SERVICIO BÁSICO ($120,000):
  total_days: 15-18 días hábiles
  fases:
    solicitud: 1 día
    revision_documental: 2-3 días
    evaluacion_preliminar: 3-4 días
    visita_terreno: 1-2 días + viaje
    analisis: 2-3 días
    dictamen: 2 días
    comite: 3-5 días
    emision: 1 día
    publicacion: 1 día

SERVICIO EXPRESS ($180,000):
  total_days: 5-7 días hábiles
  garantia_sla: true
  penalty_por_incumplimiento: 20% descuento

SERVICIO PREMIUM ($300,000):
  total_days: 10-12 días hábiles
  incluye:
    - Visitas adicionales
    - Asesoría personalizada
    - Gerente de cuenta dedicado
```

### 6.2 Monitoreo de SLA

```sql
-- Query para monitoreo de SLA
SELECT 
  p.project_id,
  p.service_type,
  p.created_at,
  p.due_date,
  p.current_phase,
  DATEDIFF(NOW(), p.created_at) as days_elapsed,
  DATEDIFF(p.due_date, NOW()) as days_remaining,
  CASE 
    WHEN NOW() > p.due_date THEN 'OVERDUE'
    WHEN DATEDIFF(p.due_date, NOW()) <= 2 THEN 'AT_RISK'
    ELSE 'ON_TRACK'
  END as sla_status
FROM projects p
WHERE p.status IN ('ACTIVE', 'INITIATED')
ORDER BY p.due_date ASC;
```

---

<a name="notificaciones"></a>
## 7. NOTIFICACIONES AUTOMÁTICAS

### 7.1 Triggers de Notificación

```yaml
Fase Completada:
  destinatarios: [cliente, gestor_proyecto]
  canales: [email, dashboard]
  template: "fase_completada.html"

Documento Aprobado:
  destinatarios: [cliente, analista]
  canales: [email]
  template: "documento_aprobado.html"

Documento Rechazado:
  destinatarios: [cliente]
  canales: [email, sms]
  template: "documento_rechazado.html"
  incluye: ["lista_de_correcciones"]

Visita Programada:
  destinatarios: [cliente, auditor]
  canales: [email, sms, calendar_invite]
  anticipacion: 48_horas
  template: "visita_programada.html"

Proyecto Atrasado:
  destinatarios: [gestor_proyecto, manager]
  canales: [email, slack]
  frecuencia: "diaria"
  template: "proyecto_atrasado.html"

Certificado Emitido:
  destinatarios: [cliente]
  canales: [email, sms, whatsapp]
  attachments: ["certificado.pdf", "qr_code.png"]
  template: "certificado_emitido.html"

Próximo a Vencer:
  destinatarios: [cliente]
  canales: [email, sms]
  schedule:
    - 90_dias_antes: email
    - 60_dias_antes: email + sms
    - 30_dias_antes: email + sms + llamada
  template: "renovacion_recordatorio.html"

Certificado Vencido:
  destinatarios: [cliente]
  canales: [email, sms]
  acciones: ["suspender_certificado"]
  template: "certificado_vencido.html"
```

---

<a name="estados-transiciones"></a>
## 8. ESTADOS Y TRANSICIONES

### 8.1 Máquina de Estados del Proyecto

```javascript
const projectStateMachine = {
  states: {
    DRAFT: {
      transitions: ["SUBMITTED"]
    },
    SUBMITTED: {
      transitions: ["IN_REVIEW", "REJECTED"]
    },
    IN_REVIEW: {
      transitions: ["APPROVED", "REJECTED", "REQUIRES_INFO"]
    },
    REQUIRES_INFO: {
      transitions: ["IN_REVIEW", "CANCELLED"]
    },
    APPROVED: {
      transitions: ["IN_EVALUATION"]
    },
    IN_EVALUATION: {
      transitions: ["FIELD_VISIT_SCHEDULED", "REJECTED"]
    },
    FIELD_VISIT_SCHEDULED: {
      transitions: ["FIELD_VISIT_COMPLETED"]
    },
    FIELD_VISIT_COMPLETED: {
      transitions: ["IN_ANALYSIS"]
    },
    IN_ANALYSIS: {
      transitions: ["PENDING_COMMITTEE", "REJECTED"]
    },
    PENDING_COMMITTEE: {
      transitions: ["COMMITTEE_APPROVED", "COMMITTEE_REJECTED", "REQUIRES_MORE_INFO"]
    },
    COMMITTEE_APPROVED: {
      transitions: ["CERTIFICATE_ISSUED"]
    },
    CERTIFICATE_ISSUED: {
      transitions: ["PUBLISHED"]
    },
    PUBLISHED: {
      transitions: ["ACTIVE"]
    },
    ACTIVE: {
      transitions: ["EXPIRED", "SUSPENDED", "REVOKED"]
    },
    EXPIRED: {
      transitions: ["RENEWAL_PROCESS"]
    },
    RENEWAL_PROCESS: {
      transitions: ["ACTIVE", "CANCELLED"]
    },
    SUSPENDED: {
      transitions: ["ACTIVE", "REVOKED"]
    },
    REVOKED: {
      transitions: [] // Terminal state
    },
    REJECTED: {
      transitions: ["RESUBMISSION"]
    },
    CANCELLED: {
      transitions: [] // Terminal state
    }
  },
  
  validateTransition: function(from, to) {
    return this.states[from]?.transitions.includes(to) || false;
  }
};
```

---

## 9. INTEGRACIÓN CON SISTEMAS EXTERNOS

### 9.1 Integraciones Gubernamentales

```yaml
SII (Servicio Impuestos Internos):
  endpoint: "https://api.sii.cl/v1/contribuyentes"
  uso: "Validar RUT y razón social"
  frecuencia: "Real-time on document upload"

RETC (Registro Emisiones):
  endpoint: "https://vu.mma.gob.cl/api/v1/registro"
  uso: "Verificar inscripción y vigencia"
  frecuencia: "Durante revisión documental"

SMA (Superintendencia Medio Ambiente):
  endpoint: "https://api.sma.gob.cl/v1/sanciones"
  uso: "Verificar sanciones ambientales"
  frecuencia: "Durante revisión + auditoría de seguimiento"
```

---

**Documento generado:** Noviembre 2025  
**Versión:** 2.0  
**Próxima revisión:** Febrero 2026
