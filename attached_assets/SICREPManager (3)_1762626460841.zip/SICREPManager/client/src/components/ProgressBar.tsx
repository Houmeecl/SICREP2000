import { Progress } from "@/components/ui/progress";

interface ProgressBarProps {
  current: number;
  total: number;
  label: string;
}

export default function ProgressBar({ current, total, label }: ProgressBarProps) {
  const percentage = Math.round((current / total) * 100);
  
  const getVariant = () => {
    if (percentage <= 70) return "default";
    if (percentage <= 85) return "warning";
    return "danger";
  };
  
  const variant = getVariant();
  const barColor = variant === "warning" ? "bg-yellow-500" : variant === "danger" ? "bg-destructive" : "bg-primary";
  
  return (
    <div className="space-y-2" data-testid="component-progress-bar">
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium">{label}</span>
        <span className="text-sm text-muted-foreground">
          <span className="font-bold text-foreground" data-testid="text-current">{current} kg</span> / {total} kg
        </span>
      </div>
      
      <div className="relative">
        <div className="h-3 w-full rounded-full bg-muted overflow-hidden">
          <div
            className={`h-full ${barColor} transition-all duration-300`}
            style={{ width: `${Math.min(percentage, 100)}%` }}
          />
        </div>
      </div>
      
      <div className="flex justify-end">
        <span className={`text-xs font-semibold ${
          variant === "warning" ? "text-yellow-600" : 
          variant === "danger" ? "text-destructive" : 
          "text-primary"
        }`} data-testid="text-percentage">
          {percentage}% utilizado
        </span>
      </div>
    </div>
  );
}
