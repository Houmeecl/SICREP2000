import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Circle, Clock, AlertCircle, ChevronRight } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface Phase {
  id: string;
  certificationId: string;
  phase: string;
  startDate: string;
  endDate?: string | null;
  sla: number;
  completed: boolean;
  delayed: boolean;
  notes?: string | null;
  createdAt: string;
}

interface SLAStatus {
  isDelayed: boolean;
  daysPassed: number;
  daysRemaining: number;
  sla: number;
  currentPhase: string;
  isFinalized?: boolean;
  finalStatus?: string;
}

interface WorkflowTimelineProps {
  certificationId: string;
  onAdvance?: () => void;
}

const PHASE_TITLES: Record<string, string> = {
  "solicitud_inicial": "Solicitud Inicial",
  "revision_documentacion": "Revisión Documentación",
  "inspeccion_terreno": "Inspección Terreno",
  "evaluacion_tecnica": "Evaluación Técnica",
  "informe_preliminar": "Informe Preliminar",
  "correcciones": "Correcciones",
  "revision_final": "Revisión Final",
  "aprobacion": "Aprobación",
  "emision_certificado": "Emisión Certificado",
  "publicacion": "Publicación"
};

const PHASE_DESCRIPTIONS: Record<string, string> = {
  "solicitud_inicial": "Registro de nueva solicitud de certificación",
  "revision_documentacion": "Validación de documentos técnicos y legales",
  "inspeccion_terreno": "Auditoría presencial de instalaciones",
  "evaluacion_tecnica": "Análisis de cumplimiento operativo",
  "informe_preliminar": "Elaboración de informe de evaluación",
  "correcciones": "Implementación de observaciones",
  "revision_final": "Validación de correcciones aplicadas",
  "aprobacion": "Decisión de comité evaluador",
  "emision_certificado": "Generación de certificación oficial",
  "publicacion": "Registro en plataforma pública"
};

export default function WorkflowTimeline({ certificationId, onAdvance }: WorkflowTimelineProps) {
  const { data: phases, isLoading: phasesLoading } = useQuery<Phase[]>({
    queryKey: ["/api/certifications", certificationId, "phases"],
    queryFn: async () => {
      const response = await fetch(`/api/certifications/${certificationId}/phases`);
      if (!response.ok) throw new Error("Error al cargar fases");
      return response.json();
    }
  });

  const { data: slaStatus } = useQuery<SLAStatus>({
    queryKey: ["/api/certifications", certificationId, "sla"],
    queryFn: async () => {
      const response = await fetch(`/api/certifications/${certificationId}/sla`);
      if (!response.ok) throw new Error("Error al verificar SLA");
      return response.json();
    },
    refetchInterval: 60000
  });

  const handleAdvance = async () => {
    try {
      await apiRequest(`/api/certifications/${certificationId}/advance`, {
        method: "POST",
        body: JSON.stringify({ notes: "Fase avanzada" })
      });
      
      // Invalidate all related queries
      queryClient.invalidateQueries({ queryKey: ["/api/certifications", certificationId, "phases"] });
      queryClient.invalidateQueries({ queryKey: ["/api/certifications", certificationId, "sla"] });
      queryClient.invalidateQueries({ queryKey: ["/api/certifications", certificationId] });
      queryClient.invalidateQueries({ queryKey: ["/api/certifications"] });
      
      if (onAdvance) {
        onAdvance();
      }
    } catch (error) {
      console.error("Error al avanzar fase:", error);
    }
  };

  if (phasesLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando workflow...</p>
        </div>
      </div>
    );
  }

  if (!phases || phases.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No hay fases registradas para esta certificación</p>
      </div>
    );
  }

  const getPhaseStatus = (phase: Phase): "completed" | "current" | "pending" | "delayed" => {
    if (phase.completed) return "completed";
    if (phase.delayed) return "delayed";
    if (slaStatus && phase.phase === slaStatus.currentPhase) {
      return slaStatus.isDelayed ? "delayed" : "current";
    }
    return "pending";
  };

  const currentPhase = phases.find(p => !p.completed);
  const isFinalized = slaStatus?.isFinalized || false;
  const isFinalPhase = slaStatus?.currentPhase === "publicacion";
  const canAdvance = currentPhase && !currentPhase.delayed && !isFinalPhase && !isFinalized;

  return (
    <div className="space-y-6" data-testid="component-workflow-timeline">
      {slaStatus && (
        <div className="bg-muted p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold mb-1">
                {isFinalized ? "Certificación Completada" : `Fase Actual: ${PHASE_TITLES[slaStatus.currentPhase]}`}
              </h4>
              <p className="text-sm text-muted-foreground">
                {isFinalized
                  ? `La certificación ha sido ${slaStatus.finalStatus === "aprobado" ? "aprobada" : slaStatus.finalStatus} y publicada exitosamente`
                  : slaStatus.daysRemaining > 0
                  ? `${slaStatus.daysRemaining} días restantes de ${slaStatus.sla}`
                  : `Atrasada por ${Math.abs(slaStatus.daysRemaining)} días`
                }
              </p>
            </div>
            {canAdvance && (
              <Button onClick={handleAdvance} data-testid="button-advance-phase">
                Avanzar Fase
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      )}

      <div className="space-y-4">
        {phases.map((phase, index) => {
          const status = getPhaseStatus(phase);
          
          return (
            <div key={phase.id} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className="relative">
                  {status === "completed" && (
                    <CheckCircle2 className="w-8 h-8 text-primary" data-testid={`icon-completed-${index + 1}`} />
                  )}
                  {status === "current" && (
                    <Clock className="w-8 h-8 text-primary animate-pulse" data-testid={`icon-current-${index + 1}`} />
                  )}
                  {status === "pending" && (
                    <Circle className="w-8 h-8 text-muted-foreground" data-testid={`icon-pending-${index + 1}`} />
                  )}
                  {status === "delayed" && (
                    <AlertCircle className="w-8 h-8 text-destructive" data-testid={`icon-delayed-${index + 1}`} />
                  )}
                </div>
                
                {index < phases.length - 1 && (
                  <div className={`w-0.5 h-16 mt-2 ${
                    status === "completed" ? "bg-primary" : "bg-border"
                  }`} />
                )}
              </div>
              
              <div className="flex-1 pb-8">
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold" data-testid={`text-phase-title-${index + 1}`}>
                        Fase {index + 1}: {PHASE_TITLES[phase.phase] || phase.phase}
                      </h3>
                      <Badge
                        variant={
                          status === "completed" ? "default" :
                          status === "current" ? "secondary" :
                          status === "delayed" ? "destructive" :
                          "outline"
                        }
                        className="text-xs"
                        data-testid={`badge-status-${index + 1}`}
                      >
                        {status === "completed" && "Completada"}
                        {status === "current" && "En Proceso"}
                        {status === "pending" && "Pendiente"}
                        {status === "delayed" && "Atrasada"}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {PHASE_DESCRIPTIONS[phase.phase] || "Sin descripción"}
                    </p>
                    {phase.notes && (
                      <p className="text-xs text-muted-foreground italic">
                        {phase.notes}
                      </p>
                    )}
                    <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                      <span>Inicio: {new Date(phase.startDate).toLocaleDateString('es-CL')}</span>
                      {phase.endDate && (
                        <span>Fin: {new Date(phase.endDate).toLocaleDateString('es-CL')}</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">SLA</p>
                    <p className="text-sm font-semibold" data-testid={`text-sla-${index + 1}`}>
                      {phase.sla} días
                    </p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
