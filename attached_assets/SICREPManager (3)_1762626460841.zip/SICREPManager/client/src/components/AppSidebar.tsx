import { Home, Package, FileCheck, Users, LogOut, QrCode, Shield, UserCog, Building2, CreditCard, UserPlus, ClipboardCheck, Search, BarChart3, Factory, Award, Leaf, TrendingUp, Vote } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import sicrepLogo from "@assets/ChatGPT Image 3 nov 2025, 03_29_38 p.m._1762584049547.png";

const menuItems = [
  { title: "Inicio", url: "/dashboard", icon: Home },
  { title: "Códigos CPS", url: "/cps", icon: QrCode },
  { title: "Despachos", url: "/despachos", icon: Package },
  { title: "Certificaciones", url: "/certificaciones", icon: FileCheck },
  { title: "Proveedores", url: "/proveedores", icon: Users },
];

const adminMenuItems = [
  { title: "Dashboard Admin", url: "/admin/dashboard", icon: Shield },
  { title: "Usuarios", url: "/admin/usuarios", icon: UserCog },
  { title: "Empresas", url: "/admin/empresas", icon: Building2 },
  { title: "Pagos", url: "/admin/pagos", icon: CreditCard },
  { title: "Asignaciones", url: "/admin/asignaciones", icon: UserPlus },
];

const cpsMenuItems = [
  { title: "Mis Proyectos", url: "/cps/dashboard", icon: ClipboardCheck },
];

const evaluadorMenuItems = [
  { title: "Proyectos Terreno", url: "/evaluador/dashboard", icon: Search },
];

const proveedorMenuItems = [
  { title: "Mi Dashboard", url: "/proveedor/dashboard", icon: Home },
  { title: "Códigos CPS", url: "/cps", icon: QrCode },
  { title: "Despachos", url: "/despachos", icon: Package },
  { title: "Certificación", url: "/certificaciones", icon: FileCheck },
];

const mineraMenuItems = [
  { title: "Dashboard ESG", url: "/minera/dashboard", icon: BarChart3 },
  { title: "Mis Proveedores", url: "/proveedores", icon: Users },
];

const auditorMenuItems = [
  { title: "Auditorías", url: "/auditor/dashboard", icon: ClipboardCheck },
];

const certificadorMenuItems = [
  { title: "Certificados", url: "/certificador/dashboard", icon: Award },
];

const analistaESGMenuItems = [
  { title: "Dashboard ESG", url: "/analista-esg/dashboard", icon: Leaf },
  { title: "Huella de Carbono", url: "/analista-esg/dashboard", icon: BarChart3 },
];

const vendedorMenuItems = [
  { title: "Pipeline Ventas", url: "/vendedor/dashboard", icon: TrendingUp },
  { title: "Clientes", url: "/vendedor/dashboard", icon: Users },
];

const comiteMenuItems = [
  { title: "Votaciones", url: "/comite/dashboard", icon: Vote },
];

export default function AppSidebar() {
  const { user, company, logout } = useAuth();
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(word => word[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Sidebar data-testid="sidebar-main">
      <SidebarContent>
        <div className="p-6 border-b">
          <img 
            src={sicrepLogo} 
            alt="SICREP - Sistema de Certificación REP" 
            className="h-12 w-auto"
          />
        </div>
        
        {user?.role === 'admin' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-orange-600 dark:text-orange-400">
              Panel de Administración
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-admin-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'cps' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-purple-600 dark:text-purple-400">
              Panel CPS - Fase 1-3
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {cpsMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-cps-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'evaluador' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-cyan-600 dark:text-cyan-400">
              Panel Evaluador - Fase 4-6
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {evaluadorMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-evaluador-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'proveedor' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-green-600 dark:text-green-400">
              Panel Proveedor
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {proveedorMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-proveedor-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'empresa_minera' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-blue-600 dark:text-blue-400">
              Panel Empresa Minera
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {mineraMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-minera-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'auditor' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-red-600 dark:text-red-400">
              Panel Auditor
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {auditorMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-auditor-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'certificador' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-amber-600 dark:text-amber-400">
              Panel Certificador
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {certificadorMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-certificador-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'analista_esg' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-green-600 dark:text-green-400">
              Panel Analista ESG
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {analistaESGMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-analista-esg-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'vendedor' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-indigo-600 dark:text-indigo-400">
              Panel Vendedor
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {vendedorMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-vendedor-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {user?.role === 'miembro_comite' && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-purple-600 dark:text-purple-400">
              Panel Comité
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {comiteMenuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild data-testid={`link-comite-${item.title.toLowerCase()}`}>
                      <a href={item.url}>
                        <item.icon className="w-5 h-5" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
        
        <SidebarGroup>
          <SidebarGroupLabel>Navegación Principal</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild data-testid={`link-${item.title.toLowerCase()}`}>
                    <a href={item.url}>
                      <item.icon className="w-5 h-5" />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      
      <SidebarFooter>
        <div className="p-4 border-t space-y-3">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarFallback className="bg-primary text-primary-foreground">
                {company ? getInitials(company.name) : user ? getInitials(user.username) : "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate">
                {company?.name || user?.username || "Usuario"}
              </p>
              {company?.rut && (
                <p className="text-xs text-muted-foreground font-mono">{company.rut}</p>
              )}
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start gap-2"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4" />
            Cerrar Sesión
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
