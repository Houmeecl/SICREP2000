import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronDown, ChevronRight } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { EvaluationCriterion, EvaluationResult } from "@shared/schema";

interface EvaluationMatrixProps {
  certificationId: string;
  readOnly?: boolean;
}

interface Section {
  title: string;
  category: string;
  maxPoints: number;
  currentPoints: number;
  criteria: {
    id: string;
    name: string;
    description: string | null;
    maxPoints: number;
    passed: boolean;
  }[];
}

const CATEGORY_LABELS: Record<string, string> = {
  documentales: "Documentales",
  operativos: "Operativos",
  valor_agregado: "Valor Agregado"
};

export default function EvaluationMatrix({ certificationId, readOnly = false }: EvaluationMatrixProps) {
  const { toast } = useToast();
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(["documentales"]));

  const { data: criteria, isLoading: criteriaLoading } = useQuery<EvaluationCriterion[]>({
    queryKey: ["/api/evaluation/criteria"]
  });

  const { data: results, isLoading: resultsLoading } = useQuery<EvaluationResult[]>({
    queryKey: ["/api/evaluation/results", certificationId]
  });

  const saveResultMutation = useMutation({
    mutationFn: async (data: { criterionId: string; passed: boolean; pointsAwarded: number }) => {
      return await apiRequest("POST", "/api/evaluation/results", {
        certificationId,
        criterionId: data.criterionId,
        passed: data.passed,
        pointsAwarded: data.passed ? data.pointsAwarded : 0
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/evaluation/results", certificationId] });
      queryClient.invalidateQueries({ queryKey: ["/api/certifications"] });
      toast({
        title: "Evaluación guardada",
        description: "El criterio ha sido actualizado correctamente"
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo guardar la evaluación"
      });
    }
  });

  const toggleSection = (category: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(category)) {
      newExpanded.delete(category);
    } else {
      newExpanded.add(category);
    }
    setExpandedSections(newExpanded);
  };

  const toggleCriterion = (criterionId: string, maxPoints: number, currentlyPassed: boolean) => {
    if (readOnly) return;
    
    saveResultMutation.mutate({
      criterionId,
      passed: !currentlyPassed,
      pointsAwarded: maxPoints
    });
  };

  const buildSections = (): Section[] => {
    if (!criteria || !results) return [];

    const categories: Record<string, Section> = {
      documentales: {
        title: CATEGORY_LABELS.documentales,
        category: "documentales",
        maxPoints: 0,
        currentPoints: 0,
        criteria: []
      },
      operativos: {
        title: CATEGORY_LABELS.operativos,
        category: "operativos",
        maxPoints: 0,
        currentPoints: 0,
        criteria: []
      },
      valor_agregado: {
        title: CATEGORY_LABELS.valor_agregado,
        category: "valor_agregado",
        maxPoints: 0,
        currentPoints: 0,
        criteria: []
      }
    };

    criteria.forEach(criterion => {
      const result = results.find(r => r.criterionId === criterion.id);
      const passed = result?.passed || false;
      
      if (categories[criterion.category]) {
        categories[criterion.category].maxPoints += criterion.maxPoints;
        categories[criterion.category].currentPoints += passed ? (result?.pointsAwarded || 0) : 0;
        categories[criterion.category].criteria.push({
          id: criterion.id,
          name: criterion.name,
          description: criterion.description,
          maxPoints: criterion.maxPoints,
          passed
        });
      }
    });

    return Object.values(categories);
  };

  const sections = buildSections();
  
  const totalPoints = sections.reduce((sum, section) => sum + section.currentPoints, 0);
  const maxTotalPoints = sections.reduce((sum, section) => sum + section.maxPoints, 0);
  const percentage = maxTotalPoints > 0 ? (totalPoints / maxTotalPoints) * 100 : 0;

  const getScoreVariant = () => {
    if (totalPoints >= 75) return { color: "text-primary", label: "Aprobado", variant: "default" as const };
    if (totalPoints >= 60) return { color: "text-yellow-600", label: "Observaciones", variant: "secondary" as const };
    return { color: "text-destructive", label: "No Aprobado", variant: "destructive" as const };
  };

  const scoreInfo = getScoreVariant();

  if (criteriaLoading || resultsLoading) {
    return (
      <Card data-testid="component-evaluation-matrix">
        <CardHeader>
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-2 w-full mt-2" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="component-evaluation-matrix">
      <CardHeader>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <CardTitle>Matriz de Evaluación - {maxTotalPoints} Puntos</CardTitle>
          <div className="flex items-center gap-3">
            <Badge variant={scoreInfo.variant} className="text-base px-3 py-1" data-testid="badge-score-status">
              {scoreInfo.label}
            </Badge>
            <span className={`text-2xl font-bold ${scoreInfo.color}`} data-testid="text-total-score">
              {totalPoints} / {maxTotalPoints}
            </span>
          </div>
        </div>
        <Progress value={percentage} className="mt-2" />
      </CardHeader>
      
      <CardContent className="space-y-4">
        {sections.map((section) => {
          const isExpanded = expandedSections.has(section.category);
          
          return (
            <div key={section.category} className="border rounded-md">
              <button
                onClick={() => toggleSection(section.category)}
                className="w-full p-4 flex items-center justify-between hover-elevate active-elevate-2"
                data-testid={`button-toggle-${section.category}`}
              >
                <div className="flex items-center gap-3">
                  {isExpanded ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
                  <h3 className="font-semibold">{section.title}</h3>
                </div>
                <span className="text-sm font-semibold" data-testid={`text-section-score-${section.category}`}>
                  {section.currentPoints} / {section.maxPoints}
                </span>
              </button>
              
              {isExpanded && (
                <div className="p-4 pt-0 space-y-3">
                  {section.criteria.map((criterion) => (
                    <div
                      key={criterion.id}
                      className="flex items-start gap-3 p-2 rounded-md hover-elevate"
                      data-testid={`item-criterion-${criterion.id}`}
                    >
                      <Checkbox
                        checked={criterion.passed}
                        onCheckedChange={() => toggleCriterion(criterion.id, criterion.maxPoints, criterion.passed)}
                        disabled={readOnly || saveResultMutation.isPending}
                        data-testid={`checkbox-${criterion.id}`}
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between gap-4 mb-1">
                          <span className="text-sm font-medium">{criterion.name}</span>
                          <Badge variant="outline" className="text-xs" data-testid={`badge-points-${criterion.id}`}>
                            {criterion.maxPoints} pts
                          </Badge>
                        </div>
                        {criterion.description && criterion.description.length > 0 && (
                          <p className="text-xs text-muted-foreground">{criterion.description}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
