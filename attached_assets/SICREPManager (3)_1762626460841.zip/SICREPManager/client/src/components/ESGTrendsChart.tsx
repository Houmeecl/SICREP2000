import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import type { ProviderMetric } from "@shared/schema";

interface ESGTrendsChartProps {
  companyId: string;
  months?: number;
}

export default function ESGTrendsChart({ companyId, months = 6 }: ESGTrendsChartProps) {
  const { data: metrics, isLoading } = useQuery<ProviderMetric[]>({
    queryKey: ["/api/metrics/history", companyId, { months }],
    queryFn: async () => {
      const response = await fetch(`/api/metrics/history/${companyId}?months=${months}`);
      if (!response.ok) throw new Error("Error al cargar métricas históricas");
      return response.json();
    },
    enabled: !!companyId
  });

  if (isLoading) {
    return (
      <Card data-testid="component-esg-trends-chart">
        <CardHeader>
          <CardTitle>Evolución de Métricas ESG</CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!metrics || metrics.length === 0) {
    return (
      <Card data-testid="component-esg-trends-chart">
        <CardHeader>
          <CardTitle>Evolución de Métricas ESG</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground py-8">
            No hay datos históricos disponibles
          </p>
        </CardContent>
      </Card>
    );
  }

  const chartData = metrics.map(metric => ({
    period: `${metric.month}/${metric.year.toString().slice(2)}`,
    esgScore: metric.esgScore || 0,
    totalDispatches: metric.totalDispatches || 0,
    totalWeight: Math.round((metric.totalWeight || 0) / 10) // Dividir por 10 para mejor escala
  }));

  return (
    <Card data-testid="component-esg-trends-chart">
      <CardHeader>
        <CardTitle>Evolución de Métricas ESG (últimos {months} meses)</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis 
              dataKey="period" 
              className="text-xs"
              label={{ value: "Período", position: "insideBottom", offset: -5 }}
            />
            <YAxis 
              className="text-xs"
              label={{ value: "Score ESG", angle: -90, position: "insideLeft" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "6px"
              }}
            />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="esgScore" 
              stroke="hsl(var(--primary))" 
              strokeWidth={2}
              name="Score ESG"
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
            <Line 
              type="monotone" 
              dataKey="totalDispatches" 
              stroke="hsl(var(--chart-2))" 
              strokeWidth={2}
              name="Despachos"
              dot={{ r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
