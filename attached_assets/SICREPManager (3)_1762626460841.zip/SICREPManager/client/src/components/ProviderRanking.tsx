import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, TrendingUp, TrendingDown, Eye } from "lucide-react";

interface ProviderRankingItem {
  id: string;
  name: string;
  rut: string;
  esgScore: number;
  trend: number;
  co2Footprint: string;
  seal: "approved" | "warning" | "rejected";
  risk: "low" | "medium" | "high";
}

interface ProviderRankingProps {
  miningCompanyId?: string;
}

export default function ProviderRanking({ miningCompanyId }: ProviderRankingProps = {}) {
  const [searchTerm, setSearchTerm] = useState("");

  const { data: providers, isLoading } = useQuery<ProviderRankingItem[]>({
    queryKey: ["/api/providers/ranking", miningCompanyId],
    queryFn: async () => {
      const url = miningCompanyId 
        ? `/api/providers/ranking?miningCompanyId=${miningCompanyId}`
        : "/api/providers/ranking";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Error al cargar ranking");
      return response.json();
    }
  });

  const getSealBadge = (seal: ProviderRankingItem["seal"]) => {
    switch (seal) {
      case "approved":
        return { label: "✓ Aprobado", variant: "default" as const };
      case "warning":
        return { label: "⚠ Observado", variant: "secondary" as const };
      case "rejected":
        return { label: "✗ Rechazado", variant: "destructive" as const };
    }
  };

  const getRiskBadge = (risk: ProviderRankingItem["risk"]) => {
    switch (risk) {
      case "low":
        return { label: "Bajo", variant: "default" as const };
      case "medium":
        return { label: "Medio", variant: "secondary" as const };
      case "high":
        return { label: "Alto", variant: "destructive" as const };
    }
  };

  const filteredProviders = (providers || []).filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.rut.includes(searchTerm)
  );

  if (isLoading) {
    return (
      <Card data-testid="component-provider-ranking">
        <CardContent className="py-12">
          <div className="flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Cargando proveedores...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="component-provider-ranking">
      <CardHeader>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <CardTitle>Ranking de Proveedores ESG</CardTitle>
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nombre o RUT..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
              data-testid="input-search-provider"
            />
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-2 text-xs font-semibold uppercase text-muted-foreground">
                  Proveedor
                </th>
                <th className="text-left py-3 px-2 text-xs font-semibold uppercase text-muted-foreground">
                  RUT
                </th>
                <th className="text-center py-3 px-2 text-xs font-semibold uppercase text-muted-foreground">
                  Score ESG
                </th>
                <th className="text-center py-3 px-2 text-xs font-semibold uppercase text-muted-foreground">
                  Tendencia
                </th>
                <th className="text-left py-3 px-2 text-xs font-semibold uppercase text-muted-foreground">
                  Huella CO₂
                </th>
                <th className="text-center py-3 px-2 text-xs font-semibold uppercase text-muted-foreground">
                  Sello SICREP
                </th>
                <th className="text-center py-3 px-2 text-xs font-semibold uppercase text-muted-foreground">
                  Riesgo
                </th>
                <th className="text-center py-3 px-2 text-xs font-semibold uppercase text-muted-foreground">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredProviders.map((provider) => {
                const seal = getSealBadge(provider.seal);
                const risk = getRiskBadge(provider.risk);
                
                return (
                  <tr
                    key={provider.id}
                    className="border-b hover-elevate"
                    data-testid={`row-provider-${provider.id}`}
                  >
                    <td className="py-4 px-2">
                      <span className="font-medium" data-testid={`text-provider-name-${provider.id}`}>
                        {provider.name}
                      </span>
                    </td>
                    <td className="py-4 px-2">
                      <span className="font-mono text-sm text-muted-foreground" data-testid={`text-provider-rut-${provider.id}`}>
                        {provider.rut}
                      </span>
                    </td>
                    <td className="py-4 px-2">
                      <div className="flex justify-center">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="text-lg font-bold text-primary" data-testid={`text-esg-score-${provider.id}`}>
                            {provider.esgScore}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-2">
                      <div className="flex items-center justify-center gap-1">
                        {provider.trend > 0 ? (
                          <TrendingUp className="w-4 h-4 text-primary" />
                        ) : (
                          <TrendingDown className="w-4 h-4 text-destructive" />
                        )}
                        <span className={`text-sm font-semibold ${provider.trend > 0 ? "text-primary" : "text-destructive"}`} data-testid={`text-trend-${provider.id}`}>
                          {provider.trend > 0 ? "+" : ""}{provider.trend}%
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-2">
                      <span className="text-sm" data-testid={`text-co2-${provider.id}`}>
                        {provider.co2Footprint} tCO₂
                      </span>
                    </td>
                    <td className="py-4 px-2">
                      <div className="flex justify-center">
                        <Badge variant={seal.variant} data-testid={`badge-seal-${provider.id}`}>
                          {seal.label}
                        </Badge>
                      </div>
                    </td>
                    <td className="py-4 px-2">
                      <div className="flex justify-center">
                        <Badge variant={risk.variant} data-testid={`badge-risk-${provider.id}`}>
                          {risk.label}
                        </Badge>
                      </div>
                    </td>
                    <td className="py-4 px-2">
                      <div className="flex justify-center">
                        <Button size="icon" variant="ghost" data-testid={`button-view-${provider.id}`}>
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {filteredProviders.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            No se encontraron proveedores
          </div>
        )}
      </CardContent>
    </Card>
  );
}
