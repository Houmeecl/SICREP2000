import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import KPICard from "./KPICard";
import ProgressBar from "./ProgressBar";
import ESGTrendsChart from "./ESGTrendsChart";
import { Package, FileCheck, TrendingUp, AlertTriangle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useAuth } from "@/contexts/AuthContext";

export default function DashboardOverview() {
  const { company } = useAuth();

  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ["/api/dashboard", company?.id],
    queryFn: async () => {
      const response = await fetch(`/api/dashboard/${company?.id}`);
      if (!response.ok) {
        throw new Error("Error al cargar datos del dashboard");
      }
      return response.json();
    },
    enabled: !!company?.id
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando datos...</p>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="p-6 text-center text-muted-foreground">
        No hay datos disponibles
      </div>
    );
  }

  const { monthlyDispatches, monthlyWeight, yearlyUsage, annualLimit, activeCertifications, esgScore, materialDistribution } = dashboardData;

  const chartData = materialDistribution?.map((item: any) => ({
    material: item.material.charAt(0).toUpperCase() + item.material.slice(1),
    cantidad: parseInt(item.cantidad)
  })) || [];

  const utilizationPercentage = annualLimit > 0 ? Math.round((yearlyUsage / annualLimit) * 100) : 0;
  const hasWarning = utilizationPercentage > 70;

  return (
    <div className="space-y-6" data-testid="component-dashboard-overview">
      <div>
        <h1 className="text-3xl font-semibold mb-2">Dashboard Principal</h1>
        <p className="text-muted-foreground">Vista general de operaciones REP</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard
          icon={Package}
          label="Despachos Mensuales"
          value={`${monthlyWeight} kg`}
          trend={{ value: `${monthlyDispatches}`, positive: true }}
        />
        <KPICard
          icon={FileCheck}
          label="Certificaciones Activas"
          value={`${activeCertifications}`}
        />
        <KPICard
          icon={TrendingUp}
          label="Score ESG"
          value={`${esgScore}`}
          trend={{ value: "5%", positive: true }}
        />
        {hasWarning && (
          <KPICard
            icon={AlertTriangle}
            label="Límite Anual"
            value={`${utilizationPercentage}%`}
            variant={utilizationPercentage > 85 ? "danger" : "warning"}
          />
        )}
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Límite Anual de Despacho</CardTitle>
        </CardHeader>
        <CardContent>
          <ProgressBar current={yearlyUsage} total={annualLimit} label={`Año ${new Date().getFullYear()}`} />
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {chartData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Distribución por Material (kg)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="material" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "6px"
                    }}
                  />
                  <Legend />
                  <Bar dataKey="cantidad" fill="hsl(var(--primary))" name="Cantidad (kg)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {company?.id && <ESGTrendsChart companyId={company.id} months={6} />}
      </div>
    </div>
  );
}
