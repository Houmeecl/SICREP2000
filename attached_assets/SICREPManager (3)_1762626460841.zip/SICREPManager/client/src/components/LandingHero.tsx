import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import heroImage from "@assets/generated_images/Minería_sustentable_con_energías_renovables_3fa86c7c.png";

export default function LandingHero() {
  return (
    <section className="relative min-h-[70vh] flex items-center justify-start overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-transparent" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        <div className="max-w-2xl text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            CUMPLE CON LA LEY REP Y ACCEDE A GRAN MINERÍA
          </h1>
          
          <p className="text-lg mb-8 text-white/90">
            Cumple a empresa en directo para que entré a entregar suministros ourterese da reside despacho da la minería.
          </p>
          
          <div className="mb-8">
            <Link href="/login">
              <Button
                size="lg"
                className="bg-green-600 hover:bg-green-700 text-white px-8 min-h-12 text-base font-semibold"
                data-testid="button-comenzar-certificacion"
              >
                COMIENZA TU CERTIFICACIÓN
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
