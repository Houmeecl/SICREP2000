import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf, TrendingUp, ShieldCheck } from "lucide-react";

const services = [
  {
    icon: ShieldCheck,
    title: "1. Cumplimiento Legal",
    description: "Certificación oficial SICREP según Ley 20.920. Evita multas de hasta $6.2M CLP por incumplimiento de declaración RETC anual."
  },
  {
    icon: Leaf,
    title: "2. Trazabilidad NFC",
    description: "Sistema completo de trazabilidad digital con adhesivos NFC para cada embalaje. Validación instantánea y auditoría blockchain."
  },
  {
    icon: TrendingUp,
    title: "3. Acceso a Mineras",
    description: "Proveedores certificados SICREP acceden preferentemente a licitaciones mineras. Dashboard ESG para cumplir The Copper Mark 2026."
  }
];

export default function ServicesSection() {
  return (
    <section id="solucion" className="py-12 md:py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold mb-4">
            NUESTRA PROPUESTA DE VALOR
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="hover-elevate" data-testid={`card-service-${index}`}>
              <CardHeader>
                <div className="w-16 h-16 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                  <service.icon className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
