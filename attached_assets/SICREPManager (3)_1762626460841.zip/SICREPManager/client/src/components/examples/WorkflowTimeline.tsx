import WorkflowTimeline from '../WorkflowTimeline'

export default function WorkflowTimelineExample() {
  return (
    <div className="p-6 max-w-2xl">
      <WorkflowTimeline />
    </div>
  )
}
