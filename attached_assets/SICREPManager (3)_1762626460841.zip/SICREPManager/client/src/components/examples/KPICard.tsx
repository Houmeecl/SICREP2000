import KPICard from '../KPICard'
import { Package } from 'lucide-react'

export default function KPICardExample() {
  return (
    <div className="p-6 max-w-sm">
      <KPICard
        icon={Package}
        label="Despachos Mensuales"
        value="247 kg"
        trend={{ value: "12%", positive: true }}
      />
    </div>
  )
}
