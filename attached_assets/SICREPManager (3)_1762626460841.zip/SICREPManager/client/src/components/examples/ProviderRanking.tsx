import ProviderRanking from '../ProviderRanking'

export default function ProviderRankingExample() {
  return (
    <div className="p-6">
      <ProviderRanking />
    </div>
  )
}
