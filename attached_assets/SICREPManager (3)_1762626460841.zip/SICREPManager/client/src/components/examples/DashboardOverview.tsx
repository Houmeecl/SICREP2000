import DashboardOverview from '../DashboardOverview'

export default function DashboardOverviewExample() {
  return (
    <div className="p-6">
      <DashboardOverview />
    </div>
  )
}
