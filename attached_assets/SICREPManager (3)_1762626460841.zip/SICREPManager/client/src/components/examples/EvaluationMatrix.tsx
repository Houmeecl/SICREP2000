import EvaluationMatrix from '../EvaluationMatrix'

export default function EvaluationMatrixExample() {
  return (
    <div className="p-6 max-w-3xl">
      <EvaluationMatrix />
    </div>
  )
}
