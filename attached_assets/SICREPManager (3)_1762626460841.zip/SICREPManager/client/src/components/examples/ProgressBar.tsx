import ProgressBar from '../ProgressBar'

export default function ProgressBarExample() {
  return (
    <div className="p-6 max-w-md space-y-4">
      <ProgressBar current={210} total={300} label="Límite Anual 2024" />
      <ProgressBar current={255} total={300} label="Límite Anual 2024 (Advertencia)" />
      <ProgressBar current={285} total={300} label="Límite Anual 2024 (Crítico)" />
    </div>
  )
}
