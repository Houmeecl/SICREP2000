import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";

interface KPICardProps {
  icon: LucideIcon;
  label: string;
  value: string;
  trend?: {
    value: string;
    positive: boolean;
  };
  variant?: "default" | "warning" | "danger";
}

export default function KPICard({ icon: Icon, label, value, trend, variant = "default" }: KPICardProps) {
  const borderClass = variant === "warning" ? "border-yellow-500" : variant === "danger" ? "border-destructive" : "";
  
  return (
    <Card className={`${borderClass} hover-elevate`} data-testid="card-kpi">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Icon className="w-6 h-6 text-primary" />
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-1">{label}</p>
            <p className="text-3xl font-bold" data-testid="text-kpi-value">{value}</p>
          </div>
          
          {trend && (
            <Badge
              variant={trend.positive ? "default" : "destructive"}
              className="text-xs"
              data-testid="badge-trend"
            >
              {trend.positive ? "↑" : "↓"} {trend.value}
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
