import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface User {
  id: string;
  username: string;
  email: string;
  role: string;
  companyId?: string;
}

interface Company {
  id: string;
  name: string;
  rut: string;
  type: string;
  esgScore?: number;
  annualLimit?: number;
  yearlyUsage?: number;
}

interface AuthContextType {
  user: User | null;
  company: Company | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem("sicrep_user");
    const storedCompany = localStorage.getItem("sicrep_company");
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    if (storedCompany) {
      setCompany(JSON.parse(storedCompany));
    }
    
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string) => {
    const response = await apiRequest("POST", "/api/auth/login", {
      username,
      password
    });

    const data = await response.json();
    setUser(data.user);
    setCompany(data.company);
    
    localStorage.setItem("sicrep_user", JSON.stringify(data.user));
    if (data.company) {
      localStorage.setItem("sicrep_company", JSON.stringify(data.company));
    }
  };

  const logout = () => {
    setUser(null);
    setCompany(null);
    localStorage.removeItem("sicrep_user");
    localStorage.removeItem("sicrep_company");
    queryClient.clear();
  };

  return (
    <AuthContext.Provider value={{ user, company, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
