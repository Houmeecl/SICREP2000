import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Package, Edit, Archive } from "lucide-react";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { CPS } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export default function CPSManagement() {
  const { user, company } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCPS, setEditingCPS] = useState<CPS | null>(null);

  const [formData, setFormData] = useState({
    code: "",
    productName: "",
    productDescription: "",
    level: "primario" as "primario" | "secundario" | "terciario",
    averageWeight: ""
  });

  const { data: cpsRecords, isLoading } = useQuery<CPS[]>({
    queryKey: ["/api/cps", company?.id],
    enabled: !!company?.id
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/cps", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cps", company?.id] });
      setIsDialogOpen(false);
      resetForm();
      toast({
        title: "CPS Creado",
        description: "El código de producto ha sido registrado exitosamente"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo crear el CPS",
        variant: "destructive"
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => 
      apiRequest("PATCH", `/api/cps/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cps", company?.id] });
      setIsDialogOpen(false);
      setEditingCPS(null);
      resetForm();
      toast({
        title: "CPS Actualizado",
        description: "El código de producto ha sido actualizado"
      });
    }
  });

  const resetForm = () => {
    setFormData({
      code: "",
      productName: "",
      productDescription: "",
      level: "primario",
      averageWeight: ""
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const payload = {
      ...formData,
      companyId: company!.id,
      averageWeight: formData.averageWeight ? parseInt(formData.averageWeight) : null
    };

    if (editingCPS) {
      updateMutation.mutate({ id: editingCPS.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleEdit = (cps: CPS) => {
    setEditingCPS(cps);
    setFormData({
      code: cps.code,
      productName: cps.productName,
      productDescription: cps.productDescription || "",
      level: cps.level,
      averageWeight: cps.averageWeight?.toString() || ""
    });
    setIsDialogOpen(true);
  };

  const handleNew = () => {
    setEditingCPS(null);
    resetForm();
    setIsDialogOpen(true);
  };

  const getLevelLabel = (level: string) => {
    const labels: Record<string, string> = {
      primario: "Primario",
      secundario: "Secundario",
      terciario: "Terciario"
    };
    return labels[level] || level;
  };

  if (isLoading) {
    return (
      <div className="p-6" data-testid="page-cps-management">
        <p className="text-muted-foreground">Cargando códigos CPS...</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6" data-testid="page-cps-management">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Códigos Producto SICREP</h1>
          <p className="text-muted-foreground mt-1">
            Gestiona los códigos CPS de tus embalajes certificados
          </p>
        </div>
        <Button onClick={handleNew} data-testid="button-new-cps">
          <Plus className="w-4 h-4 mr-2" />
          Nuevo CPS
        </Button>
      </div>

      {(!cpsRecords || cpsRecords.length === 0) ? (
        <Card>
          <CardContent className="p-12 text-center">
            <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No hay códigos CPS registrados</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Crea tu primer código de producto para comenzar a certificar embalajes
            </p>
            <Button onClick={handleNew} data-testid="button-create-first-cps">
              <Plus className="w-4 h-4 mr-2" />
              Crear Primer CPS
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cpsRecords.map((cps) => (
            <Card key={cps.id} className="hover-elevate" data-testid={`card-cps-${cps.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg mb-1 truncate">{cps.productName}</CardTitle>
                    <code className="text-sm font-mono text-primary">{cps.code}</code>
                  </div>
                  {cps.isActive && (
                    <Badge variant="default" className="shrink-0">Activo</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {cps.productDescription && (
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {cps.productDescription}
                  </p>
                )}
                
                <div className="flex items-center gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Nivel:</span>
                    <Badge variant="outline" className="ml-2">
                      {getLevelLabel(cps.level)}
                    </Badge>
                  </div>
                  {cps.averageWeight && (
                    <div>
                      <span className="text-muted-foreground">Peso:</span>
                      <span className="ml-2 font-mono">{cps.averageWeight}g</span>
                    </div>
                  )}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => handleEdit(cps)}
                  data-testid={`button-edit-cps-${cps.id}`}
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Editar
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent data-testid="dialog-cps-form">
          <DialogHeader>
            <DialogTitle>
              {editingCPS ? "Editar" : "Nuevo"} Código CPS
            </DialogTitle>
            <DialogDescription>
              Complete la información del embalaje para generar su código SICREP
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="code">Código CPS *</Label>
              <Input
                id="code"
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                placeholder="CPS-ABC-001"
                required
                data-testid="input-code"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="productName">Nombre del Producto *</Label>
              <Input
                id="productName"
                value={formData.productName}
                onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                placeholder="Ej: Caja de cartón corrugado 60x40x30"
                required
                data-testid="input-product-name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="productDescription">Descripción</Label>
              <Textarea
                id="productDescription"
                value={formData.productDescription}
                onChange={(e) => setFormData({ ...formData, productDescription: e.target.value })}
                placeholder="Descripción detallada del embalaje"
                rows={3}
                data-testid="input-product-description"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="level">Nivel de Embalaje *</Label>
                <Select
                  value={formData.level}
                  onValueChange={(value: any) => setFormData({ ...formData, level: value })}
                >
                  <SelectTrigger data-testid="select-level">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="primario">Primario</SelectItem>
                    <SelectItem value="secundario">Secundario</SelectItem>
                    <SelectItem value="terciario">Terciario</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="averageWeight">Peso Promedio (g)</Label>
                <Input
                  id="averageWeight"
                  type="number"
                  value={formData.averageWeight}
                  onChange={(e) => setFormData({ ...formData, averageWeight: e.target.value })}
                  placeholder="500"
                  data-testid="input-average-weight"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsDialogOpen(false);
                  setEditingCPS(null);
                  resetForm();
                }}
                data-testid="button-cancel"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                data-testid="button-save-cps"
              >
                {(createMutation.isPending || updateMutation.isPending)
                  ? "Guardando..."
                  : editingCPS
                  ? "Actualizar"
                  : "Crear CPS"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
