import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, User } from "lucide-react";
import loginImage from "@assets/stock_images/solar_panels_industr_838da6e7.jpg";
import sicrepLogo from "@assets/ChatGPT Image 3 nov 2025, 03_29_38 p.m._1762584049547.png";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      await login(username, password);
      setLocation("/");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-1/2 relative">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${loginImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-black/50 to-black/60" />
        <div className="relative z-10 flex flex-col justify-center px-12 text-white">
          <div className="mb-8">
            <img 
              src={sicrepLogo} 
              alt="SICREP - Sistema de Certificación REP" 
              className="h-20 w-auto mb-6"
            />
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8 bg-background">
        <Card className="w-full max-w-md border-none shadow-none">
          <CardHeader className="space-y-4 pb-8">
            <div className="flex items-center justify-center mb-4">
              <img 
                src={sicrepLogo} 
                alt="SICREP - Sistema de Certificación REP" 
                className="h-12 w-auto"
              />
            </div>
            
            <CardTitle className="text-2xl text-center">Iniciar Sesión</CardTitle>
            <CardDescription className="text-center flex items-center justify-center gap-2">
              <User className="w-4 h-4" />
              Seleccionar tu Rol
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="username">Nombre de Usuario</Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Ingrese su usuario"
                  required
                  data-testid="input-username"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Ingrese su contraseña"
                  required
                  data-testid="input-password"
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={isLoading}
                data-testid="button-login"
              >
                {isLoading ? "Iniciando sesión..." : "Ingresar"}
              </Button>
              
              <div className="text-center">
                <a 
                  href="#" 
                  className="text-sm text-muted-foreground hover:underline"
                  data-testid="link-forgot-password"
                >
                  ¿Olvidaste tu contraseña?
                </a>
              </div>
            </form>

            <div className="mt-6 p-4 bg-muted/50 rounded-md">
              <p className="text-xs font-semibold mb-2">Credenciales de prueba:</p>
              <div className="text-xs space-y-1 text-muted-foreground">
                <p>Admin: <span className="font-mono">admin / password123</span></p>
                <p>Proveedor: <span className="font-mono">ecorecicla / password123</span></p>
                <p>Minera: <span className="font-mono">codelco / password123</span></p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
