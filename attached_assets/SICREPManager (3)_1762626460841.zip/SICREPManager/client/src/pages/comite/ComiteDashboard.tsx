import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Vote,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  FileText,
  AlertCircle,
  Building2
} from "lucide-react";
export default function ComiteDashboard() {
  const { data: certifications, isLoading } = useQuery<any[]>({
    queryKey: ["/api/certifications"],
  });

  const { data: companies } = useQuery<any[]>({
    queryKey: ["/api/companies"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Estadísticas de comité
  const pendingDecisions = certifications?.filter(c => 
    c.currentPhase === "decision_final"
  ).length || 0;
  const approvedDecisions = certifications?.filter(c => 
    c.currentPhase === "publicacion" && c.status === "active"
  ).length || 0;
  const totalDecisions = pendingDecisions + approvedDecisions;

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-comite-dashboard">
          Panel de Miembro del Comité
        </h1>
        <p className="text-muted-foreground mt-2">
          Votaciones y decisiones del comité técnico REP
        </p>
      </div>

      {/* Métricas del Comité */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Decisiones Pendientes</CardTitle>
            <Clock className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600" data-testid="value-pending-decisions">
              {pendingDecisions}
            </div>
            <p className="text-xs text-muted-foreground">Requieren votación</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Decisiones Aprobadas</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="value-approved-decisions">
              {approvedDecisions}
            </div>
            <p className="text-xs text-muted-foreground">Certificaciones emitidas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Total Decisiones</CardTitle>
            <Vote className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-total-decisions">
              {totalDecisions}
            </div>
            <p className="text-xs text-muted-foreground">Históricas</p>
          </CardContent>
        </Card>
      </div>

      {/* Votaciones Pendientes */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Vote className="h-5 w-5" />
              Votaciones Pendientes
            </CardTitle>
            <Badge variant="outline">{pendingDecisions} pendientes</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {certifications && certifications.filter(c => c.currentPhase === "decision_final").length > 0 ? (
            <div className="space-y-4">
              {certifications
                .filter(c => c.currentPhase === "decision_final")
                .map((cert) => {
                  const company = companies?.find(c => c.id === cert.companyId);
                  const isApproved = cert.overallScore && cert.overallScore >= 60;
                  
                  return (
                    <div
                      key={cert.id}
                      className="flex items-center justify-between p-4 border rounded-md hover-elevate"
                      data-testid={`vote-${cert.id}`}
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                          isApproved ? "bg-green-500/10" : "bg-destructive/10"
                        }`}>
                          <Building2 className={`h-5 w-5 ${
                            isApproved ? "text-green-600" : "text-destructive"
                          }`} />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{company?.name || "Empresa"}</p>
                          <p className="text-sm text-muted-foreground">
                            Score Final: {cert.overallScore}/100
                            {isApproved ? " - Recomendación: Aprobar" : " - Recomendación: Rechazar"}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge variant={isApproved ? "outline" : "destructive"} className={
                            isApproved ? "bg-green-50 dark:bg-green-950" : ""
                          }>
                            {isApproved ? (
                              <>
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Aprobar
                              </>
                            ) : (
                              <>
                                <XCircle className="h-3 w-3 mr-1" />
                                Rechazar
                              </>
                            )}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button variant="outline" size="sm" data-testid={`button-review-${cert.id}`}>
                          <FileText className="h-4 w-4 mr-2" />
                          Revisar
                        </Button>
                        <Button size="sm" variant={isApproved ? "default" : "destructive"} data-testid={`button-vote-${cert.id}`}>
                          <Vote className="h-4 w-4 mr-2" />
                          Votar
                        </Button>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay votaciones pendientes
            </p>
          )}
        </CardContent>
      </Card>

      {/* Decisiones Aprobadas */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              Decisiones Aprobadas por el Comité
            </CardTitle>
            <Button variant="outline" size="sm">Ver Historial</Button>
          </div>
        </CardHeader>
        <CardContent>
          {certifications && certifications.filter(c => c.currentPhase === "publicacion").length > 0 ? (
            <div className="space-y-3">
              {certifications
                .filter(c => c.currentPhase === "publicacion" && c.status === "active")
                .slice(0, 5)
                .map((cert) => {
                  const company = companies?.find(c => c.id === cert.companyId);
                  return (
                    <div
                      key={cert.id}
                      className="flex items-center justify-between p-3 border rounded-md"
                      data-testid={`approved-${cert.id}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                          <CheckCircle2 className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">{company?.name || "Empresa"}</p>
                          <p className="text-sm text-muted-foreground">
                            Aprobado - Score: {cert.overallScore}/100
                          </p>
                        </div>
                      </div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 dark:bg-green-950">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Aprobado
                        </Badge>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay decisiones aprobadas
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
