import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import ProviderRanking from "@/components/ProviderRanking";
import { Building2, Users, TrendingUp, Shield, Package, AlertTriangle } from "lucide-react";

interface AggregatedStats {
  totalProviders: number;
  activeProviders: number;
  averageESG: number;
  totalDispatches: number;
  totalWeight: number;
  approvedProviders: number;
  warningProviders: number;
  rejectedProviders: number;
}

export default function MiningDashboard() {
  const { company } = useAuth();

  const { data: stats, isLoading } = useQuery<AggregatedStats>({
    queryKey: ["/api/mining/stats", company?.id],
    queryFn: async () => {
      const response = await fetch(`/api/mining/stats/${company?.id}`);
      if (!response.ok) throw new Error("Error al cargar estadísticas");
      return response.json();
    },
    enabled: !!company?.id
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Cargando dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  const data = stats || {
    totalProviders: 0,
    activeProviders: 0,
    averageESG: 0,
    totalDispatches: 0,
    totalWeight: 0,
    approvedProviders: 0,
    warningProviders: 0,
    rejectedProviders: 0
  };

  const healthPercentage = data.totalProviders > 0 
    ? Math.round((data.approvedProviders / data.totalProviders) * 100) 
    : 0;

  return (
    <div className="p-8 space-y-6" data-testid="page-mining-dashboard">
      <div>
        <h1 className="text-3xl font-bold">Dashboard Empresa Minera</h1>
        <p className="text-muted-foreground">Monitoreo de proveedores y cumplimiento REP</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Proveedores</CardTitle>
            <Users className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalProviders}</div>
            <p className="text-xs text-muted-foreground">
              {data.activeProviders} activos este mes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Promedio ESG</CardTitle>
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.averageESG}/100</div>
            <p className="text-xs text-muted-foreground">
              Score promedio de proveedores
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despachos Totales</CardTitle>
            <Package className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalDispatches}</div>
            <p className="text-xs text-muted-foreground">
              {(data.totalWeight / 1000).toFixed(2)} kg total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Salud Red</CardTitle>
            <Shield className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{healthPercentage}%</div>
            <p className="text-xs text-muted-foreground">
              Proveedores aprobados
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Shield className="w-5 h-5 text-green-600" />
              Aprobados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{data.approvedProviders}</div>
            <p className="text-sm text-muted-foreground mt-1">
              Cumplimiento completo REP
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="w-5 h-5 text-yellow-600" />
              En Observación
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{data.warningProviders}</div>
            <p className="text-sm text-muted-foreground mt-1">
              Requieren seguimiento
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              Rechazados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{data.rejectedProviders}</div>
            <p className="text-sm text-muted-foreground mt-1">
              No cumplen requisitos
            </p>
          </CardContent>
        </Card>
      </div>

      {healthPercentage < 60 && (
        <Card className="border-destructive bg-destructive/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              <CardTitle className="text-destructive">Alerta de Cumplimiento</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm">
              Menos del 60% de sus proveedores están aprobados. Considere implementar un plan de mejora 
              o revisar los criterios de selección de proveedores para garantizar el cumplimiento normativo.
            </p>
          </CardContent>
        </Card>
      )}

      <ProviderRanking miningCompanyId={company?.id} />

      <Card>
        <CardHeader>
          <CardTitle>Información de la Red</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Empresa Minera:</span>
            <span className="font-semibold">{company?.name}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">RUT:</span>
            <span className="font-mono text-sm">{company?.rut}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Proveedores Activos:</span>
            <Badge>{data.activeProviders}</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Compliance Status:</span>
            <Badge variant={healthPercentage >= 80 ? "default" : healthPercentage >= 60 ? "secondary" : "destructive"}>
              {healthPercentage >= 80 ? "Excelente" : healthPercentage >= 60 ? "Bueno" : "Requiere Atención"}
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
