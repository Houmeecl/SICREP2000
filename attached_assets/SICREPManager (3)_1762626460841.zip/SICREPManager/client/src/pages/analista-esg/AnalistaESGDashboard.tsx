import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import {
  Leaf,
  TrendingDown,
  Scale,
  Award,
  Building2,
  BarChart3,
  Globe,
  CheckCircle2,
  AlertCircle,
  Download
} from "lucide-react";

export default function AnalistaESGDashboard() {
  const { toast } = useToast();
  const [downloadingPdf, setDownloadingPdf] = useState<string | null>(null);

  const handleDownloadESG = async (companyId: string, companyName?: string) => {
    try {
      setDownloadingPdf(companyId);
      const response = await fetch(`/api/reports/esg/${companyId}`);
      
      if (!response.ok) {
        throw new Error('Error al generar el reporte ESG');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Reporte-ESG-${companyName || companyId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Reporte ESG descargado",
        description: "El reporte ESG se ha descargado exitosamente.",
      });
    } catch (error) {
      console.error('Error downloading PDF:', error);
      toast({
        title: "Error",
        description: "No se pudo descargar el reporte ESG. Intente nuevamente.",
        variant: "destructive",
      });
    } finally {
      setDownloadingPdf(null);
    }
  };
  const { data: companies, isLoading } = useQuery<any[]>({
    queryKey: ["/api/companies"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Métricas ESG
  const avgESGScore = companies && companies.length > 0
    ? companies.reduce((acc, c) => acc + (c.esgScore || 0), 0) / companies.length
    : 0;
  
  const totalCO2Footprint = companies?.reduce((acc, c) => acc + (c.co2Footprint || 0), 0) || 0;
  const copperMarkCertified = companies?.filter(c => c.copperMarkCertified).length || 0;
  const companiesWithGoodGovernance = companies?.filter(c => (c.esgScore || 0) >= 70).length || 0;

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="heading-analista-esg-dashboard">
            Panel de Analista ESG
          </h1>
          <p className="text-muted-foreground mt-2">
            Análisis ambiental, social y gobernanza - Copper Mark
          </p>
        </div>
        {companies && companies.length > 0 && (
          <Button 
            variant="outline"
            onClick={() => handleDownloadESG(companies[0].id, "Consolidado")}
            disabled={downloadingPdf !== null}
            data-testid="button-download-esg-report"
          >
            <Download className="h-4 w-4 mr-2" />
            {downloadingPdf ? "Generando..." : "Descargar Reporte ESG"}
          </Button>
        )}
      </div>

      {/* Métricas ESG Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Promedio ESG</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-avg-esg">
              {avgESGScore.toFixed(1)}
            </div>
            <p className="text-xs text-muted-foreground">De 100 puntos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Huella de Carbono</CardTitle>
            <Leaf className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="value-co2-footprint">
              {totalCO2Footprint.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">Toneladas CO₂e/año</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Copper Mark</CardTitle>
            <Award className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600" data-testid="value-copper-mark">
              {copperMarkCertified}
            </div>
            <p className="text-xs text-muted-foreground">Empresas certificadas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Buena Gobernanza</CardTitle>
            <Scale className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-good-governance">
              {companiesWithGoodGovernance}
            </div>
            <p className="text-xs text-muted-foreground">Score ESG ≥ 70</p>
          </CardContent>
        </Card>
      </div>

      {/* Análisis de Huella de Carbono */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-green-600" />
            Análisis de Huella de Carbono por Empresa
          </CardTitle>
        </CardHeader>
        <CardContent>
          {companies && companies.length > 0 ? (
            <div className="space-y-4">
              {companies
                .sort((a, b) => (b.co2Footprint || 0) - (a.co2Footprint || 0))
                .slice(0, 8)
                .map((company) => {
                  const co2 = company.co2Footprint || 0;
                  const maxCO2 = Math.max(...(companies.map(c => c.co2Footprint || 0)));
                  const percentage = maxCO2 > 0 ? (co2 / maxCO2) * 100 : 0;
                  
                  return (
                    <div key={company.id} className="space-y-2" data-testid={`co2-${company.id}`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Building2 className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{company.name}</span>
                        </div>
                        <span className="text-sm font-semibold">
                          {co2.toFixed(2)} toneladas CO₂e
                        </span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  );
                })}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay datos de huella de carbono
            </p>
          )}
        </CardContent>
      </Card>

      {/* Certificación Copper Mark */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-amber-600" />
              Estado Copper Mark
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Empresas</span>
              <span className="font-semibold">{companies?.length || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Certificadas Copper Mark</span>
              <span className="font-semibold text-amber-600">{copperMarkCertified}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Tasa de Certificación</span>
              <span className="font-semibold">
                {companies && companies.length > 0
                  ? Math.round((copperMarkCertified / companies.length) * 100)
                  : 0}%
              </span>
            </div>
            <Progress 
              value={companies && companies.length > 0 ? (copperMarkCertified / companies.length) * 100 : 0} 
              className="h-3 mt-4"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              Gobernanza y Compliance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950/20 rounded-md">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-green-700 dark:text-green-400">
                  Gobernanza Excelente
                </p>
                <p className="text-xs text-muted-foreground">
                  {companiesWithGoodGovernance} empresas con ESG ≥ 70
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 p-3 bg-amber-50 dark:bg-amber-950/20 rounded-md">
              <AlertCircle className="h-5 w-5 text-amber-600" />
              <div>
                <p className="text-sm font-medium text-amber-700 dark:text-amber-400">
                  Requieren Mejora
                </p>
                <p className="text-xs text-muted-foreground">
                  {(companies?.length || 0) - companiesWithGoodGovernance} empresas con ESG &lt; 70
                </p>
              </div>
            </div>
            <Button className="w-full mt-4" variant="outline">
              <BarChart3 className="h-4 w-4 mr-2" />
              Generar Informe ESG Completo
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
