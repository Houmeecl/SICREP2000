import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import {
  Package,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  QrCode,
  Scale,
  Calendar,
  BarChart3,
  FileText,
  Plus,
  Send,
  Clock
} from "lucide-react";

export default function ProveedorDashboard() {
  const { user, company } = useAuth();

  const { data: dispatches, isLoading } = useQuery<any[]>({
    queryKey: ["/api/dispatches"],
  });

  const { data: cpsProducts } = useQuery<any[]>({
    queryKey: ["/api/cps"],
  });

  const { data: certifications } = useQuery<any[]>({
    queryKey: ["/api/certifications"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Calcular métricas
  const currentYearlyUsage = company?.yearlyUsage || 0; // en gramos
  const annualLimit = (company?.annualLimit || 300) * 1000; // convertir kg a gramos
  const usagePercentage = (currentYearlyUsage / annualLimit) * 100;
  const remainingKg = ((annualLimit - currentYearlyUsage) / 1000).toFixed(2);

  const totalDispatches = dispatches?.length || 0;
  const totalCPS = cpsProducts?.length || 0;
  const myCertifications = certifications?.filter((c: any) => c.companyId === company?.id) || [];
  const activeCertification = myCertifications.find((c: any) => 
    c.status === "active" || c.currentPhase !== "publicacion"
  );

  const thisMonthDispatches = dispatches?.filter((d: any) => {
    const dispatchDate = new Date(d.date);
    const now = new Date();
    return dispatchDate.getMonth() === now.getMonth() && 
           dispatchDate.getFullYear() === now.getFullYear();
  }).length || 0;

  // Estado de compliance
  const isCompliant = usagePercentage < 100;
  const isWarning = usagePercentage >= 80 && usagePercentage < 100;
  const isOverLimit = usagePercentage >= 100;

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-proveedor-dashboard">
          Panel de Proveedor
        </h1>
        <p className="text-muted-foreground mt-2">
          Gestión de despachos, trazabilidad NFC y cumplimiento REP
        </p>
      </div>

      {/* Alertas de Compliance */}
      {isOverLimit && (
        <Card className="border-destructive bg-destructive/5">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <AlertCircle className="h-8 w-8 text-destructive" />
              <div>
                <h3 className="font-semibold text-destructive">Límite Anual Excedido</h3>
                <p className="text-sm text-muted-foreground">
                  Has superado el límite de 300kg. Contacta a soporte@sicrep.cl para regularizar.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {isWarning && !isOverLimit && (
        <Card className="border-amber-500 bg-amber-50 dark:bg-amber-950/20">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <AlertCircle className="h-8 w-8 text-amber-600" />
              <div>
                <h3 className="font-semibold text-amber-700 dark:text-amber-500">
                  Acercándose al Límite Anual
                </h3>
                <p className="text-sm text-muted-foreground">
                  Solo quedan {remainingKg}kg disponibles de tu límite anual.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Despachos este Mes</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-monthly-dispatches">
              {thisMonthDispatches}
            </div>
            <p className="text-xs text-muted-foreground">Total año: {totalDispatches}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Códigos CPS</CardTitle>
            <QrCode className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-total-cps">{totalCPS}</div>
            <p className="text-xs text-muted-foreground">Productos registrados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Uso Anual</CardTitle>
            <Scale className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-yearly-usage">
              {(currentYearlyUsage / 1000).toFixed(2)}kg
            </div>
            <p className="text-xs text-muted-foreground">
              De {company?.annualLimit || 300}kg límite
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Estado Certificación</CardTitle>
            {activeCertification ? (
              <CheckCircle2 className="h-4 w-4 text-green-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-amber-600" />
            )}
          </CardHeader>
          <CardContent>
            {activeCertification ? (
              <div>
                <Badge variant="outline" className="bg-green-50 dark:bg-green-950">
                  Activa
                </Badge>
                <p className="text-xs text-muted-foreground mt-2">
                  Fase: {activeCertification.currentPhase}
                </p>
              </div>
            ) : (
              <div>
                <Badge variant="outline">Sin Certificación</Badge>
                <p className="text-xs text-muted-foreground mt-2">
                  Solicita tu certificación REP
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Progreso de Uso Anual */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Uso Anual de Embalajes REP
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Límite de 300kg</span>
              <span className="text-2xl font-bold">
                {usagePercentage.toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={Math.min(usagePercentage, 100)} 
              className={`h-3 ${isOverLimit ? "bg-destructive/20" : isWarning ? "bg-amber-100 dark:bg-amber-950" : ""}`}
            />
            <div className="flex items-center justify-between mt-2">
              <p className="text-xs text-muted-foreground">
                Usado: {(currentYearlyUsage / 1000).toFixed(2)}kg
              </p>
              <p className="text-xs text-muted-foreground">
                Disponible: {remainingKg}kg
              </p>
            </div>
          </div>

          {isCompliant && !isWarning && (
            <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950/20 rounded-md">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <p className="text-sm text-green-700 dark:text-green-400">
                Cumplimiento REP: En regla
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Acciones Rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="hover-elevate cursor-pointer" data-testid="card-new-dispatch">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Package className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold">Nuevo Despacho</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Registra un nuevo envío con trazabilidad NFC
                </p>
              </div>
              <Button asChild className="w-full" data-testid="button-new-dispatch">
                <a href="/despachos">
                  Crear Despacho
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate cursor-pointer" data-testid="card-new-cps">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="h-12 w-12 rounded-full bg-purple-500/10 flex items-center justify-center">
                <QrCode className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold">Registrar CPS</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Añade un nuevo código de producto SICREP
                </p>
              </div>
              <Button asChild variant="outline" className="w-full" data-testid="button-new-cps">
                <a href="/cps">
                  Crear CPS
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate cursor-pointer" data-testid="card-view-certification">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center">
                <CheckCircle2 className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold">Mi Certificación</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Ver estado y avances de certificación REP
                </p>
              </div>
              <Button asChild variant="outline" className="w-full" data-testid="button-view-certification">
                <a href="/certificaciones">
                  Ver Certificación
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Despachos Recientes */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Últimos Despachos</CardTitle>
            <Button variant="outline" size="sm" asChild>
              <a href="/despachos">Ver Todos</a>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {dispatches && dispatches.length > 0 ? (
            <div className="space-y-3">
              {dispatches.slice(0, 5).map((dispatch: any) => (
                <div
                  key={dispatch.id}
                  className="flex items-center justify-between p-3 border rounded-md"
                  data-testid={`dispatch-${dispatch.id}`}
                >
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Package className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{dispatch.description || "Despacho"}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(dispatch.date).toLocaleDateString("es-CL")}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{(dispatch.totalWeight / 1000).toFixed(2)}kg</p>
                    {dispatch.nfcTag && (
                      <Badge variant="outline" className="text-xs mt-1">
                        <QrCode className="h-3 w-3 mr-1" />
                        NFC
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay despachos registrados. Crea tu primer despacho para empezar.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
