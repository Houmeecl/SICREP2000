import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  NfcIcon,
  Package,
  Scale,
  QrCode,
  CheckCircle2,
  AlertCircle,
  Download,
  Send,
  Camera,
  MapPin
} from "lucide-react";

export default function CertificacionEmbalajes() {
  const { user, company } = useAuth();
  const { toast } = useToast();
  const [isScanning, setIsScanning] = useState(false);
  const [nfcData, setNfcData] = useState<any>(null);
  const [selectedCPS, setSelectedCPS] = useState("");
  const [pesoTotal, setPesoTotal] = useState("");
  const [tara, setTara] = useState("");
  const [ubicacion, setUbicacion] = useState("");
  
  const { data: cpsProducts } = useQuery<any[]>({
    queryKey: ["/api/cps"],
  });

  const { data: nfcTags } = useQuery<any[]>({
    queryKey: ["/api/nfc-tags"],
  });

  // Web NFC API - Lectura
  const handleScanNFC = async () => {
    if (!('NDEFReader' in window)) {
      toast({
        title: "NFC no soportado",
        description: "Tu dispositivo no soporta Web NFC. Usa Chrome en Android.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsScanning(true);
      const ndef = new (window as any).NDEFReader();
      await ndef.scan();

      toast({
        title: "Escaneando...",
        description: "Acerca tu dispositivo al tag NFC",
      });

      ndef.addEventListener("reading", ({ message, serialNumber }: any) => {
        const uid = serialNumber;
        setNfcData({ uid, message });
        setIsScanning(false);
        
        toast({
          title: "Tag detectado",
          description: `UID: ${uid}`,
        });
      });
    } catch (error: any) {
      setIsScanning(false);
      toast({
        title: "Error al escanear",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Web NFC API - Escritura
  const handleWriteNFC = async () => {
    if (!selectedCPS || !nfcData) {
      toast({
        title: "Datos incompletos",
        description: "Selecciona un CPS y escanea un tag NFC primero",
        variant: "destructive",
      });
      return;
    }

    try {
      const ndef = new (window as any).NDEFReader();
      const cps = cpsProducts?.find(c => c.id === selectedCPS);
      
      await ndef.write({
        records: [
          { recordType: "url", data: `https://sicrep.cl/trace/${nfcData.uid}` },
          { recordType: "text", data: `CPS:${cps?.code}|UID:${nfcData.uid}` }
        ]
      });

      toast({
        title: "Tag grabado",
        description: "Embalaje vinculado exitosamente",
      });

      // Crear registro en backend
      createNfcTagMutation.mutate({
        uidTag: nfcData.uid,
        cpsId: selectedCPS,
        companyId: company?.id,
        nivel: cps?.level,
        qrCode: `https://sicrep.cl/trace/${nfcData.uid}`,
      });
    } catch (error: any) {
      toast({
        title: "Error al escribir",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const createNfcTagMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/api/nfc-tags', 'POST', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nfc-tags'] });
      toast({
        title: "Embalaje certificado",
        description: "Tag NFC registrado en el sistema",
      });
      setNfcData(null);
      setSelectedCPS("");
    },
  });

  const registerPesoMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('/api/peso-mediciones', 'POST', data);
    },
    onSuccess: () => {
      toast({
        title: "Peso registrado",
        description: "Medición guardada exitosamente",
      });
    },
  });

  const handleRegisterPeso = () => {
    if (!nfcData || !pesoTotal) {
      toast({
        title: "Datos incompletos",
        description: "Escanea un tag y registra el peso",
        variant: "destructive",
      });
      return;
    }

    const tag = nfcTags?.find(t => t.uidTag === nfcData.uid);
    if (!tag) {
      toast({
        title: "Tag no encontrado",
        description: "Primero certifica el embalaje",
        variant: "destructive",
      });
      return;
    }

    registerPesoMutation.mutate({
      nfcTagId: tag.id,
      totalGr: parseInt(pesoTotal) * 1000, // kg a gramos
      metodo: "balanza",
      actorRut: user?.username || "",
      actorNombre: user?.username || "",
      ubicacion: ubicacion || "Sin ubicación",
      hashIntegridad: generateHash(nfcData.uid, pesoTotal),
    });
  };

  const generateHash = (uid: string, peso: string) => {
    return btoa(`${uid}-${peso}-${Date.now()}`);
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-certificacion-embalajes">
          Certificación de Embalajes
        </h1>
        <p className="text-muted-foreground mt-2">
          Certifica tus embalajes con tecnología NFC y trazabilidad REP
        </p>
      </div>

      {/* Alertas */}
      {!('NDEFReader' in window) && (
        <Card className="border-amber-500 bg-amber-50 dark:bg-amber-950/20">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <AlertCircle className="h-8 w-8 text-amber-600" />
              <div>
                <h3 className="font-semibold text-amber-700 dark:text-amber-500">
                  NFC no disponible
                </h3>
                <p className="text-sm text-muted-foreground">
                  Web NFC solo funciona en Chrome/Edge para Android. Utiliza un dispositivo compatible.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Panel de Certificación */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <NfcIcon className="h-5 w-5" />
              1. Certificar Embalaje
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cps-select">Seleccionar Producto CPS</Label>
              <Select value={selectedCPS} onValueChange={setSelectedCPS}>
                <SelectTrigger id="cps-select" data-testid="select-cps">
                  <SelectValue placeholder="Selecciona un CPS" />
                </SelectTrigger>
                <SelectContent>
                  {cpsProducts?.map((cps) => (
                    <SelectItem key={cps.id} value={cps.id}>
                      {cps.code} - {cps.productName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Button
                onClick={handleScanNFC}
                disabled={isScanning || !selectedCPS}
                className="w-full"
                variant={nfcData ? "outline" : "default"}
                data-testid="button-scan-nfc"
              >
                <NfcIcon className="h-4 w-4 mr-2" />
                {isScanning ? "Escaneando..." : nfcData ? "Tag Detectado" : "Escanear Tag NFC"}
              </Button>
              
              {nfcData && (
                <div className="p-3 bg-green-50 dark:bg-green-950/20 rounded-md">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium">UID: {nfcData.uid}</span>
                  </div>
                </div>
              )}
            </div>

            <Button
              onClick={handleWriteNFC}
              disabled={!nfcData || !selectedCPS || createNfcTagMutation.isPending}
              className="w-full"
              data-testid="button-write-nfc"
            >
              <Send className="h-4 w-4 mr-2" />
              {createNfcTagMutation.isPending ? "Certificando..." : "Certificar Embalaje"}
            </Button>
          </CardContent>
        </Card>

        {/* Panel de Peso */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Scale className="h-5 w-5" />
              2. Registrar Peso
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="tara">Tara (kg)</Label>
              <Input
                id="tara"
                type="number"
                step="0.001"
                placeholder="0.000"
                value={tara}
                onChange={(e) => setTara(e.target.value)}
                data-testid="input-tara"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="peso-total">Peso Total (kg)</Label>
              <Input
                id="peso-total"
                type="number"
                step="0.001"
                placeholder="0.000"
                value={pesoTotal}
                onChange={(e) => setPesoTotal(e.target.value)}
                data-testid="input-peso-total"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ubicacion">Ubicación</Label>
              <div className="flex gap-2">
                <Input
                  id="ubicacion"
                  placeholder="Bodega A - Sector 3"
                  value={ubicacion}
                  onChange={(e) => setUbicacion(e.target.value)}
                  data-testid="input-ubicacion"
                />
                <Button variant="outline" size="icon" data-testid="button-gps">
                  <MapPin className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <Button
              onClick={handleRegisterPeso}
              disabled={!nfcData || !pesoTotal || registerPesoMutation.isPending}
              className="w-full"
              data-testid="button-register-peso"
            >
              <Scale className="h-4 w-4 mr-2" />
              {registerPesoMutation.isPending ? "Registrando..." : "Registrar Medición"}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Embalajes Certificados */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Embalajes Certificados Recientes</CardTitle>
            <Badge variant="outline">{nfcTags?.length || 0} certificados</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {nfcTags && nfcTags.length > 0 ? (
            <div className="space-y-3">
              {nfcTags.slice(0, 10).map((tag: any) => {
                const cps = cpsProducts?.find(c => c.id === tag.cpsId);
                return (
                  <div
                    key={tag.id}
                    className="flex items-center justify-between p-4 border rounded-md hover-elevate"
                    data-testid={`nfc-tag-${tag.id}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <QrCode className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{cps?.productName || "Producto"}</p>
                        <p className="text-sm text-muted-foreground font-mono">
                          UID: {tag.uidTag.slice(0, 16)}...
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={tag.status === "activo" ? "default" : "secondary"}>
                        {tag.status}
                      </Badge>
                      <Button variant="outline" size="sm" data-testid={`button-download-cert-${tag.id}`}>
                        <Download className="h-4 w-4 mr-2" />
                        Certificado
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                No hay embalajes certificados. Escanea tu primer tag NFC para empezar.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
