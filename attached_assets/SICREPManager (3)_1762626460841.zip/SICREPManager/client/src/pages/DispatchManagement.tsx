import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Package, TrendingUp, Calendar, MapPin, AlertTriangle, Plus, CheckCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface CPS {
  id: string;
  code: string;
  productName: string;
  level: string;
  averageWeight: number;
}

interface Dispatch {
  id: string;
  nfcTag: string;
  totalWeight: number;
  status: string;
  origin: string;
  destination: string;
  dispatchDate: string;
  cpsId: string;
}

export default function DispatchManagement() {
  const { company } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    cpsId: "",
    quantity: 1,
    origin: "",
    destination: "",
    nfcTag: ""
  });

  const { data: cpsCodes = [] } = useQuery<CPS[]>({
    queryKey: ["/api/cps", company?.id],
    enabled: !!company?.id
  });

  const { data: dispatches = [] } = useQuery<Dispatch[]>({
    queryKey: ["/api/dispatches", company?.id],
    enabled: !!company?.id
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const selectedCPS = cpsCodes.find(cps => cps.id === data.cpsId);
      if (!selectedCPS) {
        throw new Error("Código CPS no encontrado");
      }

      const totalWeight = selectedCPS.averageWeight * data.quantity;
      
      const dispatchPayload = {
        companyId: company?.id,
        cpsId: data.cpsId,
        nfcTag: data.nfcTag || `NFC-${Date.now()}`,
        totalWeight,
        status: "registrado",
        origin: data.origin,
        destination: data.destination,
        dispatchDate: new Date().toISOString()
      };

      return apiRequest("POST", "/api/dispatches", dispatchPayload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dispatches", company?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      setIsDialogOpen(false);
      resetForm();
      toast({
        title: "Despacho Registrado",
        description: "El despacho ha sido registrado exitosamente"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo registrar el despacho",
        variant: "destructive"
      });
    }
  });

  const resetForm = () => {
    setFormData({
      cpsId: "",
      quantity: 1,
      origin: "",
      destination: "",
      nfcTag: ""
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.cpsId || !formData.origin || !formData.destination) {
      toast({
        title: "Error de Validación",
        description: "Complete todos los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    const selectedCPS = cpsCodes.find(cps => cps.id === formData.cpsId);
    if (!selectedCPS) {
      toast({
        title: "Error",
        description: "Código CPS no válido",
        variant: "destructive"
      });
      return;
    }

    const totalWeight = selectedCPS.averageWeight * formData.quantity;
    const yearlyUsageKg = (company?.yearlyUsage || 0) / 1000;
    const newTotalKg = yearlyUsageKg + (totalWeight / 1000);

    if (newTotalKg > (company?.annualLimit || 300)) {
      toast({
        title: "Límite Anual Excedido",
        description: `Este despacho excedería el límite anual de ${company?.annualLimit}kg. Uso actual: ${yearlyUsageKg.toFixed(2)}kg`,
        variant: "destructive"
      });
      return;
    }

    createMutation.mutate(formData);
  };

  const selectedCPS = cpsCodes.find(cps => cps.id === formData.cpsId);
  const estimatedWeight = selectedCPS ? (selectedCPS.averageWeight * formData.quantity) / 1000 : 0;
  const yearlyUsageKg = (company?.yearlyUsage || 0) / 1000;
  const remainingKg = (company?.annualLimit || 300) - yearlyUsageKg;
  const usagePercentage = (yearlyUsageKg / (company?.annualLimit || 300)) * 100;

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: any; label: string }> = {
      registrado: { variant: "secondary", label: "Registrado" },
      en_transito: { variant: "default", label: "En Tránsito" },
      recibido: { variant: "outline", label: "Recibido" },
      verificado: { variant: "default", label: "Verificado" },
      certificado: { variant: "default", label: "Certificado" }
    };
    const config = variants[status] || { variant: "secondary", label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestión de Despachos</h1>
          <p className="text-muted-foreground">Registre y monitoree los despachos de embalajes certificados</p>
        </div>
        <Button onClick={() => setIsDialogOpen(true)} data-testid="button-new-dispatch">
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Despacho
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Uso Anual</CardTitle>
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{yearlyUsageKg.toFixed(2)} kg</div>
            <p className="text-xs text-muted-foreground">
              de {company?.annualLimit || 300} kg permitidos
            </p>
            <div className="mt-3 h-2 bg-secondary rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all ${usagePercentage > 90 ? 'bg-destructive' : usagePercentage > 70 ? 'bg-yellow-500' : 'bg-primary'}`}
                style={{ width: `${Math.min(usagePercentage, 100)}%` }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disponible</CardTitle>
            <Package className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{remainingKg.toFixed(2)} kg</div>
            <p className="text-xs text-muted-foreground">
              Capacidad restante {new Date().getFullYear()}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Despachos</CardTitle>
            <CheckCircle className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dispatches.length}</div>
            <p className="text-xs text-muted-foreground">
              Registrados en el sistema
            </p>
          </CardContent>
        </Card>
      </div>

      {usagePercentage > 90 && (
        <Card className="border-destructive bg-destructive/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              <CardTitle className="text-destructive">Alerta de Capacidad</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm">
              Ha utilizado más del 90% de su límite anual. Contacte a SICREP para gestionar una extensión si es necesario.
            </p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Despachos Recientes</CardTitle>
          <CardDescription>Historial de despachos registrados</CardDescription>
        </CardHeader>
        <CardContent>
          {dispatches.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Package className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p>No hay despachos registrados</p>
              <p className="text-sm">Comience registrando su primer despacho</p>
            </div>
          ) : (
            <div className="space-y-3">
              {dispatches.slice(0, 10).map((dispatch) => {
                const cps = cpsCodes.find(c => c.id === dispatch.cpsId);
                return (
                  <div key={dispatch.id} className="flex items-center justify-between p-4 rounded-lg border hover-elevate" data-testid={`dispatch-${dispatch.id}`}>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{cps?.code || "Sin CPS"}</span>
                        {getStatusBadge(dispatch.status)}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {dispatch.origin} → {dispatch.destination}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(dispatch.dispatchDate).toLocaleDateString('es-CL')}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">{(dispatch.totalWeight / 1000).toFixed(2)} kg</div>
                      <div className="text-xs text-muted-foreground font-mono">{dispatch.nfcTag}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Registrar Nuevo Despacho</DialogTitle>
            <DialogDescription>
              Complete la información del despacho de embalajes certificados
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cpsId">Código CPS *</Label>
              <Select
                value={formData.cpsId}
                onValueChange={(value) => setFormData({ ...formData, cpsId: value })}
              >
                <SelectTrigger data-testid="select-cps-code">
                  <SelectValue placeholder="Seleccione un código CPS" />
                </SelectTrigger>
                <SelectContent>
                  {cpsCodes.filter(cps => cps.averageWeight > 0).map((cps) => (
                    <SelectItem key={cps.id} value={cps.id}>
                      {cps.code} - {cps.productName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {cpsCodes.length === 0 && (
                <p className="text-xs text-muted-foreground">
                  No hay códigos CPS disponibles. Cree uno primero en la sección Códigos CPS.
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="quantity">Cantidad de Unidades *</Label>
              <Input
                id="quantity"
                type="number"
                min="1"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
                data-testid="input-quantity"
              />
            </div>

            {selectedCPS && (
              <Card>
                <CardContent className="pt-4 space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Peso unitario:</span>
                    <span className="font-medium">{(selectedCPS.averageWeight / 1000).toFixed(3)} kg</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Peso estimado total:</span>
                    <span className="font-bold text-primary">{estimatedWeight.toFixed(2)} kg</span>
                  </div>
                  <div className="flex justify-between text-sm pt-2 border-t">
                    <span className="text-muted-foreground">Uso anual después:</span>
                    <span className={`font-medium ${(yearlyUsageKg + estimatedWeight) > (company?.annualLimit || 300) ? 'text-destructive' : ''}`}>
                      {(yearlyUsageKg + estimatedWeight).toFixed(2)} / {company?.annualLimit || 300} kg
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="space-y-2">
              <Label htmlFor="origin">Origen *</Label>
              <Input
                id="origin"
                placeholder="Bodega Central, Santiago"
                value={formData.origin}
                onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                data-testid="input-origin"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="destination">Destino *</Label>
              <Input
                id="destination"
                placeholder="Faena Minera Los Pelambres"
                value={formData.destination}
                onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                data-testid="input-destination"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="nfcTag">Tag NFC (Opcional)</Label>
              <Input
                id="nfcTag"
                placeholder="Se generará automáticamente si no se ingresa"
                value={formData.nfcTag}
                onChange={(e) => setFormData({ ...formData, nfcTag: e.target.value })}
                data-testid="input-nfc-tag"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsDialogOpen(false);
                  resetForm();
                }}
                className="flex-1"
                data-testid="button-cancel"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || !formData.cpsId}
                className="flex-1"
                data-testid="button-submit"
              >
                {createMutation.isPending ? "Registrando..." : "Registrar Despacho"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
