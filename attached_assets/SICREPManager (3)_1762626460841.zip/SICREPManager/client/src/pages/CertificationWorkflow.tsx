import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import WorkflowTimeline from "@/components/WorkflowTimeline";
import EvaluationMatrix from "@/components/EvaluationMatrix";
import type { Certification } from "@shared/schema";

export default function CertificationWorkflow() {
  const { data: certifications, isLoading } = useQuery<Certification[]>({
    queryKey: ["/api/certifications"]
  });

  const certification = certifications?.[0];

  if (isLoading) {
    return (
      <div className="p-6 space-y-6" data-testid="page-certification">
        <div>
          <h1 className="text-3xl font-semibold mb-2">Proceso de Certificación</h1>
          <p className="text-muted-foreground">
            Workflow completo de certificación REP - 10 Fases
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Timeline de Certificación</CardTitle>
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full" />
            </CardContent>
          </Card>
          
          <div>
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!certification) {
    return (
      <div className="p-6 space-y-6" data-testid="page-certification">
        <div>
          <h1 className="text-3xl font-semibold mb-2">Proceso de Certificación</h1>
          <p className="text-muted-foreground">
            No hay certificaciones disponibles
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6" data-testid="page-certification">
      <div>
        <h1 className="text-3xl font-semibold mb-2">Proceso de Certificación</h1>
        <p className="text-muted-foreground">
          Workflow completo de certificación REP - 10 Fases
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Timeline de Certificación</CardTitle>
          </CardHeader>
          <CardContent>
            <WorkflowTimeline certificationId={certification.id} />
          </CardContent>
        </Card>
        
        <div>
          <EvaluationMatrix certificationId={certification.id} />
        </div>
      </div>
    </div>
  );
}
