import { useAuth } from "@/contexts/AuthContext";
import DashboardOverview from "@/components/DashboardOverview";
import MiningDashboard from "@/pages/MiningDashboard";

export default function Dashboard() {
  const { company } = useAuth();

  if (!company) {
    return (
      <div className="p-6 flex items-center justify-center">
        <p className="text-muted-foreground">Cargando...</p>
      </div>
    );
  }

  if (company.type === "minera") {
    return <MiningDashboard />;
  }

  return (
    <div className="p-6" data-testid="page-dashboard">
      <DashboardOverview />
    </div>
  );
}
