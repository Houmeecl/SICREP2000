import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { FileCheck, Clock, TrendingUp, CheckCircle2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CPSDashboard() {
  const { user } = useAuth();

  const { data: assignments, isLoading } = useQuery({
    queryKey: ["/api/admin/assignments"],
  });

  const { data: certifications } = useQuery({
    queryKey: ["/api/certifications"],
  });

  const { data: companies } = useQuery({
    queryKey: ["/api/companies"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Filtrar asignaciones del CPS actual
  const myAssignments = assignments?.filter((a: any) => 
    a.assignedTo === user?.id && a.role === "cps"
  ) || [];

  const myProjectIds = myAssignments.map((a: any) => a.certificationId);
  const myProjects = certifications?.filter((c: any) => 
    myProjectIds.includes(c.id)
  ) || [];

  // Métricas
  const totalProjects = myProjects.length;
  const phase1Projects = myProjects.filter((p: any) => p.currentPhase === "solicitud_inicial").length;
  const phase2Projects = myProjects.filter((p: any) => p.currentPhase === "revision_documentacion").length;
  const phase3Projects = myProjects.filter((p: any) => p.currentPhase === "inspeccion_terreno").length;
  const delayedProjects = myProjects.filter((p: any) => p.isDelayed).length;

  const getPhaseLabel = (phase: string) => {
    const labels: Record<string, string> = {
      solicitud_inicial: "Solicitud Inicial",
      revision_documentacion: "Revisión Documentación",
      inspeccion_terreno: "Inspección Terreno",
      evaluacion_tecnica: "Evaluación Técnica",
      informe_preliminar: "Informe Preliminar",
      correcciones: "Correcciones",
      revision_final: "Revisión Final",
      aprobacion: "Aprobación",
      emision_certificado: "Emisión Certificado",
      publicacion: "Publicación",
    };
    return labels[phase] || phase;
  };

  const getPhaseColor = (phase: string) => {
    if (phase === "solicitud_inicial") return "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300";
    if (phase === "revision_documentacion") return "bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300";
    if (phase === "inspeccion_terreno") return "bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-300";
    return "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300";
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-cps-dashboard">
          Panel CPS - Coordinador de Procesos
        </h1>
        <p className="text-muted-foreground mt-2">
          Gestión de certificaciones Fase 1-3 (Solicitud, Documentación, Inspección)
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Total Proyectos</CardTitle>
            <FileCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-total-projects">{totalProjects}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Fase 1</CardTitle>
            <div className="h-2 w-2 rounded-full bg-blue-500"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-phase1">{phase1Projects}</div>
            <p className="text-xs text-muted-foreground">Solicitud Inicial</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Fase 2</CardTitle>
            <div className="h-2 w-2 rounded-full bg-purple-500"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-phase2">{phase2Projects}</div>
            <p className="text-xs text-muted-foreground">Rev. Documentación</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Fase 3</CardTitle>
            <div className="h-2 w-2 rounded-full bg-orange-500"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-phase3">{phase3Projects}</div>
            <p className="text-xs text-muted-foreground">Inspección Terreno</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Con Retraso</CardTitle>
            <AlertCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive" data-testid="value-delayed">{delayedProjects}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Proyectos Asignados</CardTitle>
        </CardHeader>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Código</TableHead>
              <TableHead>Empresa</TableHead>
              <TableHead>Fase Actual</TableHead>
              <TableHead>Días en Fase</TableHead>
              <TableHead>Puntaje Documental</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {myProjects.map((cert: any) => {
              const company = companies?.find((c: any) => c.id === cert.companyId);
              const daysPassed = Math.floor(
                (Date.now() - new Date(cert.phaseStartDate).getTime()) / (1000 * 60 * 60 * 24)
              );

              return (
                <TableRow key={cert.id} data-testid={`row-certification-${cert.id}`}>
                  <TableCell className="font-medium font-mono">{cert.code}</TableCell>
                  <TableCell>{company?.name || "N/A"}</TableCell>
                  <TableCell>
                    <Badge className={getPhaseColor(cert.currentPhase)}>
                      {getPhaseLabel(cert.currentPhase)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      {daysPassed} días
                      {cert.isDelayed && (
                        <Badge variant="destructive" className="text-xs">Atrasado</Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-green-600" />
                      {cert.documentalScore || 0} pts
                    </div>
                  </TableCell>
                  <TableCell>
                    {cert.isDelayed ? (
                      <Badge variant="destructive">Retrasado</Badge>
                    ) : (
                      <Badge variant="outline">En Curso</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      asChild
                      data-testid={`button-evaluate-${cert.id}`}
                    >
                      <a href={`/cps/evaluacion/${cert.id}`}>
                        Evaluar
                      </a>
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
            {myProjects.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                  No hay proyectos asignados actualmente
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
