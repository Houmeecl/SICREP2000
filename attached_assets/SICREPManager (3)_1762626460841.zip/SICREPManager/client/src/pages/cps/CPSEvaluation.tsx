import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { FileCheck, Building2, CheckCircle2, XCircle, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

export default function CPSEvaluation() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [, params] = useRoute("/cps/evaluacion/:id");
  const certId = params?.id;

  const [evaluationData, setEvaluationData] = useState<Record<string, { passed: boolean; points: number; notes: string }>>({});

  const { data: certification, isLoading } = useQuery({
    queryKey: ["/api/certifications", certId],
    enabled: !!certId,
  });

  const { data: company } = useQuery({
    queryKey: ["/api/companies", certification?.companyId],
    enabled: !!certification?.companyId,
  });

  const { data: criteria } = useQuery({
    queryKey: ["/api/evaluation/criteria"],
  });

  const { data: existingResults } = useQuery({
    queryKey: ["/api/evaluation/results", certId],
    enabled: !!certId,
  });

  const saveResultMutation = useMutation({
    mutationFn: async (result: any) => {
      return await apiRequest("/api/evaluation/results", {
        method: "POST",
        body: JSON.stringify(result),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/evaluation/results", certId] });
    },
  });

  const advancePhaseMutation = useMutation({
    mutationFn: async (notes: string) => {
      return await apiRequest(`/api/certifications/${certId}/advance`, {
        method: "POST",
        body: JSON.stringify({ notes }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/certifications", certId] });
      toast({ title: "Fase avanzada exitosamente" });
    },
    onError: (error: any) => {
      toast({ title: "Error al avanzar fase", description: error.message, variant: "destructive" });
    },
  });

  const documentalCriteria = criteria?.filter((c: any) => c.category === "documentales") || [];

  const handleEvaluate = (criterionId: string, passed: boolean, points: number) => {
    const newData = {
      ...evaluationData,
      [criterionId]: {
        passed,
        points,
        notes: evaluationData[criterionId]?.notes || "",
      },
    };
    setEvaluationData(newData);

    // Guardar inmediatamente
    saveResultMutation.mutate({
      certificationId: certId,
      criterionId,
      passed,
      pointsAwarded: points,
      evaluatorId: user?.id,
      notes: newData[criterionId].notes,
    });
  };

  const handleAdvancePhase = () => {
    const totalScore = Object.values(evaluationData).reduce((sum, e) => sum + e.points, 0);
    advancePhaseMutation.mutate(`Evaluación documental completada. Puntaje total: ${totalScore} puntos.`);
  };

  if (isLoading) {
    return <div className="p-8">Cargando...</div>;
  }

  if (!certification) {
    return <div className="p-8">Certificación no encontrada</div>;
  }

  const totalDocumentalPoints = Object.values(evaluationData).reduce((sum, e) => sum + e.points, 0);
  const maxDocumentalPoints = documentalCriteria.reduce((sum: number, c: any) => sum + c.maxPoints, 0);
  const progress = maxDocumentalPoints > 0 ? (totalDocumentalPoints / maxDocumentalPoints) * 100 : 0;

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="heading-cps-evaluation">
            Evaluación Documental - Fase 1-3
          </h1>
          <p className="text-muted-foreground mt-2">
            Certificación {certification.code}
          </p>
        </div>
        <Button
          onClick={handleAdvancePhase}
          disabled={advancePhaseMutation.isPending || totalDocumentalPoints === 0}
          data-testid="button-advance-phase"
        >
          <ArrowRight className="h-4 w-4 mr-2" />
          Avanzar a Siguiente Fase
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Información del Proveedor
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Empresa</p>
              <p className="font-medium">{company?.name}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">RUT</p>
              <p className="font-mono">{company?.rut}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Email</p>
              <p className="text-sm">{company?.contactEmail || "N/A"}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Fase Actual</p>
              <Badge>{certification.currentPhase}</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Progreso de Evaluación Documental</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Puntaje Actual</span>
                <span className="text-2xl font-bold">{totalDocumentalPoints} / {maxDocumentalPoints}</span>
              </div>
              <Progress value={progress} className="h-2" />
              <p className="text-xs text-muted-foreground mt-2">
                {progress.toFixed(1)}% completado
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4 border-t">
              <div>
                <p className="text-xs text-muted-foreground">Criterios Evaluados</p>
                <p className="text-lg font-semibold">{Object.keys(evaluationData).length} / {documentalCriteria.length}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Aprobados</p>
                <p className="text-lg font-semibold text-green-600">
                  {Object.values(evaluationData).filter(e => e.passed).length}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Rechazados</p>
                <p className="text-lg font-semibold text-red-600">
                  {Object.values(evaluationData).filter(e => !e.passed).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileCheck className="h-5 w-5" />
            Criterios Documentales (Fase 1-3)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {documentalCriteria.map((criterion: any) => {
            const evaluation = evaluationData[criterion.id];
            const existingResult = existingResults?.find((r: any) => r.criterionId === criterion.id);

            return (
              <div
                key={criterion.id}
                className="p-4 border rounded-md space-y-3"
                data-testid={`criterion-${criterion.id}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="font-medium">{criterion.name}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{criterion.description}</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Puntaje máximo: {criterion.maxPoints} puntos
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant={evaluation?.passed ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleEvaluate(criterion.id, true, criterion.maxPoints)}
                      data-testid={`button-approve-${criterion.id}`}
                    >
                      <CheckCircle2 className="h-4 w-4 mr-1" />
                      Aprobar
                    </Button>
                    <Button
                      variant={evaluation?.passed === false ? "destructive" : "outline"}
                      size="sm"
                      onClick={() => handleEvaluate(criterion.id, false, 0)}
                      data-testid={`button-reject-${criterion.id}`}
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Rechazar
                    </Button>
                  </div>
                </div>

                {evaluation && (
                  <div className="pt-3 border-t space-y-2">
                    <Label htmlFor={`notes-${criterion.id}`}>Notas de Evaluación</Label>
                    <Textarea
                      id={`notes-${criterion.id}`}
                      placeholder="Observaciones, evidencias, recomendaciones..."
                      value={evaluation.notes}
                      onChange={(e) => {
                        const newData = {
                          ...evaluationData,
                          [criterion.id]: { ...evaluation, notes: e.target.value },
                        };
                        setEvaluationData(newData);
                      }}
                      onBlur={() => {
                        saveResultMutation.mutate({
                          certificationId: certId,
                          criterionId: criterion.id,
                          passed: evaluation.passed,
                          pointsAwarded: evaluation.points,
                          evaluatorId: user?.id,
                          notes: evaluation.notes,
                        });
                      }}
                      data-testid={`textarea-notes-${criterion.id}`}
                    />
                  </div>
                )}

                {existingResult && !evaluation && (
                  <div className="pt-3 border-t">
                    <p className="text-sm text-muted-foreground">
                      Evaluado previamente: {existingResult.passed ? "Aprobado" : "Rechazado"} ({existingResult.pointsAwarded} pts)
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
