import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import {
  ClipboardCheck,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  TrendingUp,
  Users,
  Building2,
  Download
} from "lucide-react";

export default function AuditorDashboard() {
  const { toast } = useToast();
  const [downloadingPdf, setDownloadingPdf] = useState<string | null>(null);

  const handleDownloadAudit = async (certificationId: string, companyName?: string) => {
    try {
      setDownloadingPdf(certificationId);
      const response = await fetch(`/api/reports/auditoria/${certificationId}`);
      
      if (!response.ok) {
        throw new Error('Error al generar el reporte');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Auditoria-${companyName || certificationId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Reporte descargado",
        description: "El reporte de auditoría se ha descargado exitosamente.",
      });
    } catch (error) {
      console.error('Error downloading PDF:', error);
      toast({
        title: "Error",
        description: "No se pudo descargar el reporte. Intente nuevamente.",
        variant: "destructive",
      });
    } finally {
      setDownloadingPdf(null);
    }
  };
  const { data: certifications, isLoading } = useQuery<any[]>({
    queryKey: ["/api/certifications"],
  });

  const { data: companies } = useQuery<any[]>({
    queryKey: ["/api/companies"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Estadísticas de auditorías
  const totalCertifications = certifications?.length || 0;
  const pendingAudits = certifications?.filter(c => 
    c.currentPhase === "evaluacion_documental" || 
    c.currentPhase === "evaluacion_operativa"
  ).length || 0;
  const completedAudits = certifications?.filter(c => 
    c.currentPhase === "publicacion"
  ).length || 0;
  const criticalIssues = certifications?.filter(c => 
    c.overallScore && c.overallScore < 60
  ).length || 0;

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-auditor-dashboard">
          Panel de Auditor
        </h1>
        <p className="text-muted-foreground mt-2">
          Supervisión de auditorías y compliance REP
        </p>
      </div>

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Total Certificaciones</CardTitle>
            <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-total-certifications">
              {totalCertifications}
            </div>
            <p className="text-xs text-muted-foreground">En el sistema</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Auditorías Pendientes</CardTitle>
            <Calendar className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600" data-testid="value-pending-audits">
              {pendingAudits}
            </div>
            <p className="text-xs text-muted-foreground">Requieren revisión</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Auditorías Completadas</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="value-completed-audits">
              {completedAudits}
            </div>
            <p className="text-xs text-muted-foreground">Publicadas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Hallazgos Críticos</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive" data-testid="value-critical-issues">
              {criticalIssues}
            </div>
            <p className="text-xs text-muted-foreground">Puntaje &lt; 60</p>
          </CardContent>
        </Card>
      </div>

      {/* Auditorías Pendientes */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <ClipboardCheck className="h-5 w-5" />
              Auditorías Pendientes de Revisión
            </CardTitle>
            <Badge variant="outline">{pendingAudits} pendientes</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {certifications && certifications.filter(c => 
            c.currentPhase === "evaluacion_documental" || 
            c.currentPhase === "evaluacion_operativa"
          ).length > 0 ? (
            <div className="space-y-4">
              {certifications
                .filter(c => 
                  c.currentPhase === "evaluacion_documental" || 
                  c.currentPhase === "evaluacion_operativa"
                )
                .slice(0, 5)
                .map((cert) => {
                  const company = companies?.find(c => c.id === cert.companyId);
                  return (
                    <div
                      key={cert.id}
                      className="flex items-center justify-between p-4 border rounded-md hover-elevate"
                      data-testid={`audit-${cert.id}`}
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Building2 className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{company?.name || "Empresa"}</p>
                          <p className="text-sm text-muted-foreground">
                            Fase: {cert.currentPhase}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge variant={cert.status === "active" ? "default" : "secondary"}>
                            {cert.status}
                          </Badge>
                          {cert.overallScore && (
                            <p className="text-sm text-muted-foreground mt-1">
                              Score: {cert.overallScore}/100
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleDownloadAudit(cert.id, company?.name)}
                          disabled={downloadingPdf === cert.id}
                          data-testid={`button-download-audit-${cert.id}`}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          {downloadingPdf === cert.id ? "Generando..." : "Reporte"}
                        </Button>
                        <Button variant="outline" size="sm" data-testid={`button-audit-${cert.id}`}>
                          <FileText className="h-4 w-4 mr-2" />
                          Revisar
                        </Button>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay auditorías pendientes de revisión
            </p>
          )}
        </CardContent>
      </Card>

      {/* Estadísticas de Compliance */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Tasa de Aprobación
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Certificaciones Aprobadas</span>
                <span className="text-2xl font-bold">
                  {totalCertifications > 0 ? Math.round((completedAudits / totalCertifications) * 100) : 0}%
                </span>
              </div>
              <Progress 
                value={totalCertifications > 0 ? (completedAudits / totalCertifications) * 100 : 0} 
                className="h-3"
              />
            </div>
            <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950/20 rounded-md">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <p className="text-sm text-green-700 dark:text-green-400">
                {completedAudits} de {totalCertifications} certificaciones aprobadas
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Empresas en Proceso
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Total Empresas</span>
                <span className="font-semibold">{companies?.length || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Con Certificación Activa</span>
                <span className="font-semibold text-green-600">{completedAudits}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">En Evaluación</span>
                <span className="font-semibold text-amber-600">{pendingAudits}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Con Hallazgos Críticos</span>
                <span className="font-semibold text-destructive">{criticalIssues}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
