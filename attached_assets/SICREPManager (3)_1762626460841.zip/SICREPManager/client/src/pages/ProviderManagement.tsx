import ProviderRanking from "@/components/ProviderRanking";

export default function ProviderManagement() {
  return (
    <div className="p-6 space-y-6" data-testid="page-providers">
      <div>
        <h1 className="text-3xl font-semibold mb-2">Gestión de Proveedores</h1>
        <p className="text-muted-foreground">
          Análisis ESG y ranking de proveedores certificados
        </p>
      </div>
      
      <ProviderRanking />
    </div>
  );
}
