import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Search, Clock, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function EvaluadorDashboard() {
  const { user } = useAuth();

  const { data: assignments, isLoading } = useQuery<any[]>({
    queryKey: ["/api/admin/assignments"],
  });

  const { data: certifications } = useQuery<any[]>({
    queryKey: ["/api/certifications"],
  });

  const { data: companies } = useQuery<any[]>({
    queryKey: ["/api/companies"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Filtrar asignaciones del evaluador actual
  const myAssignments = assignments?.filter((a: any) => 
    a.assignedTo === user?.id && a.role === "evaluador"
  ) || [];

  const myProjectIds = myAssignments.map((a: any) => a.certificationId);
  const myProjects = certifications?.filter((c: any) => 
    myProjectIds.includes(c.id)
  ) || [];

  // Fases 4-6 que maneja el evaluador
  const phase4Projects = myProjects.filter((p: any) => p.currentPhase === "evaluacion_tecnica").length;
  const phase5Projects = myProjects.filter((p: any) => p.currentPhase === "informe_preliminar").length;
  const phase6Projects = myProjects.filter((p: any) => p.currentPhase === "correcciones").length;
  const delayedProjects = myProjects.filter((p: any) => p.isDelayed).length;

  const getPhaseLabel = (phase: string) => {
    const labels: Record<string, string> = {
      solicitud_inicial: "Solicitud Inicial",
      revision_documentacion: "Revisión Documentación",
      inspeccion_terreno: "Inspección Terreno",
      evaluacion_tecnica: "Evaluación Técnica",
      informe_preliminar: "Informe Preliminar",
      correcciones: "Correcciones",
      revision_final: "Revisión Final",
      aprobacion: "Aprobación",
      emision_certificado: "Emisión Certificado",
      publicacion: "Publicación",
    };
    return labels[phase] || phase;
  };

  const getPhaseColor = (phase: string) => {
    if (phase === "evaluacion_tecnica") return "bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300";
    if (phase === "informe_preliminar") return "bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300";
    if (phase === "correcciones") return "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300";
    return "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300";
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-evaluador-dashboard">
          Panel Evaluador - Visitas Terreno
        </h1>
        <p className="text-muted-foreground mt-2">
          Evaluación técnica Fase 4-6 (Terreno, Informe, Correcciones)
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Total Proyectos</CardTitle>
            <Search className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-total-projects">{myProjects.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Fase 4</CardTitle>
            <div className="h-2 w-2 rounded-full bg-cyan-500"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-phase4">{phase4Projects}</div>
            <p className="text-xs text-muted-foreground">Evaluación Técnica</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Fase 5</CardTitle>
            <div className="h-2 w-2 rounded-full bg-teal-500"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-phase5">{phase5Projects}</div>
            <p className="text-xs text-muted-foreground">Informe Preliminar</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Fase 6</CardTitle>
            <div className="h-2 w-2 rounded-full bg-amber-500"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-phase6">{phase6Projects}</div>
            <p className="text-xs text-muted-foreground">Correcciones</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Con Retraso</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive" data-testid="value-delayed">{delayedProjects}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Proyectos Asignados - Evaluación de Terreno</CardTitle>
        </CardHeader>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Código</TableHead>
              <TableHead>Empresa</TableHead>
              <TableHead>Fase Actual</TableHead>
              <TableHead>Días en Fase</TableHead>
              <TableHead>Score Documental</TableHead>
              <TableHead>Score Operativo</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {myProjects.map((cert: any) => {
              const company = companies?.find((c: any) => c.id === cert.companyId);
              const daysPassed = Math.floor(
                (Date.now() - new Date(cert.phaseStartDate).getTime()) / (1000 * 60 * 60 * 24)
              );

              return (
                <TableRow key={cert.id} data-testid={`row-certification-${cert.id}`}>
                  <TableCell className="font-medium font-mono">{cert.code}</TableCell>
                  <TableCell>{company?.name || "N/A"}</TableCell>
                  <TableCell>
                    <Badge className={getPhaseColor(cert.currentPhase)}>
                      {getPhaseLabel(cert.currentPhase)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      {daysPassed} días
                      {cert.isDelayed && (
                        <Badge variant="destructive" className="text-xs">Atrasado</Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      {cert.documentalScore || 0} pts
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-blue-600" />
                      {cert.operationalScore || 0} pts
                    </div>
                  </TableCell>
                  <TableCell>
                    {cert.isDelayed ? (
                      <Badge variant="destructive">Retrasado</Badge>
                    ) : cert.currentPhase === "correcciones" ? (
                      <Badge variant="outline" className="bg-amber-50 dark:bg-amber-950">
                        Requiere Acción
                      </Badge>
                    ) : (
                      <Badge variant="outline">En Curso</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      asChild
                      data-testid={`button-evaluate-${cert.id}`}
                    >
                      <a href={`/evaluador/inspeccion/${cert.id}`}>
                        Inspeccionar
                      </a>
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
            {myProjects.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                  No hay proyectos asignados actualmente
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
