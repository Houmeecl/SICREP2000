import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { 
  Search, 
  Building2, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  ClipboardCheck,
  FileText,
  Camera
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

export default function FieldInspection() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [, params] = useRoute("/evaluador/inspeccion/:id");
  const certId = params?.id;

  const [evaluationData, setEvaluationData] = useState<Record<string, { passed: boolean; points: number; notes: string }>>({});
  const [reportNotes, setReportNotes] = useState("");

  const { data: certification, isLoading } = useQuery<any>({
    queryKey: ["/api/certifications", certId],
    enabled: !!certId,
  });

  const { data: company } = useQuery<any>({
    queryKey: ["/api/companies", certification?.companyId],
    enabled: !!certification?.companyId,
  });

  const { data: criteria } = useQuery<any[]>({
    queryKey: ["/api/evaluation/criteria"],
  });

  const { data: existingResults } = useQuery<any[]>({
    queryKey: ["/api/evaluation/results", certId],
    enabled: !!certId,
  });

  const saveResultMutation = useMutation({
    mutationFn: async (result: any) => {
      return await apiRequest("POST", "/api/evaluation/results", result);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/evaluation/results", certId] });
    },
  });

  const advancePhaseMutation = useMutation({
    mutationFn: async (notes: string) => {
      return await apiRequest("POST", `/api/certifications/${certId}/advance`, { notes });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/certifications", certId] });
      toast({ title: "Fase avanzada exitosamente" });
    },
    onError: (error: any) => {
      toast({ title: "Error al avanzar fase", description: error.message, variant: "destructive" });
    },
  });

  // Filtrar criterios operativos y de valor agregado
  const operationalCriteria = criteria?.filter((c: any) => c.category === "operativos") || [];
  const valueAddedCriteria = criteria?.filter((c: any) => c.category === "valor_agregado") || [];
  const allEvaluationCriteria = [...operationalCriteria, ...valueAddedCriteria];

  const handleEvaluate = (criterionId: string, passed: boolean, points: number) => {
    const newData = {
      ...evaluationData,
      [criterionId]: {
        passed,
        points,
        notes: evaluationData[criterionId]?.notes || "",
      },
    };
    setEvaluationData(newData);

    if (certId && user?.id) {
      saveResultMutation.mutate({
        certificationId: certId,
        criterionId,
        passed,
        pointsAwarded: points,
        evaluatorId: user.id,
        notes: newData[criterionId].notes,
      });
    }
  };

  const handleGenerateReport = () => {
    const totalOperationalScore = Object.entries(evaluationData)
      .filter(([id]) => operationalCriteria.some((c: any) => c.id === id))
      .reduce((sum, [, e]) => sum + e.points, 0);
    
    const totalValueAddedScore = Object.entries(evaluationData)
      .filter(([id]) => valueAddedCriteria.some((c: any) => c.id === id))
      .reduce((sum, [, e]) => sum + e.points, 0);

    const finalNotes = `
INFORME TÉCNICO DE TERRENO

Puntaje Operativo: ${totalOperationalScore} puntos
Puntaje Valor Agregado: ${totalValueAddedScore} puntos

Observaciones del Evaluador:
${reportNotes}

Criterios Evaluados: ${Object.keys(evaluationData).length}
Criterios Aprobados: ${Object.values(evaluationData).filter(e => e.passed).length}
`;

    advancePhaseMutation.mutate(finalNotes);
  };

  if (isLoading) {
    return <div className="p-8">Cargando...</div>;
  }

  if (!certification) {
    return <div className="p-8">Certificación no encontrada</div>;
  }

  const totalOperationalScore = Object.entries(evaluationData)
    .filter(([id]) => operationalCriteria.some((c: any) => c.id === id))
    .reduce((sum, [, e]) => sum + e.points, 0);
  
  const totalValueAddedScore = Object.entries(evaluationData)
    .filter(([id]) => valueAddedCriteria.some((c: any) => c.id === id))
    .reduce((sum, [, e]) => sum + e.points, 0);

  const maxOperationalPoints = operationalCriteria.reduce((sum: number, c: any) => sum + c.maxPoints, 0);
  const maxValueAddedPoints = valueAddedCriteria.reduce((sum: number, c: any) => sum + c.maxPoints, 0);

  const operationalProgress = maxOperationalPoints > 0 ? (totalOperationalScore / maxOperationalPoints) * 100 : 0;
  const valueAddedProgress = maxValueAddedPoints > 0 ? (totalValueAddedScore / maxValueAddedPoints) * 100 : 0;

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="heading-field-inspection">
            Inspección de Terreno - Fase 4-6
          </h1>
          <p className="text-muted-foreground mt-2">
            Certificación {certification.code}
          </p>
        </div>
        <Button
          onClick={handleGenerateReport}
          disabled={advancePhaseMutation.isPending || Object.keys(evaluationData).length === 0}
          data-testid="button-generate-report"
        >
          <FileText className="h-4 w-4 mr-2" />
          Generar Informe y Avanzar
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Información del Proveedor
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Empresa</p>
              <p className="font-medium">{company?.name}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">RUT</p>
              <p className="font-mono">{company?.rut}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Dirección</p>
              <p className="text-sm">{company?.address || "N/A"}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Puntaje Documental</p>
              <Badge variant="outline" className="bg-green-50 dark:bg-green-950">
                {certification.documentalScore || 0} pts
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Progreso de Evaluación de Terreno</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Criterios Operativos</span>
                <span className="text-lg font-bold">{totalOperationalScore} / {maxOperationalPoints}</span>
              </div>
              <Progress value={operationalProgress} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">{operationalProgress.toFixed(1)}% completado</p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Criterios de Valor Agregado</span>
                <span className="text-lg font-bold">{totalValueAddedScore} / {maxValueAddedPoints}</span>
              </div>
              <Progress value={valueAddedProgress} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">{valueAddedProgress.toFixed(1)}% completado</p>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4 border-t">
              <div>
                <p className="text-xs text-muted-foreground">Total Evaluados</p>
                <p className="text-lg font-semibold">{Object.keys(evaluationData).length} / {allEvaluationCriteria.length}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Aprobados</p>
                <p className="text-lg font-semibold text-green-600">
                  {Object.values(evaluationData).filter(e => e.passed).length}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Rechazados</p>
                <p className="text-lg font-semibold text-red-600">
                  {Object.values(evaluationData).filter(e => !e.passed).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Criterios Operativos */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ClipboardCheck className="h-5 w-5" />
            Criterios Operativos (Fase 4-5)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {operationalCriteria.map((criterion: any) => {
            const evaluation = evaluationData[criterion.id];

            return (
              <div
                key={criterion.id}
                className="p-4 border rounded-md space-y-3"
                data-testid={`criterion-operational-${criterion.id}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="font-medium">{criterion.name}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{criterion.description}</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Puntaje máximo: {criterion.maxPoints} puntos
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant={evaluation?.passed ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleEvaluate(criterion.id, true, criterion.maxPoints)}
                      data-testid={`button-approve-${criterion.id}`}
                    >
                      <CheckCircle2 className="h-4 w-4 mr-1" />
                      Aprobar
                    </Button>
                    <Button
                      variant={evaluation?.passed === false ? "destructive" : "outline"}
                      size="sm"
                      onClick={() => handleEvaluate(criterion.id, false, 0)}
                      data-testid={`button-reject-${criterion.id}`}
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Rechazar
                    </Button>
                  </div>
                </div>

                {evaluation && (
                  <div className="pt-3 border-t space-y-2">
                    <Label htmlFor={`notes-${criterion.id}`}>Observaciones de Terreno</Label>
                    <Textarea
                      id={`notes-${criterion.id}`}
                      placeholder="Evidencias fotográficas, mediciones, no conformidades detectadas..."
                      value={evaluation.notes}
                      onChange={(e) => {
                        const newData = {
                          ...evaluationData,
                          [criterion.id]: { ...evaluation, notes: e.target.value },
                        };
                        setEvaluationData(newData);
                      }}
                      onBlur={() => {
                        if (certId && user?.id) {
                          saveResultMutation.mutate({
                            certificationId: certId,
                            criterionId: criterion.id,
                            passed: evaluation.passed,
                            pointsAwarded: evaluation.points,
                            evaluatorId: user.id,
                            notes: evaluation.notes,
                          });
                        }
                      }}
                      data-testid={`textarea-notes-${criterion.id}`}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Criterios de Valor Agregado */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Criterios de Valor Agregado (Fase 6)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {valueAddedCriteria.map((criterion: any) => {
            const evaluation = evaluationData[criterion.id];

            return (
              <div
                key={criterion.id}
                className="p-4 border rounded-md space-y-3"
                data-testid={`criterion-value-${criterion.id}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="font-medium">{criterion.name}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{criterion.description}</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Puntaje máximo: {criterion.maxPoints} puntos
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant={evaluation?.passed ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleEvaluate(criterion.id, true, criterion.maxPoints)}
                      data-testid={`button-approve-value-${criterion.id}`}
                    >
                      <CheckCircle2 className="h-4 w-4 mr-1" />
                      Aprobar
                    </Button>
                    <Button
                      variant={evaluation?.passed === false ? "destructive" : "outline"}
                      size="sm"
                      onClick={() => handleEvaluate(criterion.id, false, 0)}
                      data-testid={`button-reject-value-${criterion.id}`}
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Rechazar
                    </Button>
                  </div>
                </div>

                {evaluation && (
                  <div className="pt-3 border-t space-y-2">
                    <Label htmlFor={`notes-value-${criterion.id}`}>Observaciones</Label>
                    <Textarea
                      id={`notes-value-${criterion.id}`}
                      placeholder="Innovaciones detectadas, buenas prácticas, diferenciadores competitivos..."
                      value={evaluation.notes}
                      onChange={(e) => {
                        const newData = {
                          ...evaluationData,
                          [criterion.id]: { ...evaluation, notes: e.target.value },
                        };
                        setEvaluationData(newData);
                      }}
                      onBlur={() => {
                        if (certId && user?.id) {
                          saveResultMutation.mutate({
                            certificationId: certId,
                            criterionId: criterion.id,
                            passed: evaluation.passed,
                            pointsAwarded: evaluation.points,
                            evaluatorId: user.id,
                            notes: evaluation.notes,
                          });
                        }
                      }}
                      data-testid={`textarea-notes-value-${criterion.id}`}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Notas del Informe Final */}
      <Card>
        <CardHeader>
          <CardTitle>Notas del Informe Técnico</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Resumen ejecutivo de la visita, hallazgos principales, recomendaciones generales..."
            value={reportNotes}
            onChange={(e) => setReportNotes(e.target.value)}
            rows={6}
            data-testid="textarea-report-notes"
          />
        </CardContent>
      </Card>
    </div>
  );
}
