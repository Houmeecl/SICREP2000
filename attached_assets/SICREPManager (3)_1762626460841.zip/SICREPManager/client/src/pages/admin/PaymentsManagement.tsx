import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { CreditCard, CheckCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

export default function PaymentsManagement() {
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: payments, isLoading } = useQuery({
    queryKey: ["/api/admin/payments"],
  });

  const { data: companies } = useQuery({
    queryKey: ["/api/companies"],
  });

  const confirmMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest(`/api/admin/payments/${id}/confirm`, {
        method: "POST",
        body: JSON.stringify({ confirmedBy: user?.id }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payments"] });
      toast({ title: "Pago confirmado exitosamente" });
    },
    onError: (error: any) => {
      toast({ title: "Error al confirmar pago", description: error.message, variant: "destructive" });
    },
  });

  const handleConfirm = (id: string) => {
    if (confirm("¿Confirmar este pago? Esto activará la certificación del proveedor.")) {
      confirmMutation.mutate(id);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      pending: { variant: "secondary", label: "Pendiente", icon: Clock },
      confirmed: { variant: "default", label: "Confirmado", icon: CheckCircle },
      rejected: { variant: "destructive", label: "Rechazado", icon: null },
    };

    const config = variants[status] || variants.pending;
    const Icon = config.icon;

    return (
      <Badge variant={config.variant as any}>
        {Icon && <Icon className="h-3 w-3 mr-1" />}
        {config.label}
      </Badge>
    );
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      certificacion_inicial: "Certificación Inicial (15 UF)",
      mensual_plataforma: "Mensualidad Plataforma (5 UF)",
      certificados_nfc_extra: "Certificados NFC Extra",
    };
    return labels[type] || type;
  };

  if (isLoading) {
    return <div className="p-8">Cargando...</div>;
  }

  const pendingPayments = payments?.filter((p: any) => p.status === "pending");
  const confirmedPayments = payments?.filter((p: any) => p.status === "confirmed");

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-payments-management">Gestión de Pagos</h1>
        <p className="text-muted-foreground mt-1">Confirmar pagos y activar certificaciones</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-orange-100 dark:bg-orange-950 rounded-md">
              <Clock className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pendientes</p>
              <p className="text-2xl font-bold" data-testid="value-pending-payments">
                {pendingPayments?.length || 0}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-100 dark:bg-green-950 rounded-md">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Confirmados</p>
              <p className="text-2xl font-bold" data-testid="value-confirmed-payments">
                {confirmedPayments?.length || 0}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-100 dark:bg-blue-950 rounded-md">
              <CreditCard className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Pagos</p>
              <p className="text-2xl font-bold" data-testid="value-total-payments">
                {payments?.length || 0}
              </p>
            </div>
          </div>
        </Card>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Pagos Pendientes de Confirmación</h2>
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Empresa</TableHead>
                <TableHead>Tipo de Pago</TableHead>
                <TableHead>Monto (UF)</TableHead>
                <TableHead>Fecha Solicitud</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingPayments?.map((payment: any) => {
                const company = companies?.find((c: any) => c.id === payment.companyId);
                return (
                  <TableRow key={payment.id} data-testid={`row-payment-${payment.id}`}>
                    <TableCell className="font-medium">{company?.name || "N/A"}</TableCell>
                    <TableCell>{getTypeLabel(payment.type)}</TableCell>
                    <TableCell>{parseFloat(payment.amountUF).toFixed(2)} UF</TableCell>
                    <TableCell>{new Date(payment.createdAt).toLocaleDateString('es-CL')}</TableCell>
                    <TableCell>{getStatusBadge(payment.status)}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        onClick={() => handleConfirm(payment.id)}
                        disabled={confirmMutation.isPending}
                        data-testid={`button-confirm-payment-${payment.id}`}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Confirmar
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {pendingPayments?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    No hay pagos pendientes
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </Card>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Historial de Pagos Confirmados</h2>
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Empresa</TableHead>
                <TableHead>Tipo de Pago</TableHead>
                <TableHead>Monto (UF)</TableHead>
                <TableHead>Fecha Confirmación</TableHead>
                <TableHead>Estado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {confirmedPayments?.slice(0, 10).map((payment: any) => {
                const company = companies?.find((c: any) => c.id === payment.companyId);
                return (
                  <TableRow key={payment.id} data-testid={`row-confirmed-payment-${payment.id}`}>
                    <TableCell className="font-medium">{company?.name || "N/A"}</TableCell>
                    <TableCell>{getTypeLabel(payment.type)}</TableCell>
                    <TableCell>{parseFloat(payment.amountUF).toFixed(2)} UF</TableCell>
                    <TableCell>
                      {payment.confirmedAt ? new Date(payment.confirmedAt).toLocaleDateString('es-CL') : "-"}
                    </TableCell>
                    <TableCell>{getStatusBadge(payment.status)}</TableCell>
                  </TableRow>
                );
              })}
              {confirmedPayments?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    No hay pagos confirmados
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </Card>
      </div>
    </div>
  );
}
