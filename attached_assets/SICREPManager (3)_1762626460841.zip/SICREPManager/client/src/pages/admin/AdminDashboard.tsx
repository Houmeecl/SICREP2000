import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Building2, CreditCard, FileCheck, Package, TrendingUp, AlertCircle, CheckCircle } from "lucide-react";

export default function AdminDashboard() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const metrics = [
    {
      title: "Total Usuarios",
      value: stats?.totalUsers || 0,
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-950",
    },
    {
      title: "Total Empresas",
      value: stats?.totalCompanies || 0,
      icon: Building2,
      color: "text-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-950",
    },
    {
      title: "Proveedores",
      value: stats?.totalProviders || 0,
      icon: Package,
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-950",
    },
    {
      title: "Empresas Mineras",
      value: stats?.totalMiningCompanies || 0,
      icon: TrendingUp,
      color: "text-orange-600",
      bgColor: "bg-orange-50 dark:bg-orange-950",
    },
    {
      title: "Pagos Pendientes",
      value: stats?.pendingPayments || 0,
      icon: AlertCircle,
      color: "text-red-600",
      bgColor: "bg-red-50 dark:bg-red-950",
    },
    {
      title: "Certificaciones Activas",
      value: stats?.activeCertifications || 0,
      icon: FileCheck,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50 dark:bg-yellow-950",
    },
    {
      title: "Certificaciones Completadas",
      value: stats?.completedCertifications || 0,
      icon: CheckCircle,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50 dark:bg-emerald-950",
    },
    {
      title: "Total Despachos",
      value: stats?.totalDispatches || 0,
      icon: Package,
      color: "text-indigo-600",
      bgColor: "bg-indigo-50 dark:bg-indigo-950",
    },
  ];

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-admin-dashboard">
          Panel de Administración
        </h1>
        <p className="text-muted-foreground mt-2">
          Gestión integral del sistema SICREP
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <Card key={metric.title} className="hover-elevate" data-testid={`card-metric-${metric.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
                <CardTitle className="text-sm font-medium">
                  {metric.title}
                </CardTitle>
                <div className={`p-2 rounded-md ${metric.bgColor}`}>
                  <Icon className={`h-4 w-4 ${metric.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid={`value-${metric.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  {metric.value.toLocaleString('es-CL')}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Acciones Rápidas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <a href="/admin/usuarios" className="block p-3 rounded-md hover-elevate active-elevate-2 border" data-testid="link-manage-users">
              <div className="flex items-center gap-3">
                <Users className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Gestionar Usuarios</p>
                  <p className="text-sm text-muted-foreground">Crear, editar y asignar roles</p>
                </div>
              </div>
            </a>
            <a href="/admin/empresas" className="block p-3 rounded-md hover-elevate active-elevate-2 border" data-testid="link-manage-companies">
              <div className="flex items-center gap-3">
                <Building2 className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="font-medium">Gestionar Empresas</p>
                  <p className="text-sm text-muted-foreground">Alta de proveedores y mineras</p>
                </div>
              </div>
            </a>
            <a href="/admin/pagos" className="block p-3 rounded-md hover-elevate active-elevate-2 border" data-testid="link-manage-payments">
              <div className="flex items-center gap-3">
                <CreditCard className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">Confirmar Pagos</p>
                  <p className="text-sm text-muted-foreground">Activar certificaciones</p>
                </div>
              </div>
            </a>
            <a href="/admin/asignaciones" className="block p-3 rounded-md hover-elevate active-elevate-2 border" data-testid="link-manage-assignments">
              <div className="flex items-center gap-3">
                <FileCheck className="h-5 w-5 text-orange-600" />
                <div>
                  <p className="font-medium">Asignar Certificadores</p>
                  <p className="text-sm text-muted-foreground">Distribución de carga de trabajo</p>
                </div>
              </div>
            </a>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Peso Total Procesado</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="text-3xl font-bold" data-testid="value-total-weight">
                  {((stats?.totalWeight || 0) / 1000).toLocaleString('es-CL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} kg
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Total de embalajes procesados en el sistema
                </p>
              </div>
              <div className="pt-4 border-t">
                <p className="text-sm font-medium mb-2">Distribución de Materiales</p>
                <p className="text-xs text-muted-foreground">
                  Ver detalles en Dashboard de Proveedores
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
