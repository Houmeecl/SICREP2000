import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { UserPlus, TrendingDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

export default function AssignmentsManagement() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    certificationId: "",
    assignedTo: "",
    role: "cps" as "cps" | "evaluador" | "auditor",
  });

  const { data: assignments, isLoading } = useQuery({
    queryKey: ["/api/admin/assignments"],
  });

  const { data: certifications } = useQuery({
    queryKey: ["/api/certifications"],
  });

  const { data: workload } = useQuery({
    queryKey: ["/api/admin/certifiers/workload"],
  });

  const { data: companies } = useQuery({
    queryKey: ["/api/companies"],
  });

  const assignMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("/api/admin/assignments", {
        method: "POST",
        body: JSON.stringify({
          ...data,
          assignedBy: user?.id,
          phaseStart: "solicitud_inicial",
          phaseEnd: data.role === "cps" ? "informe_preliminar" : "publicacion",
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/assignments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/certifiers/workload"] });
      toast({ title: "Certificador asignado exitosamente" });
      setIsAssignDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({ title: "Error al asignar certificador", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({ certificationId: "", assignedTo: "", role: "cps" });
  };

  const handleAutoAssign = () => {
    const certifier = workload?.[0];
    if (!certifier) {
      toast({ title: "No hay certificadores disponibles", variant: "destructive" });
      return;
    }
    setFormData({ ...formData, assignedTo: certifier.userId });
  };

  const handleAssign = () => {
    if (!formData.certificationId || !formData.assignedTo) {
      toast({ title: "Complete todos los campos", variant: "destructive" });
      return;
    }
    assignMutation.mutate(formData);
  };

  const getRoleBadge = (role: string) => {
    const variants: Record<string, string> = {
      cps: "Fase 1-3",
      evaluador: "Fase 4+",
      auditor: "Auditoría",
    };
    return variants[role] || role;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      assigned: { variant: "secondary", label: "Asignado" },
      in_progress: { variant: "default", label: "En Progreso" },
      completed: { variant: "outline", label: "Completado" },
    };
    const config = variants[status] || variants.assigned;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (isLoading) {
    return <div className="p-8">Cargando...</div>;
  }

  const unassignedCertifications = certifications?.filter(
    (cert: any) => !assignments?.some((a: any) => a.certificationId === cert.id)
  );

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="heading-assignments-management">Asignación de Certificadores</h1>
          <p className="text-muted-foreground mt-1">Distribuir carga de trabajo entre CPS y Evaluadores</p>
        </div>
        <Button onClick={() => setIsAssignDialogOpen(true)} data-testid="button-assign-certifier">
          <UserPlus className="h-4 w-4 mr-2" />
          Asignar Certificador
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-primary" />
            Carga de Trabajo Actual
          </h2>
          <div className="space-y-3">
            {workload?.slice(0, 10).map((certifier: any) => (
              <div key={certifier.userId} className="flex items-center justify-between p-3 border rounded-md" data-testid={`workload-${certifier.userId}`}>
                <div className="flex-1">
                  <p className="font-medium">{certifier.username}</p>
                  <p className="text-sm text-muted-foreground">{certifier.email}</p>
                  <Badge variant="outline" className="mt-1">{getRoleBadge(certifier.role)}</Badge>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold">{certifier.workload}</p>
                  <p className="text-xs text-muted-foreground">proyectos activos</p>
                </div>
              </div>
            ))}
            {!workload || workload.length === 0 && (
              <p className="text-muted-foreground text-center py-8">No hay certificadores disponibles</p>
            )}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-semibold mb-4">Certificaciones Sin Asignar</h2>
          <div className="space-y-2">
            {unassignedCertifications?.slice(0, 10).map((cert: any) => {
              const company = companies?.find((c: any) => c.id === cert.companyId);
              return (
                <div key={cert.id} className="p-3 border rounded-md" data-testid={`unassigned-cert-${cert.id}`}>
                  <p className="font-medium">{cert.code}</p>
                  <p className="text-sm text-muted-foreground">{company?.name}</p>
                  <Badge className="mt-1">{cert.currentPhase}</Badge>
                </div>
              );
            })}
            {!unassignedCertifications || unassignedCertifications.length === 0 && (
              <p className="text-muted-foreground text-center py-8">Todas las certificaciones están asignadas</p>
            )}
          </div>
        </Card>
      </div>

      <Card>
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold">Asignaciones Activas</h2>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Certificación</TableHead>
              <TableHead>Empresa</TableHead>
              <TableHead>Asignado a</TableHead>
              <TableHead>Rol</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Fecha Asignación</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assignments?.map((assignment: any) => {
              const cert = certifications?.find((c: any) => c.id === assignment.certificationId);
              const company = companies?.find((c: any) => c.id === cert?.companyId);
              const certifier = workload?.find((w: any) => w.userId === assignment.assignedTo);

              return (
                <TableRow key={assignment.id} data-testid={`row-assignment-${assignment.id}`}>
                  <TableCell className="font-medium">{cert?.code || "N/A"}</TableCell>
                  <TableCell>{company?.name || "N/A"}</TableCell>
                  <TableCell>{certifier?.username || "N/A"}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{getRoleBadge(assignment.role)}</Badge>
                  </TableCell>
                  <TableCell>{getStatusBadge(assignment.status)}</TableCell>
                  <TableCell>{new Date(assignment.createdAt).toLocaleDateString('es-CL')}</TableCell>
                </TableRow>
              );
            })}
            {!assignments || assignments.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                  No hay asignaciones registradas
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
        <DialogContent data-testid="dialog-assign-certifier">
          <DialogHeader>
            <DialogTitle>Asignar Certificador</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="certification">Certificación</Label>
              <Select
                value={formData.certificationId}
                onValueChange={(value) => setFormData({ ...formData, certificationId: value })}
              >
                <SelectTrigger data-testid="select-certification">
                  <SelectValue placeholder="Seleccionar certificación" />
                </SelectTrigger>
                <SelectContent>
                  {unassignedCertifications?.map((cert: any) => {
                    const company = companies?.find((c: any) => c.id === cert.companyId);
                    return (
                      <SelectItem key={cert.id} value={cert.id}>
                        {cert.code} - {company?.name}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Rol de Certificador</Label>
              <Select
                value={formData.role}
                onValueChange={(value: any) => setFormData({ ...formData, role: value })}
              >
                <SelectTrigger data-testid="select-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cps">CPS (Fase 1-3)</SelectItem>
                  <SelectItem value="evaluador">Evaluador (Fase 4+)</SelectItem>
                  <SelectItem value="auditor">Auditor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="certifier">Certificador</Label>
                <Button
                  variant="link"
                  size="sm"
                  onClick={handleAutoAssign}
                  data-testid="button-auto-assign"
                >
                  Asignar Automático
                </Button>
              </div>
              <Select
                value={formData.assignedTo}
                onValueChange={(value) => setFormData({ ...formData, assignedTo: value })}
              >
                <SelectTrigger data-testid="select-certifier">
                  <SelectValue placeholder="Seleccionar certificador" />
                </SelectTrigger>
                <SelectContent>
                  {workload
                    ?.filter((w: any) => w.role === formData.role)
                    .map((certifier: any) => (
                      <SelectItem key={certifier.userId} value={certifier.userId}>
                        {certifier.username} ({certifier.workload} proyectos)
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAssignDialogOpen(false)} data-testid="button-cancel">
              Cancelar
            </Button>
            <Button onClick={handleAssign} disabled={assignMutation.isPending} data-testid="button-submit">
              {assignMutation.isPending ? "Asignando..." : "Asignar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
