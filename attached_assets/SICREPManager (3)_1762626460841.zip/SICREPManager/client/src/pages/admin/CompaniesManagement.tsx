import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Plus, Search, Building2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CompaniesManagement() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    rut: "",
    type: "proveedor" as "proveedor" | "minera",
    address: "",
    contactEmail: "",
    contactPhone: "",
    annualLimit: 300,
  });

  const { data: companies, isLoading } = useQuery({
    queryKey: ["/api/companies"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("/api/admin/companies", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/companies"] });
      toast({ title: "Empresa creada exitosamente" });
      setIsCreateDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({ title: "Error al crear empresa", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      rut: "",
      type: "proveedor",
      address: "",
      contactEmail: "",
      contactPhone: "",
      annualLimit: 300,
    });
  };

  const handleCreate = () => {
    createMutation.mutate(formData);
  };

  const filteredCompanies = companies?.filter((company: any) =>
    company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.rut.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return <div className="p-8">Cargando...</div>;
  }

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="heading-companies-management">Gestión de Empresas</h1>
          <p className="text-muted-foreground mt-1">Administrar proveedores y empresas mineras</p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)} data-testid="button-create-company">
          <Plus className="h-4 w-4 mr-2" />
          Crear Empresa
        </Button>
      </div>

      <Card className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar empresas..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            data-testid="input-search-companies"
          />
        </div>
      </Card>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre</TableHead>
              <TableHead>RUT</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Teléfono</TableHead>
              <TableHead>Límite Anual</TableHead>
              <TableHead>Uso Actual</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCompanies?.map((company: any) => (
              <TableRow key={company.id} data-testid={`row-company-${company.id}`}>
                <TableCell className="font-medium">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-muted-foreground" />
                    {company.name}
                  </div>
                </TableCell>
                <TableCell>{company.rut}</TableCell>
                <TableCell>
                  <span className={`px-2 py-1 rounded-md text-sm ${
                    company.type === 'minera'
                      ? 'bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-300'
                      : 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300'
                  }`}>
                    {company.type === 'minera' ? 'Minera' : 'Proveedor'}
                  </span>
                </TableCell>
                <TableCell>{company.contactEmail || "-"}</TableCell>
                <TableCell>{company.contactPhone || "-"}</TableCell>
                <TableCell>{company.annualLimit} kg</TableCell>
                <TableCell>
                  {((company.yearlyUsage || 0) / 1000).toFixed(2)} kg
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent data-testid="dialog-create-company">
          <DialogHeader>
            <DialogTitle>Crear Nueva Empresa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4 max-h-[500px] overflow-y-auto">
            <div className="space-y-2">
              <Label htmlFor="company-name">Razón Social</Label>
              <Input
                id="company-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                data-testid="input-company-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="company-rut">RUT</Label>
              <Input
                id="company-rut"
                value={formData.rut}
                onChange={(e) => setFormData({ ...formData, rut: e.target.value })}
                placeholder="12.345.678-9"
                data-testid="input-company-rut"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="company-type">Tipo</Label>
              <Select
                value={formData.type}
                onValueChange={(value: any) => setFormData({ ...formData, type: value })}
              >
                <SelectTrigger data-testid="select-company-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="proveedor">Proveedor</SelectItem>
                  <SelectItem value="minera">Empresa Minera</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="company-address">Dirección</Label>
              <Input
                id="company-address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                data-testid="input-company-address"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="company-email">Email de Contacto</Label>
              <Input
                id="company-email"
                type="email"
                value={formData.contactEmail}
                onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                data-testid="input-company-email"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="company-phone">Teléfono</Label>
              <Input
                id="company-phone"
                value={formData.contactPhone}
                onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                data-testid="input-company-phone"
              />
            </div>
            {formData.type === 'proveedor' && (
              <div className="space-y-2">
                <Label htmlFor="company-limit">Límite Anual (kg)</Label>
                <Input
                  id="company-limit"
                  type="number"
                  value={formData.annualLimit}
                  onChange={(e) => setFormData({ ...formData, annualLimit: parseInt(e.target.value) })}
                  data-testid="input-company-limit"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)} data-testid="button-cancel">
              Cancelar
            </Button>
            <Button onClick={handleCreate} disabled={createMutation.isPending} data-testid="button-submit">
              {createMutation.isPending ? "Creando..." : "Crear"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
