import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  Award,
  FileCheck,
  Clock,
  Download,
  Send,
  CheckCircle2,
  AlertCircle,
  Building2
} from "lucide-react";

export default function CertificadorDashboard() {
  const { toast } = useToast();
  const [downloadingPdf, setDownloadingPdf] = useState<string | null>(null);

  const handleDownloadCertificate = async (certificationId: string, companyName?: string) => {
    try {
      setDownloadingPdf(certificationId);
      const response = await fetch(`/api/reports/certificado/${certificationId}`);
      
      if (!response.ok) {
        throw new Error('Error al generar el certificado');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Certificado-REP-${companyName || certificationId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Certificado descargado",
        description: "El certificado PDF se ha descargado exitosamente.",
      });
    } catch (error) {
      console.error('Error downloading PDF:', error);
      toast({
        title: "Error",
        description: "No se pudo descargar el certificado. Intente nuevamente.",
        variant: "destructive",
      });
    } finally {
      setDownloadingPdf(null);
    }
  };
  const { data: certifications, isLoading } = useQuery<any[]>({
    queryKey: ["/api/certifications"],
  });

  const { data: companies } = useQuery<any[]>({
    queryKey: ["/api/companies"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Estadísticas de certificación
  const approvedCertifications = certifications?.filter(c => 
    c.currentPhase === "publicacion" && c.status === "active"
  ).length || 0;
  const pendingIssuance = certifications?.filter(c => 
    c.currentPhase === "decision_final" && c.overallScore && c.overallScore >= 60
  ).length || 0;
  const totalIssued = certifications?.filter(c => c.status === "active").length || 0;

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-certificador-dashboard">
          Panel de Certificador
        </h1>
        <p className="text-muted-foreground mt-2">
          Emisión y validación de certificados oficiales REP
        </p>
      </div>

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Certificados Emitidos</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-total-issued">
              {totalIssued}
            </div>
            <p className="text-xs text-muted-foreground">Total activos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Pendientes de Emisión</CardTitle>
            <Clock className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600" data-testid="value-pending-issuance">
              {pendingIssuance}
            </div>
            <p className="text-xs text-muted-foreground">Aprobados, sin emitir</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Aprobados Este Mes</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="value-monthly-approved">
              {approvedCertifications}
            </div>
            <p className="text-xs text-muted-foreground">Publicados</p>
          </CardContent>
        </Card>
      </div>

      {/* Certificados Pendientes de Emisión */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <FileCheck className="h-5 w-5" />
              Certificados Pendientes de Emisión
            </CardTitle>
            <Badge variant="outline">{pendingIssuance} pendientes</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {certifications && certifications.filter(c => 
            c.currentPhase === "decision_final" && c.overallScore && c.overallScore >= 60
          ).length > 0 ? (
            <div className="space-y-4">
              {certifications
                .filter(c => c.currentPhase === "decision_final" && c.overallScore && c.overallScore >= 60)
                .map((cert) => {
                  const company = companies?.find(c => c.id === cert.companyId);
                  return (
                    <div
                      key={cert.id}
                      className="flex items-center justify-between p-4 border rounded-md hover-elevate"
                      data-testid={`cert-pending-${cert.id}`}
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                          <Building2 className="h-5 w-5 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{company?.name || "Empresa"}</p>
                          <p className="text-sm text-muted-foreground">
                            Score: {cert.overallScore}/100 - Aprobado
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge variant="outline" className="bg-green-50 dark:bg-green-950">
                            Listo para emisión
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleDownloadCertificate(cert.id, company?.name)}
                          disabled={downloadingPdf === cert.id}
                          data-testid={`button-download-${cert.id}`}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          {downloadingPdf === cert.id ? "Generando..." : "PDF"}
                        </Button>
                        <Button size="sm" data-testid={`button-issue-${cert.id}`}>
                          <Send className="h-4 w-4 mr-2" />
                          Emitir
                        </Button>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay certificados pendientes de emisión
            </p>
          )}
        </CardContent>
      </Card>

      {/* Certificados Emitidos Recientemente */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              Certificados Emitidos
            </CardTitle>
            <Button variant="outline" size="sm">Ver Todos</Button>
          </div>
        </CardHeader>
        <CardContent>
          {certifications && certifications.filter(c => c.status === "active").length > 0 ? (
            <div className="space-y-3">
              {certifications
                .filter(c => c.status === "active")
                .slice(0, 5)
                .map((cert) => {
                  const company = companies?.find(c => c.id === cert.companyId);
                  return (
                    <div
                      key={cert.id}
                      className="flex items-center justify-between p-3 border rounded-md"
                      data-testid={`cert-issued-${cert.id}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Award className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{company?.name || "Empresa"}</p>
                          <p className="text-sm text-muted-foreground">
                            Certificado REP - Score: {cert.overallScore}/100
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="bg-green-50 dark:bg-green-950">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Activo
                        </Badge>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay certificados emitidos
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
