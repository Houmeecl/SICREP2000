import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  TrendingUp,
  DollarSign,
  Users,
  Target,
  Phone,
  Mail,
  Building2,
  CheckCircle2,
  Clock
} from "lucide-react";

export default function VendedorDashboard() {
  const { data: companies, isLoading } = useQuery<any[]>({
    queryKey: ["/api/companies"],
  });

  const { data: certifications } = useQuery<any[]>({
    queryKey: ["/api/certifications"],
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Métricas de ventas
  const totalClients = companies?.length || 0;
  const activeClients = certifications?.filter(c => c.status === "active").length || 0;
  const potentialClients = companies?.filter(c => 
    !certifications?.some(cert => cert.companyId === c.id && cert.status === "active")
  ).length || 0;
  const conversionRate = totalClients > 0 ? (activeClients / totalClients) * 100 : 0;

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-vendedor-dashboard">
          Panel de Vendedor
        </h1>
        <p className="text-muted-foreground mt-2">
          Gestión comercial y pipeline de clientes potenciales
        </p>
      </div>

      {/* Métricas Comerciales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Total Clientes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-total-clients">
              {totalClients}
            </div>
            <p className="text-xs text-muted-foreground">Empresas registradas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Clientes Activos</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="value-active-clients">
              {activeClients}
            </div>
            <p className="text-xs text-muted-foreground">Con certificación</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Clientes Potenciales</CardTitle>
            <Target className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600" data-testid="value-potential-clients">
              {potentialClients}
            </div>
            <p className="text-xs text-muted-foreground">Sin certificación</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Tasa de Conversión</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="value-conversion-rate">
              {conversionRate.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">Leads → Clientes</p>
          </CardContent>
        </Card>
      </div>

      {/* Pipeline de Ventas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Pipeline de Ventas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Clientes Activos</span>
              <span className="text-sm font-semibold">{activeClients} ({conversionRate.toFixed(1)}%)</span>
            </div>
            <Progress value={conversionRate} className="h-3 bg-green-100 dark:bg-green-950" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Clientes Potenciales</span>
              <span className="text-sm font-semibold">{potentialClients} ({((potentialClients / totalClients) * 100).toFixed(1)}%)</span>
            </div>
            <Progress value={(potentialClients / totalClients) * 100} className="h-3 bg-amber-100 dark:bg-amber-950" />
          </div>
        </CardContent>
      </Card>

      {/* Clientes Potenciales - Leads */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Clientes Potenciales (Leads)
            </CardTitle>
            <Badge variant="outline">{potentialClients} leads</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {companies && companies.filter(c => 
            !certifications?.some(cert => cert.companyId === c.id && cert.status === "active")
          ).length > 0 ? (
            <div className="space-y-3">
              {companies
                .filter(c => !certifications?.some(cert => cert.companyId === c.id && cert.status === "active"))
                .slice(0, 5)
                .map((company) => (
                  <div
                    key={company.id}
                    className="flex items-center justify-between p-4 border rounded-md hover-elevate"
                    data-testid={`lead-${company.id}`}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                        <Building2 className="h-5 w-5 text-amber-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{company.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {company.contactEmail || "Sin email registrado"}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="bg-amber-50 dark:bg-amber-950">
                          Lead
                        </Badge>
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4">
                      <Button variant="outline" size="sm" data-testid={`button-email-${company.id}`}>
                        <Mail className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" data-testid={`button-call-${company.id}`}>
                        <Phone className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay clientes potenciales. ¡Todos los clientes están certificados!
            </p>
          )}
        </CardContent>
      </Card>

      {/* Clientes Activos */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              Clientes Activos
            </CardTitle>
            <Badge variant="outline" className="bg-green-50 dark:bg-green-950">
              {activeClients} activos
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {certifications && certifications.filter(c => c.status === "active").length > 0 ? (
            <div className="space-y-3">
              {certifications
                .filter(c => c.status === "active")
                .slice(0, 5)
                .map((cert) => {
                  const company = companies?.find(c => c.id === cert.companyId);
                  return (
                    <div
                      key={cert.id}
                      className="flex items-center justify-between p-3 border rounded-md"
                      data-testid={`active-client-${cert.id}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                          <Building2 className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">{company?.name || "Empresa"}</p>
                          <p className="text-sm text-muted-foreground">
                            Certificación Activa - Score: {cert.overallScore}/100
                          </p>
                        </div>
                      </div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 dark:bg-green-950">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Cliente
                        </Badge>
                      </div>
                    </div>
                  );
                })}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No hay clientes activos
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
