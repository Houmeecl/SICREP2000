import LandingHero from "@/components/LandingHero";
import ServicesSection from "@/components/ServicesSection";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Mail, Phone, MapPin } from "lucide-react";

const pricingPlans = [
  {
    name: "Certificación Inicial",
    price: "15 UF",
    period: "(pago único)",
    description: "Setup completo y auditoría inicial",
    features: [
      "Visita técnica a bodega/planta",
      "Medición certificada de embalajes",
      "Creación de códigos CPS por producto",
      "Capacitación del personal",
      "Auditoría documental inicial",
      "Emisión certificado SICREP año 1"
    ],
    popular: false
  },
  {
    name: "Plataforma Mensual",
    price: "5 UF",
    period: "/mes",
    description: "Gestión continua y trazabilidad digital",
    features: [
      "Plataforma web + app móvil",
      "30 adhesivos QR/mes incluidos",
      "Trazabilidad digital completa",
      "Reportes RETC automáticos",
      "Certificación anual renovable",
      "Soporte técnico 8x5"
    ],
    popular: true
  }
];

export default function LandingPage() {
  return (
    <div className="min-h-screen" data-testid="page-landing">
      <LandingHero />
      <ServicesSection />
      
      <section id="precios" className="py-12 md:py-20 px-4 bg-muted/30">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-semibold mb-4">
              PRECIOS
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {pricingPlans.map((plan, index) => (
              <Card
                key={index}
                className={`relative ${plan.popular ? "border-2 border-primary" : ""} hover-elevate`}
                data-testid={`card-pricing-${index}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="px-4 py-1">Popular</Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-8">
                  <CardTitle className="text-2xl mb-2">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-muted-foreground">{plan.period}</span>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <ul className="space-y-3">
                    {plan.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button
                    className="w-full mt-6"
                    variant={plan.popular ? "default" : "outline"}
                    data-testid={`button-select-plan-${index}`}
                  >
                    Seleccionar Plan
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
      
      <section id="contacto" className="py-16 px-4 bg-gradient-to-b from-background to-muted/30">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-semibold mb-4" data-testid="heading-contacto">
              CONTÁCTANOS
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-contacto-subtitle">
              Inicia tu certificación REP y accede a la red de proveedores mineros
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-3" data-testid="heading-email-card">
                  <div className="w-12 h-12 rounded-md bg-green-600/10 flex items-center justify-center">
                    <Mail className="w-6 h-6 text-green-600" />
                  </div>
                  Asesoría Comercial
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground mb-1" data-testid="text-email-comercial-label">Certificación y Precios</p>
                  <a 
                    href="mailto:guirep@sicrep.cl?subject=Consulta%20Certificación%20REP" 
                    className="text-lg font-medium hover:text-green-600 transition-colors"
                    data-testid="link-email-general"
                    aria-label="Enviar correo a guirep@sicrep.cl para consultas sobre certificación"
                  >
                    guirep@sicrep.cl
                  </a>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1" data-testid="text-email-soporte-label">Soporte Plataforma</p>
                  <a 
                    href="mailto:soporte@sicrep.cl?subject=Soporte%20Técnico" 
                    className="text-lg font-medium hover:text-green-600 transition-colors"
                    data-testid="link-email-support"
                    aria-label="Enviar correo a soporte@sicrep.cl para asistencia técnica"
                  >
                    soporte@sicrep.cl
                  </a>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-3" data-testid="heading-phone-card">
                  <div className="w-12 h-12 rounded-md bg-blue-600/10 flex items-center justify-center">
                    <Phone className="w-6 h-6 text-blue-600" />
                  </div>
                  Atención Telefónica
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground mb-1" data-testid="text-phone-label">Línea Directa</p>
                  <a 
                    href="tel:+56223456789" 
                    className="text-lg font-medium hover:text-blue-600 transition-colors"
                    data-testid="link-phone"
                    aria-label="Llamar al teléfono +56 2 2345 6789"
                  >
                    +56 2 2345 6789
                  </a>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1" data-testid="text-horario-label">Horario de Atención</p>
                  <p className="text-lg font-medium" data-testid="text-horario-value">
                    Lun - Vie: 9:00 - 18:00
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-8">
            <Card className="bg-green-600/5 border-green-600/20">
              <CardContent className="flex flex-col md:flex-row items-center justify-between gap-4 pt-6">
                <div className="flex items-start gap-3">
                  <MapPin className="w-6 h-6 text-green-600 mt-1 shrink-0" />
                  <div>
                    <p className="font-semibold mb-1" data-testid="text-ubicacion-label">Oficina Central</p>
                    <p className="text-sm text-muted-foreground" data-testid="text-ubicacion-value">
                      Santiago, Región Metropolitana, Chile
                    </p>
                  </div>
                </div>
                <a href="mailto:guirep@sicrep.cl?subject=Solicitud%20Asesoría%20Gratuita&body=Hola,%20me%20interesa%20obtener%20una%20asesoría%20gratuita%20sobre%20certificación%20REP.">
                  <Button 
                    size="lg" 
                    className="bg-green-600 hover:bg-green-700"
                    data-testid="button-agendar-asesoria"
                  >
                    Solicitar Asesoría Gratuita
                  </Button>
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      
      <footer className="border-t py-8 px-4 bg-muted/20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="font-semibold mb-3">SICREP</h3>
              <p className="text-sm text-muted-foreground">
                Sistema Integral de Certificación REP para proveedores de la industria minera en Chile.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-3">Enlaces Rápidos</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#solucion" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-solucion">
                    Nuestra Solución
                  </a>
                </li>
                <li>
                  <a href="#precios" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-precios">
                    Precios
                  </a>
                </li>
                <li>
                  <a href="#contacto" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-contacto">
                    Contacto
                  </a>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-3">Contacto</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <a href="mailto:guirep@sicrep.cl" className="hover:text-primary transition-colors">
                    guirep@sicrep.cl
                  </a>
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>+56 2 2345 6789</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t pt-6 text-center text-sm text-muted-foreground">
            <p>© 2024 SICREP - Sistema Integral de Certificación REP</p>
            <p className="mt-2">Cumplimiento Ley 20.920 - República de Chile</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
