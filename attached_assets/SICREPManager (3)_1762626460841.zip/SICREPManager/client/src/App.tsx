import { Switch, Route, Link, useLocation, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import AppSidebar from "@/components/AppSidebar";
import ThemeToggle from "@/components/ThemeToggle";
import LandingPage from "@/pages/LandingPage";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import CertificationWorkflow from "@/pages/CertificationWorkflow";
import ProviderManagement from "@/pages/ProviderManagement";
import CPSManagement from "@/pages/CPSManagement";
import DispatchManagement from "@/pages/DispatchManagement";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import UsersManagement from "@/pages/admin/UsersManagement";
import CompaniesManagement from "@/pages/admin/CompaniesManagement";
import PaymentsManagement from "@/pages/admin/PaymentsManagement";
import AssignmentsManagement from "@/pages/admin/AssignmentsManagement";
import CPSDashboard from "@/pages/cps/CPSDashboard";
import CPSEvaluation from "@/pages/cps/CPSEvaluation";
import EvaluadorDashboard from "@/pages/evaluador/EvaluadorDashboard";
import FieldInspection from "@/pages/evaluador/FieldInspection";
import ProveedorDashboard from "@/pages/proveedor/ProveedorDashboard";
import MiningDashboard from "@/pages/MiningDashboard";
import AuditorDashboard from "@/pages/auditor/AuditorDashboard";
import CertificadorDashboard from "@/pages/certificador/CertificadorDashboard";
import AnalistaESGDashboard from "@/pages/analista-esg/AnalistaESGDashboard";
import VendedorDashboard from "@/pages/vendedor/VendedorDashboard";
import ComiteDashboard from "@/pages/comite/ComiteDashboard";
import { RoleGuard } from "@/components/RoleGuard";
import NotFound from "@/pages/not-found";
import sicrepLogo from "@assets/ChatGPT Image 3 nov 2025, 03_29_38 p.m._1762584049547.png";

function AppLayout({ children }: { children: React.ReactNode }) {
  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1">
          <header className="flex items-center justify-between p-4 border-b gap-4">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <ThemeToggle />
          </header>
          <main className="flex-1 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function Router() {
  const [location] = useLocation();
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }
  
  // Landing page - sin autenticación
  if (location === "/" && !user) {
    return (
      <div className="min-h-screen">
        <nav className="sticky top-0 left-0 right-0 z-50 bg-white dark:bg-background border-b shadow-sm">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <Link href="/" data-testid="link-logo">
              <div className="flex items-center">
                <span className="text-2xl font-bold">
                  <span className="text-foreground">SICR</span>
                  <span className="text-green-600">EP</span>
                </span>
              </div>
            </Link>
            
            <div className="hidden md:flex items-center gap-6">
              <a href="#solucion" className="text-sm font-medium hover:text-primary transition-colors" data-testid="link-solucion">
                Solución
              </a>
              <a href="#precios" className="text-sm font-medium hover:text-primary transition-colors" data-testid="link-precios">
                Precios
              </a>
              <a href="#contacto" className="text-sm font-medium hover:text-primary transition-colors" data-testid="link-contacto">
                Contacto
              </a>
              <Link href="/login">
                <Button className="bg-blue-600 hover:bg-blue-700" data-testid="button-para-minera">
                  Para Minera
                </Button>
              </Link>
              <Link href="/login">
                <Button variant="outline" data-testid="button-acceso-proveedor">
                  Acceso Proveedor
                </Button>
              </Link>
            </div>
            
            <div className="md:hidden">
              <Link href="/login">
                <Button variant="outline" size="sm" data-testid="button-login-access">
                  Iniciar Sesión
                </Button>
              </Link>
            </div>
          </div>
        </nav>
        <LandingPage />
      </div>
    );
  }
  
  // Redirect root to dashboard if authenticated
  if (location === "/" && user) {
    return <Redirect to="/dashboard" />;
  }
  
  // Login page
  if (location === "/login") {
    if (user) {
      return <Redirect to="/dashboard" />;
    }
    return <Login />;
  }
  
  // Require authentication for all other routes
  if (!user) {
    return <Redirect to="/login" />;
  }
  
  return (
    <AppLayout>
      <Switch>
        <Route path="/">
          <Redirect to="/dashboard" />
        </Route>
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/certificaciones" component={CertificationWorkflow} />
        <Route path="/proveedores" component={ProviderManagement} />
        <Route path="/cps" component={CPSManagement} />
        <Route path="/despachos" component={DispatchManagement} />
        <Route path="/admin/dashboard">
          <RoleGuard allowedRoles={["admin"]}>
            <AdminDashboard />
          </RoleGuard>
        </Route>
        <Route path="/admin/usuarios">
          <RoleGuard allowedRoles={["admin"]}>
            <UsersManagement />
          </RoleGuard>
        </Route>
        <Route path="/admin/empresas">
          <RoleGuard allowedRoles={["admin"]}>
            <CompaniesManagement />
          </RoleGuard>
        </Route>
        <Route path="/admin/pagos">
          <RoleGuard allowedRoles={["admin"]}>
            <PaymentsManagement />
          </RoleGuard>
        </Route>
        <Route path="/admin/asignaciones">
          <RoleGuard allowedRoles={["admin"]}>
            <AssignmentsManagement />
          </RoleGuard>
        </Route>
        <Route path="/cps/dashboard">
          <RoleGuard allowedRoles={["cps"]}>
            <CPSDashboard />
          </RoleGuard>
        </Route>
        <Route path="/cps/evaluacion/:id">
          <RoleGuard allowedRoles={["cps"]}>
            <CPSEvaluation />
          </RoleGuard>
        </Route>
        <Route path="/evaluador/dashboard">
          <RoleGuard allowedRoles={["evaluador"]}>
            <EvaluadorDashboard />
          </RoleGuard>
        </Route>
        <Route path="/evaluador/inspeccion/:id">
          <RoleGuard allowedRoles={["evaluador"]}>
            <FieldInspection />
          </RoleGuard>
        </Route>
        <Route path="/proveedor/dashboard">
          <RoleGuard allowedRoles={["proveedor"]}>
            <ProveedorDashboard />
          </RoleGuard>
        </Route>
        <Route path="/minera/dashboard">
          <RoleGuard allowedRoles={["empresa_minera"]}>
            <MiningDashboard />
          </RoleGuard>
        </Route>
        <Route path="/auditor/dashboard">
          <RoleGuard allowedRoles={["auditor"]}>
            <AuditorDashboard />
          </RoleGuard>
        </Route>
        <Route path="/certificador/dashboard">
          <RoleGuard allowedRoles={["certificador"]}>
            <CertificadorDashboard />
          </RoleGuard>
        </Route>
        <Route path="/analista-esg/dashboard">
          <RoleGuard allowedRoles={["analista_esg"]}>
            <AnalistaESGDashboard />
          </RoleGuard>
        </Route>
        <Route path="/vendedor/dashboard">
          <RoleGuard allowedRoles={["vendedor"]}>
            <VendedorDashboard />
          </RoleGuard>
        </Route>
        <Route path="/comite/dashboard">
          <RoleGuard allowedRoles={["miembro_comite"]}>
            <ComiteDashboard />
          </RoleGuard>
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
